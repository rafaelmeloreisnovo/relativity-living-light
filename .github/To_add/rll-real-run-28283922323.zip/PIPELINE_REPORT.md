# PIPELINE_REPORT

- run_utc: `2026-06-27T08:30:40Z`
- commit_sha: `8fc3134de672a195dc4e3347dda4ba765523e087`
- book_scope: `all`
- dataset_group: `all`
- mode: `compute`
- status editorial: `Parcial real em preparação`
- objetivo: methodology: validar rota metodológica. ; real_data: auditar dados reais e χ² inicial. ; scripts: mapear execução reprodutível. ; observational_validation: gerar rota de validação observacional completa. ; desi_boss: gerar manifesto de validação DESI/BOSS/Planck. ; amas_mcrp: ligar AMAS/SAA ao MCRP sem afirmar validação total.

## Separação obrigatória
- Hipótese
- Dado
- Modelo
- Métrica
- Referência
- Status: `blocked`
