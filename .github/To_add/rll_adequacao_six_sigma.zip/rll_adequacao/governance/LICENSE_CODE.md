# LICENSE — Código / Code License

**MIT License**

Copyright (c) 2025–2026 Rafael Melo Reis (∆RafaelVerboΩ) — Instituto Rafael / RAFAELIA Research Collective

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

---

## Escopo desta licença

Esta licença **MIT** aplica-se a:

- Todo código Python em `src/`
- Scripts em `scripts/`
- Notebooks em `data/*.ipynb`
- Arquivos de configuração (`pyproject.toml`, `pytest.ini`, `requirements.txt`)
- Schemas JSON em `schemas/`
- Workflows CI/CD em `.github/`

## O que NÃO está coberto pela licença MIT

- Documentação científica, manuscritos e textos simbólicos → cobertos por `LICENSE.md` (RAFCODE-Φ)
- Dados observacionais externos (DESI, Pantheon+, CMB) → licença da fonte original
- Logotipos, selos simbólicos e simbologia RAFAELIA → cobertos por `LICENSE.md`

## Resolução do conflito LIC-01

> **Problema anterior:** `LICENSE.md` (RAFCODE-Φ, não-OSI) conflitava com
> `pyproject.toml` que declarava `MIT`.
>
> **Resolução:** separação explícita de escopos:
> - `LICENSE.md` → obras simbólicas e documentação (RAFCODE-Φ, autoral)
> - `LICENSE_CODE.md` (este arquivo) → código e scripts (MIT, OSI-aprovado)
>
> Norma de referência: SPDX License Identifier `MIT` para código,
> identificador customizado `RAFCODE-PHI-1.0` para obras simbólicas.

---

*RAFCODE-Φ-∆RafaelVerboΩ-𓂀ΔΦΩ · Ω=Amor · FIAT LUX*
