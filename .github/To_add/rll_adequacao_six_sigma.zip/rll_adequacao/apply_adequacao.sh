#!/bin/sh
# apply_adequacao.sh — Aplica todos os arquivos de adequação ao repositório RLL
# Compatível com: Termux ARM32/ARMv7l · sh POSIX (sem bash extensions)
# Uso: sh apply_adequacao.sh [--dry-run]
#
# Norma: IEEE 730-2014 (Software QA) · FAIR (reprodutibilidade)
# Status: [C] script de aplicação — não modifica lógica científica

set -e

REPO_ROOT="${REPO_ROOT:-$HOME/relativity-living-light}"
ADEQUACAO_DIR="$(cd "$(dirname "$0")" && pwd)"
DRY_RUN=0
LOG="$ADEQUACAO_DIR/apply_adequacao.log"

if [ "$1" = "--dry-run" ]; then
    DRY_RUN=1
    echo "[DRY-RUN] Nenhum arquivo será modificado."
fi

log() {
    echo "[$(date '+%Y-%m-%dT%H:%M:%S')] $*" | tee -a "$LOG"
}

apply() {
    SRC="$1"
    DST="$REPO_ROOT/$2"
    if [ $DRY_RUN -eq 1 ]; then
        log "DRY-RUN: cp $SRC → $DST"
        return
    fi
    # Backup antes de sobrescrever
    if [ -f "$DST" ]; then
        cp "$DST" "${DST}.bak_$(date '+%Y%m%d_%H%M%S')"
        log "BACKUP: ${DST}.bak criado"
    fi
    mkdir -p "$(dirname "$DST")"
    cp "$SRC" "$DST"
    log "OK: $SRC → $DST"
}

# ============================================================
log "=== INÍCIO DA APLICAÇÃO DE ADEQUAÇÕES RLL ==="
log "Repositório: $REPO_ROOT"
log "Modo: $([ $DRY_RUN -eq 1 ] && echo DRY-RUN || echo APLICAR)"

# Verificar que o repositório existe
if [ ! -d "$REPO_ROOT" ]; then
    log "ERRO: Repositório não encontrado em $REPO_ROOT"
    log "Definir variável: export REPO_ROOT=/path/to/relativity-living-light"
    exit 1
fi

# ============================================================
log "--- A01: Cirurgia templates de governança ---"
apply "$ADEQUACAO_DIR/raiz/REFORM_LOG.md"              "REFORM_LOG.md"
apply "$ADEQUACAO_DIR/raiz/GOVERNANCE_REORG_DRAFT.md"  "GOVERNANCE_REORG_DRAFT.md"

# ============================================================
log "--- A02: Instruções de fetch Pantheon+ ---"
mkdir -p "$REPO_ROOT/data/pantheon" 2>/dev/null || true
apply "$ADEQUACAO_DIR/data/FETCH_INSTRUCTIONS.md" "data/pantheon/FETCH_INSTRUCTIONS.md"

# ============================================================
log "--- A03: newadd/README.md ---"
apply "$ADEQUACAO_DIR/raiz/newadd_README.md" "newadd/README.md"

# ============================================================
log "--- A04: data2/README.md ---"
apply "$ADEQUACAO_DIR/data/data2_README.md" "data2/README.md"

# ============================================================
log "--- A05: INDICE_MESTRE patch (append) ---"
PATCH="$ADEQUACAO_DIR/docs/INDICE_MESTRE_PATCH.md"
INDICE="$REPO_ROOT/docs/INDICE_MESTRE.md"
if [ $DRY_RUN -eq 0 ]; then
    if ! grep -q "Núcleo computacional bare-metal" "$INDICE" 2>/dev/null; then
        echo "" >> "$INDICE"
        echo "---" >> "$INDICE"
        echo "<!-- ADEQUAÇÃO A05 2026-06-24 -->" >> "$INDICE"
        cat "$PATCH" >> "$INDICE"
        log "OK: INDICE_MESTRE_PATCH.md appendado em docs/INDICE_MESTRE.md"
    else
        log "SKIP: seção 'Núcleo computacional bare-metal' já existe em INDICE_MESTRE.md"
    fi
else
    log "DRY-RUN: appendaria INDICE_MESTRE_PATCH.md → docs/INDICE_MESTRE.md"
fi

# ============================================================
log "--- A06: chi2_bao_cov.py ---"
apply "$ADEQUACAO_DIR/scripts/chi2_bao_cov.py" "scripts/chi2_bao_cov.py"
if [ $DRY_RUN -eq 0 ]; then
    chmod +x "$REPO_ROOT/scripts/chi2_bao_cov.py"
fi

# ============================================================
log "--- A07: src/rll/rll_model.py ---"
apply "$ADEQUACAO_DIR/src/rll_model.py" "src/rll/rll_model.py"

# ============================================================
log "--- D-LIC: CITATION.cff e LICENSE_CODE.md ---"
apply "$ADEQUACAO_DIR/governance/CITATION.cff"    "CITATION.cff"
apply "$ADEQUACAO_DIR/governance/LICENSE_CODE.md" "LICENSE_CODE.md"

# ============================================================
log "--- CHECKLIST MESTRE ---"
apply "$ADEQUACAO_DIR/CHECKLIST_MESTRE_ADEQUACAO.md" "docs/CHECKLIST_MESTRE_ADEQUACAO.md"

# ============================================================
log ""
log "=== VERIFICAÇÕES PÓS-APLICAÇÃO ==="

if [ $DRY_RUN -eq 0 ]; then
    # Verificar que pytest ainda passa
    log "Rodando pytest -q..."
    cd "$REPO_ROOT"
    if command -v pytest >/dev/null 2>&1; then
        pytest -q 2>&1 | tail -5 | tee -a "$LOG"
    else
        log "AVISO: pytest não encontrado. Instalar: pip install pytest --break-system-packages"
    fi

    # Verificar imports do novo módulo
    log "Verificando rll_model.py imports..."
    python3 -c "
import sys
sys.path.insert(0, 'src')
try:
    from rll.rll_model import Ez_RLL, Ez_LCDM, Ez_w0wa, w_eff_RLL
    print('OK: rll_model imports funcionando')
    # Teste rápido
    e = Ez_RLL(0.5)
    print(f'OK: Ez_RLL(z=0.5) = {e:.6f}')
    w = w_eff_RLL(0.7)
    print(f'OK: w_eff_RLL(a=0.7) = {w:.6f}')
except ImportError as exc:
    print(f'AVISO: {exc} — verificar se rll_model já existe em src/rll/')
" 2>&1 | tee -a "$LOG"

    # Verificar chi2_bao_cov
    log "Verificando chi2_bao_cov.py..."
    python3 scripts/chi2_bao_cov.py --model lcdm --json 2>&1 | head -10 | tee -a "$LOG"
fi

# ============================================================
log ""
log "=== RESUMO ==="
log "Arquivos aplicados:"
log "  REFORM_LOG.md                       (A01)"
log "  GOVERNANCE_REORG_DRAFT.md           (A01)"
log "  data/pantheon/FETCH_INSTRUCTIONS.md (A02)"
log "  newadd/README.md                    (A03)"
log "  data2/README.md                     (A04)"
log "  docs/INDICE_MESTRE.md (patch)       (A05)"
log "  scripts/chi2_bao_cov.py             (A06)"
log "  src/rll/rll_model.py                (A07)"
log "  CITATION.cff                        (D-LIC)"
log "  LICENSE_CODE.md                     (D-LIC)"
log "  docs/CHECKLIST_MESTRE_ADEQUACAO.md  (controle)"
log ""
log "Próximos passos:"
log "  1. git add -A && git commit -m 'adequacao: Six Sigma gaps G01-G10 (A01-A07, D-LIC)'"
log "  2. Executar fetch Pantheon+: python scripts/verify_pantheon_inputs.py --fetch"
log "  3. Rodar pipeline completo: python rll_vs_lcdm.py --adversary both --with-bayes --with-growth"
log "  4. Registrar SHA-256 de Pantheon+ em data/pantheon/FETCH_INSTRUCTIONS.md"
log ""
log "=== FIM: $(date '+%Y-%m-%dT%H:%M:%S') ==="
