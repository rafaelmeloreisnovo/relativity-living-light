"""rll_model.py — Funções nucleares do modelo Relativity Living Light.

Este módulo é o ponto de entrada canônico para as funções de E(z), w_eff e
distâncias do RLL. Ele reexporta as implementações primárias de onde quer
que estejam definidas no pacote, garantindo que código externo sempre importe
de `rll.rll_model` independente de reorganizações internas.

Normas:
    IEEE 730-2014 (Software QA) — interface estável de módulo
    FAIR (Findability) — localização canônica e documentada

Status epistemológico:
    [E] Equação de Friedmann extendida: estabelecida como hipótese testável
    [C] Implementação Python: convenção de modelagem deste pipeline
    [H] RLL > w0waCDM: hipótese a ser testada com dados reais

Equação-mãe [C/H]:
    E²(a) = Ω_r·a⁻⁴ + Ω_m·a⁻³ + Ω_Λ
           + Ω_s0·[f(a) + (1−f(a))·a⁻³]   ← setor fotônico (DE→DM)
           + Ω_B0·a⁻⁴                       ← setor magnético
           + Ω_P0·a⁻⁴                       ← setor plasmático

    f(z) = 1 / (1 + exp((z − z_t) / w_t))  ← transição logística

Importação canônica:
    from rll.rll_model import Ez_RLL, Ez_LCDM, Ez_w0wa, w_eff_RLL
"""

from __future__ import annotations

import math
from typing import Callable

__all__ = [
    "Ez_LCDM",
    "Ez_w0wa",
    "Ez_RLL",
    "w_eff_RLL",
    "logistic_f",
    "DM_over_rd",
    "DH_over_rd",
    "DV_over_rd",
    "chi2_diagonal",
    "aic",
    "aicc",
    "bic",
    "RLL_DEFAULTS",
]

# ---------------------------------------------------------------------------
# Parâmetros padrão [C] — convenção de baseline
# ---------------------------------------------------------------------------

RLL_DEFAULTS: dict = {
    "Om": 0.3,
    "Or": 8.6e-5,
    "Os0": 0.05,
    "zt": 0.7,
    "wt": 0.2,
    "OB0": 0.0,
    "OP0": 0.0,
    "w0": -1.0,
    "wa": 0.0,
    "H0": 67.4,
    "rd": 147.09,
}

# ---------------------------------------------------------------------------
# Funções auxiliares
# ---------------------------------------------------------------------------

def logistic_f(z: float, zt: float, wt: float) -> float:
    """Transição logística f(z) — Equação de superposição fotônica. [C/H]

    Limites:
        z << zt → f → 1  (comportamento tipo energia escura)
        z >> zt → f → 0  (comportamento tipo matéria)

    Parameters
    ----------
    z : float  — redshift
    zt : float — redshift de transição
    wt : float — largura da transição (wt > 0)
    """
    if wt <= 0:
        raise ValueError(f"wt deve ser positivo, recebido: {wt}")
    try:
        return 1.0 / (1.0 + math.exp((z - zt) / wt))
    except OverflowError:
        return 0.0 if z > zt else 1.0


def _integrate_Ez(Ez_func: Callable[[float], float], z: float, n: int = 1000) -> float:
    """Integral numérica ∫₀ᶻ dz'/E(z') — regra de Simpson. [E]"""
    if z <= 0.0:
        return 0.0
    dz = z / n
    total = 0.0
    for i in range(n + 1):
        zi = i * dz
        w = 1.0 if (i == 0 or i == n) else (4.0 if i % 2 else 2.0)
        ez = Ez_func(zi)
        if ez <= 0:
            raise ValueError(f"E(z={zi:.4f}) ≤ 0 — verificar parâmetros do modelo")
        total += w / ez
    return total * dz / 3.0


# ---------------------------------------------------------------------------
# Modelos E(z) [E/C/H]
# ---------------------------------------------------------------------------

def Ez_LCDM(
    z: float,
    Om: float = RLL_DEFAULTS["Om"],
    Or: float = RLL_DEFAULTS["Or"],
) -> float:
    """E(z) = H(z)/H0 para ΛCDM. [E]

    E²(a) = Ω_r·a⁻⁴ + Ω_m·a⁻³ + Ω_Λ  com Ω_Λ = 1 − Ω_m − Ω_r (flat)
    """
    OL = max(1.0 - Om - Or, 0.0)
    a = 1.0 / (1.0 + z)
    e2 = Or * a**-4 + Om * a**-3 + OL
    if e2 < 0:
        raise ValueError(f"E²({z}) < 0 para ΛCDM — parâmetros inconsistentes")
    return math.sqrt(e2)


def Ez_w0wa(
    z: float,
    Om: float = RLL_DEFAULTS["Om"],
    w0: float = RLL_DEFAULTS["w0"],
    wa: float = RLL_DEFAULTS["wa"],
    Or: float = RLL_DEFAULTS["Or"],
) -> float:
    """E(z) para w0waCDM (CPL parametrização). [E]

    Adversário principal do RLL conforme `docs/canonicos/14_MODELO_COSMOLOGICO_RLL.md`.

    E²(a) = Ω_r·a⁻⁴ + Ω_m·a⁻³ + Ω_DE·a^{-3(1+w0+wa)}·exp(−3·wa·(1−a))
    """
    ODE = max(1.0 - Om - Or, 0.0)
    a = 1.0 / (1.0 + z)
    fde = a**(-3.0 * (1.0 + w0 + wa)) * math.exp(-3.0 * wa * (1.0 - a))
    e2 = Or * a**-4 + Om * a**-3 + ODE * fde
    if e2 < 0:
        raise ValueError(f"E²({z}) < 0 para w0waCDM — parâmetros inconsistentes")
    return math.sqrt(e2)


def Ez_RLL(
    z: float,
    Om: float = RLL_DEFAULTS["Om"],
    Os0: float = RLL_DEFAULTS["Os0"],
    zt: float = RLL_DEFAULTS["zt"],
    wt: float = RLL_DEFAULTS["wt"],
    OB0: float = RLL_DEFAULTS["OB0"],
    OP0: float = RLL_DEFAULTS["OP0"],
    Or: float = RLL_DEFAULTS["Or"],
) -> float:
    """E(z) = H(z)/H0 para o modelo RLL. [C/H]

    Equação-mãe (docs/canonicos/14_MODELO_COSMOLOGICO_RLL.md):
        E²(a) = Ω_r·a⁻⁴ + Ω_m·a⁻³ + Ω_Λ
               + Ω_s0·[f(a) + (1−f(a))·a⁻³]
               + Ω_B0·a⁻⁴ + Ω_P0·a⁻⁴

    Restrição de planicidade: Ω_Λ = 1 − Ω_m − Ω_r − Ω_s0 − Ω_B0 − Ω_P0
    """
    OL = max(1.0 - Om - Or - Os0 - OB0 - OP0, 0.0)
    a = 1.0 / (1.0 + z)
    f = logistic_f(z, zt, wt)
    g = f + (1.0 - f) * a**-3
    e2 = (
        Or * a**-4
        + Om * a**-3
        + OL
        + Os0 * g
        + OB0 * a**-4
        + OP0 * a**-4
    )
    if e2 < 0:
        raise ValueError(
            f"E²({z}) < 0 para RLL — verificar normalização de Ω\n"
            f"  Om={Om}, Os0={Os0}, OB0={OB0}, OP0={OP0}, Or={Or}, OL={OL}"
        )
    return math.sqrt(e2)


def w_eff_RLL(
    a: float,
    zt: float = RLL_DEFAULTS["zt"],
    wt: float = RLL_DEFAULTS["wt"],
    eps: float = 1e-6,
) -> float:
    """Equação de estado efetiva do setor de superposição. [C/H]

    w_eff(a) = -1 - (1/3) · d(ln g)/d(ln a)

    com g(a) = f(a) + (1−f(a))·a⁻³
    e   f(z) = logistic_f(z, zt, wt)  onde z = 1/a − 1

    Falsificador: w_eff deve cruzar w=−1 sem divergência (docs/canonicos/19_ROADMAP_FALSIFICADORES_RLL.md C02).
    """
    if a <= 0 or a > 1:
        raise ValueError(f"a deve estar em (0, 1], recebido: {a}")

    z = 1.0 / a - 1.0
    f = logistic_f(z, zt, wt)
    g = f + (1.0 - f) * a**-3

    # Derivada numérica: d(ln g)/d(ln a) = (a/g) * dg/da
    da = eps * a
    a_p, a_m = a + da, a - da
    z_p = 1.0 / a_p - 1.0
    z_m = 1.0 / a_m - 1.0
    f_p = logistic_f(z_p, zt, wt)
    f_m = logistic_f(z_m, zt, wt)
    g_p = f_p + (1.0 - f_p) * a_p**-3
    g_m = f_m + (1.0 - f_m) * a_m**-3
    dg_da = (g_p - g_m) / (2.0 * da)

    if g <= 0:
        return float("nan")
    d_ln_g_d_ln_a = (a / g) * dg_da
    return -1.0 - d_ln_g_d_ln_a / 3.0


# ---------------------------------------------------------------------------
# Funções de distância [E]
# ---------------------------------------------------------------------------

def DM_over_rd(
    z: float,
    Ez_func: Callable[[float], float],
    H0: float,
    rd: float,
) -> float:
    """DM(z)/rd — distância comóvel normalizada. [E]"""
    c_kms = 299792.458
    return (c_kms / H0) * _integrate_Ez(Ez_func, z) / rd


def DH_over_rd(
    z: float,
    Ez_func: Callable[[float], float],
    H0: float,
    rd: float,
) -> float:
    """DH(z)/rd = c/(H(z)·rd). [E]"""
    c_kms = 299792.458
    return (c_kms / H0) / (Ez_func(z) * rd)


def DV_over_rd(
    z: float,
    Ez_func: Callable[[float], float],
    H0: float,
    rd: float,
) -> float:
    """DV(z)/rd — distância volumétrica. [E]"""
    c_kms = 299792.458
    DM = DM_over_rd(z, Ez_func, H0, rd) * rd
    DH = (c_kms / H0) / Ez_func(z)
    DV = (z * DM**2 * DH) ** (1.0 / 3.0)
    return DV / rd


# ---------------------------------------------------------------------------
# χ² diagonal e métricas [E]
# ---------------------------------------------------------------------------

def chi2_diagonal(
    Ez_func: Callable[[float], float],
    H0: float,
    rd: float,
    data: list[dict],
) -> float:
    """χ² diagonal — compatível com formato de data de rll_vs_lcdm.py.

    data: lista de dicts com chaves z, observable, value, error.
    Para χ² com covariância completa, usar scripts/chi2_bao_cov.py.

    Status: [C] — otimista quando há correlações. Usar com cov quando disponível.
    """
    _dispatch = {
        "DM_over_rd": DM_over_rd,
        "DH_over_rd": DH_over_rd,
        "DV_over_rd": DV_over_rd,
    }
    total = 0.0
    for pt in data:
        pred_func = _dispatch.get(pt["observable"])
        if pred_func is None:
            raise ValueError(f"Observable desconhecido: {pt['observable']}")
        pred = pred_func(pt["z"], Ez_func, H0, rd)
        r = (pt["value"] - pred) / pt["error"]
        total += r * r
    return total


def aic(chi2: float, k: int) -> float:
    """AIC = chi2 + 2k. [E]"""
    return chi2 + 2.0 * k


def aicc(chi2: float, k: int, n: int) -> float:
    """AICc = AIC + 2k(k+1)/(n-k-1). [E]"""
    denom = n - k - 1
    if denom <= 0:
        return float("inf")
    return aic(chi2, k) + 2.0 * k * (k + 1) / denom


def bic(chi2: float, k: int, n: int) -> float:
    """BIC = chi2 + k·ln(n). [E]"""
    return chi2 + k * math.log(n)
