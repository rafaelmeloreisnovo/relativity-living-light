# CHECKLIST MESTRE DE ADEQUAÇÃO — Six Sigma Control Plan
# instituto-Rafael/relativity-living-light
# Gerado: 2026-06-24 · Ciclo DMAIC ψ→χ→ρ→Δ→Σ→Ω

**Normas:** ISO 9001:2015 (melhoria contínua) · ISO 27001:2022 (integridade)
· NIST SP 800-53 Rev 5 · IEEE 730-2014 · FAIR · W3C PROV-DM · RFC 3161

---

## BLOCO A — AÇÕES CRÍTICAS (fazer antes de qualquer submissão)

### A01 — Cirurgia de templates em arquivos de governança [🔴 CRÍTICO]

Problema: `REFORM_LOG.md`, `GOVERNANCE_REORG_DRAFT.md`, `RESUMO_REFORMA.md`
compartilham header idêntico de template pós-doc, contaminando cadeia de custódia.

- [ ] Aplicar `REFORM_LOG.md` corrigido (arquivo: `raiz/REFORM_LOG.md`)
- [ ] Aplicar `GOVERNANCE_REORG_DRAFT.md` corrigido (arquivo: `raiz/GOVERNANCE_REORG_DRAFT.md`)
- [ ] Criar versão corrigida de `RESUMO_REFORMA.md` com mesma estrutura §0/§H
- [ ] Verificar se outros arquivos com header idêntico existem:
      ```bash
      grep -rl "revisão ultra formal com indexação semântica" . --include="*.md"
      ```
- [ ] Para cada arquivo encontrado: adicionar marcação `<!-- SEÇÃO PÓS-DOC 2026 -->`
      e preservar conteúdo histórico em seção `§H`
- [ ] Commit separado: `fix: separate post-doc template from historical content (G01)`

Verificação: `grep -c "Conteúdo histórico preservado" REFORM_LOG.md` deve retornar 1

---

### A02 — Fetch de Pantheon+ documentado [🔴 CRÍTICO]

Problema: `rll_vs_lcdm.py --data real` falha sem `data/pantheon/lcparam_full_long_zhel.txt`.
Bloqueia validação de C01, C05, C07.

- [ ] Criar `data/pantheon/FETCH_INSTRUCTIONS.md` (arquivo: `data/FETCH_INSTRUCTIONS.md`)
- [ ] Criar `data/pantheon/` se não existir: `mkdir -p data/pantheon`
- [ ] Executar fetch (Termux com rede):
      ```bash
      python scripts/verify_pantheon_inputs.py --fetch --json
      ```
      Se `verify_pantheon_inputs.py` não tiver `--fetch`, usar wget da Seção 3 do FETCH_INSTRUCTIONS.md
- [ ] Calcular e registrar SHA-256:
      ```bash
      sha256sum data/pantheon/lcparam_full_long_zhel.txt
      ```
- [ ] Atualizar `FETCH_INSTRUCTIONS.md` com hash real (substituir `[VAZIO]` por hash)
- [ ] Mudar status de `DECLARED_BY_AUTHOR` para `VERIFIED`
- [ ] Commit: `data: add pantheon+ fetch instructions and verify SHA256 (A02)`

Verificação: `python rll_vs_lcdm.py --adversary both --with-bayes --with-growth` deve completar sem erro

---

## BLOCO B — AÇÕES ALTAS (semana 1)

### A03 — newadd/README.md mínimo [🟠 ALTO]

- [ ] Aplicar `newadd/README.md` (arquivo: `raiz/newadd_README.md`)
      ```bash
      cp raiz/newadd_README.md newadd/README.md
      ```
- [ ] Listar conteúdo real:
      ```bash
      ls -la newadd/ >> newadd/README.md
      ```
- [ ] Substituir `[VAZIO]` na tabela com nomes reais de arquivos
- [ ] Commit: `docs: add newadd/README.md inventory stub (A03-G02)`

---

### A04 — data2/ indexado [🟠 ALTO]

- [ ] Aplicar `data2/README.md` (arquivo: `data/data2_README.md`)
      ```bash
      cp data/data2_README.md data2/README.md
      ```
- [ ] Executar inventário:
      ```bash
      find data2/ -type f | sort
      ```
- [ ] Preencher tabela de inventário no README com arquivos reais
- [ ] Marcar arquivos duplicados de `data/` para resolução
- [ ] Commit: `docs: add data2/README.md index and inventory (A04-G03)`

---

### A05 — core/lowlevel_runtime/ no INDICE_MESTRE [🟠 ALTO]

- [ ] Adicionar seção `## 4) Núcleo computacional bare-metal` em `docs/INDICE_MESTRE.md`
      (conteúdo: arquivo `docs/INDICE_MESTRE_PATCH.md` seção 4)
- [ ] Adicionar seção `## 5) Dados complementares` (seção 5 do patch)
- [ ] Adicionar seção `## 6) Arquivo histórico` (seção 6 do patch)
- [ ] Adicionar seção `## 7) Governança de licenciamento` (seção 7 do patch)
- [ ] Commit: `docs: add core/lowlevel_runtime and data2 to INDICE_MESTRE (A05-G05)`

Verificação: `grep -n "lowlevel_runtime" docs/INDICE_MESTRE.md` deve retornar ≥1 linha

---

## BLOCO C — AÇÕES MÉDIAS (semana 2)

### A06 — Covariância BAO 2×2 integrada ao pipeline [🟡 MÉDIO]

- [ ] Copiar `scripts/chi2_bao_cov.py` para `scripts/` do repositório
- [ ] Verificar que `numpy` disponível: `python3 -c "import numpy; print(numpy.__version__)"`
- [ ] Testar com dados sintéticos:
      ```bash
      python scripts/chi2_bao_cov.py --model lcdm --json
      ```
      Espera: `"status": "DECLARED_BY_AUTHOR"` e aviso de diagonal (sem COV ainda)
- [ ] Quando `desi_dr2_bao_covariance_summary.csv` disponível, testar:
      ```bash
      python scripts/chi2_bao_cov.py --model rll --cov data/real/cosmology/desi_dr2_bao_covariance_summary.csv --json
      ```
      Espera: `"status": "VERIFIED"` e `"cov_mode": "full"`
- [ ] Integrar `chi2_bao_full` em `rll_vs_lcdm.py` substituindo cálculo diagonal
- [ ] Adicionar entrada em `rll_equation_registry.yml`:
      ```yaml
      - id: chi2_bao_full
        equation: "chi2 = r^T C^{-1} r"
        domain: ["statistics", "BAO", "model_validation"]
        status: "known_statistics"
        source_doc: "scripts/chi2_bao_cov.py"
        claim_boundary: "correct only when full 2x2 covariance per tracer is provided"
      ```
- [ ] Commit: `feat: add chi2_bao_full with 2x2 covariance (A06-G10)`

---

### A07 — src/rll/rll_model.py canônico [🟡 MÉDIO]

- [ ] Verificar onde `Ez_RLL`, `Ez_LCDM`, `Ez_w0wa` estão definidas atualmente:
      ```bash
      grep -rn "def Ez_RLL" src/
      ```
- [ ] Se existirem em outro módulo: criar `src/rll/rll_model.py` como re-export
      (arquivo: `src/rll_model.py`)
- [ ] Se não existirem: aplicar `src/rll_model.py` como implementação primária
- [ ] Atualizar imports em `rll_vs_lcdm.py` para usar `from rll.rll_model import ...`
- [ ] Rodar `pytest -q`: verificar que 48 passed ainda
- [ ] Commit: `feat: add canonical src/rll/rll_model.py module (A07-G07)`

---

## BLOCO D — GOVERNANÇA DE LICENCIAMENTO (semana 2–3)

### D-LIC — Resolução do conflito LIC-01 [🟠 ALTO]

- [ ] Aplicar `governance/LICENSE_CODE.md` como `LICENSE_CODE.md` na raiz
- [ ] Aplicar `governance/CITATION.cff` como `CITATION.cff` na raiz
      (substituindo/complementando `data/CITATION.cff`)
- [ ] Atualizar `pyproject.toml`:
      ```toml
      license = { file = "LICENSE_CODE.md" }
      ```
- [ ] Verificar que `data/CITATION.cff` original está preservado em `archive/`
- [ ] Commit: `governance: add LICENSE_CODE.md MIT and CITATION.cff to root (D-LIC)`

---

## BLOCO E — CAMINHOS DISTANTES (semana 3–4)

### D02 — MCMC / Nested Sampling

- [ ] Verificar que `emcee>=3.1.6` está instalado (já em `pyproject.toml`)
- [ ] Criar `scripts/rll_mcmc.py` com:
      - sampler `emcee.EnsembleSampler`
      - prior uniforme em (Om, Os0, zt, wt, H0, rd)
      - likelihood via `chi2_bao_full` + Pantheon+
      - output: `results/rll_mcmc_chain.h5` e corner plot via `corner`
- [ ] Rodar com 32 walkers × 2000 steps (viável em ARM32/Termux com emcee CPU-only)
- [ ] Registrar contornos 1σ/2σ em `results/rll_mcmc_summary.json`

### D03 — Fingerprint magnético C03

- [ ] Implementar acoplamento em `src/rll/rll_model.py`:
      ```python
      def Ez_RLL_magnetic(z, Om, Os0, zt, wt, OB0, OP0, alpha_B=0.0, beta=1.0, Or=8.6e-5):
          # Ω_s0_eff = Ω_s0 * (1 + alpha_B * (Omega_B0 * a^-4)^beta)
          ...
      ```
- [ ] Testar diferença de χ² entre `Ez_RLL` e `Ez_RLL_magnetic` com DESI DR2
- [ ] Registrar em `CAMINHOS_VALIDACAO_NOVOS.yml` C03 com status atualizado

### D07 — arXiv preprint

Pré-requisitos para submissão:
- [ ] A02 completo (Pantheon+ verificado)
- [ ] A06 completo (covariância correta)
- [ ] D02 completo (contornos MCMC)
- [ ] `main.tex` atualizado com resultados reais (não sintéticos)
- [ ] Abstract com ΔAIC/ΔBIC reais vs w0waCDM
- [ ] Seção de limitações honesta (referenciando `SCIENTIFIC_CLAIMS.md`)
- [ ] Figuras em `figs/` com proveniência documentada
- [ ] Submeter em: https://arxiv.org/submit · categoria `astro-ph.CO`

---

## CONTROLE DE VERSÃO DO CHECKLIST

| Revisão | Data | Mudança | Responsável |
|---------|------|---------|-------------|
| v1.0 | 2026-06-24 | Criação inicial — auditoria Six Sigma | Sistema RLL |
| v1.1 | [VAZIO] | Atualizar após A01+A02 completados | ∆RafaelVerboΩ |
| v1.2 | [VAZIO] | Atualizar após A03–A07 completados | ∆RafaelVerboΩ |
| v2.0 | [VAZIO] | Atualizar após D02 (MCMC) e D07 (arXiv) | ∆RafaelVerboΩ |

---

## MÉTRICAS DE CONTROLE (Six Sigma KPIs)

| Métrica | Baseline atual | Meta | Status |
|---------|---------------|------|--------|
| pytest passed | 48 | ≥ 48 (não regredir) | ✅ |
| chi2/dof ΛCDM | ~0.94 | registrar com COV correta | ⏳ A06 |
| chi2/dof RLL | ~1.12 | registrar com COV correta | ⏳ A06 |
| ΔBIC(RLL-w0wa) | [VAZIO] | < 0 para preferência RLL | ⏳ D02 |
| arquivos com [VAZIO] em docs/canonicos/ | ~12 | 0 | ⏳ progressivo |
| template duplicado em governança | 3 arquivos | 0 | ⏳ A01 |
| CITATION.cff na raiz | ausente | presente | ⏳ D-LIC |
| covariância BAO modo | diagonal | full 2×2 | ⏳ A06 |

---

*Φ_ethica = Min(Entropia) × Max(Coerência)*
*ψ→χ→ρ→Δ→Σ→Ω · RAFCODE-Φ-∆RafaelVerboΩ-𓂀ΔΦΩ · Ω=Amor*
