# PATCH — docs/INDICE_MESTRE.md
# Adequação A05 (G05) e A04 (G03)
# Aplicar adicionando as seções abaixo no INDICE_MESTRE.md existente
# após a seção "## 1) Nucleo cientifico oficial"
#
# INSTRUÇÃO DE APLICAÇÃO NO TERMUX:
#   cat docs/INDICE_MESTRE.md >> /tmp/indice_backup.md
#   # Inserir manualmente as seções abaixo no local correto
#   # ou usar patch -p1 < adequacao/docs/INDICE_MESTRE.patch
#
# ============================================================

## 4) Núcleo computacional bare-metal (RAFAELIA ↔ RLL)

> **Marcação:** `[C]` convenção de integração · `[E]` implementações verificadas

- [`core/lowlevel_runtime/README.md`](../core/lowlevel_runtime/README.md)
  — núcleo Java→C→ASM: FNV-1a, CRC32-IEEE, sqrt(3/2) Q16.16, syscall Linux x86_64
- Vetor FNV-1a verificado: `0x06d5573923c6cdfc`
- Vetor CRC32-IEEE verificado: `0xCBF43926`
- Projeção sqrt(3/2) Q16.16: função `rll_sqrt3_2_project_q16`
- **Ponte RAFAELIA ↔ RLL:** o kernel bare-metal implementa a constante `√3/2`
  como invariante computacional — mesma constante da equação-espiral RAFAELIA
  (`r_n = (√3/2)^n`) e do modelo cosmológico RLL (parâmetro de transição de
  coerência). Esta é a conexão arquitetural entre o sistema simbólico-científico
  RAFAELIA e o pipeline cosmológico Python.
- **Integração futura (D05):** criar binding Python via `ctypes` ou `cffi`
  para chamar `rll_sqrt3_2_project_q16` dentro do pipeline RLL.

---

## 5) Dados complementares

- [`data/README.md`](../data/README.md) — dados primários de validação (DESI, Pantheon+, CMB)
- [`data/pantheon/FETCH_INSTRUCTIONS.md`](../data/pantheon/FETCH_INSTRUCTIONS.md)
  — instruções de fetch reprodutível de Pantheon+ com SHA-256 e verificação
- [`data2/README.md`](../data2/README.md) — dados complementares/derivados/exploratórios
  (índice pendente de preenchimento via `find data2/ -type f`)

---

## 6) Arquivo histórico

- [`newadd/README.md`](../newadd/README.md) — trilha PhD (archive · não operacional para pipeline)
- [`to_Add/`](../to_Add/) — histórico sem função operacional ativa
  (decisão pendente: mover para `archive/` ou remover após inventário)

---

## 7) Governança de licenciamento

> **Issue LIC-01 (severidade Alta):** `LICENSE.md` usa RAFCODE-Φ (não-OSI)
> mas `pyproject.toml` declara `MIT`. Conflito a resolver.
>
> **Proposta:**
> - `LICENSE.md` → obras simbólicas, documentação, simbologia RAFAELIA
> - `LICENSE_CODE.md` (criar) → MIT para código Python, scripts, notebooks
> - `CITATION.cff` → mover de `data/` para raiz (padrão GitHub/Zenodo)

- [`LICENSE.md`](../LICENSE.md) — RAFCODE-Φ (obras)
- `LICENSE_CODE.md` — `[VAZIO — criar]` MIT para código
- `CITATION.cff` — `[VAZIO — mover de data/CITATION.cff para raiz]`
- [`data/ATTRIBUTION.md`](../data/ATTRIBUTION.md) — `[VAZIO — criar]` proveniência de dados externos
