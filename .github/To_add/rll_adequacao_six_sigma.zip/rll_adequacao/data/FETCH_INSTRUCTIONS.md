# Pantheon+ — Instruções de Fetch e Verificação

**Status:** `[C]` procedimento de ingestão · `[E]` fontes primárias externas
**Mantido por:** Sistema RLL · `docs/canonicos/15_DADOS_EXTERNOS_REAIS_RLL.md`
**Norma:** FAIR (Wilkinson 2016) · W3C PROV-DM · NIST SP 800-53 (integridade de dados)

---

## 1. Fonte primária

| Item | Valor |
|------|-------|
| Repositório oficial | https://github.com/PantheonPlusSH0ES/DataRelease |
| Paper de referência | Scolnic et al. 2022, ApJ 938, 113 · doi:10.3847/1538-4357/ac8b7a |
| Brewer et al. 2022 | doi:10.3847/1538-4357/ac8935 (calibração) |
| Licença dos dados | CC-BY-4.0 (verificar no repositório oficial antes de redistribuir) |

## 2. Arquivo principal

```
lcparam_full_long_zhel.txt
```

Localização esperada após fetch:

```
data/pantheon/lcparam_full_long_zhel.txt
```

## 3. Comando de fetch reprodutível

```bash
# Opção A — wget direto (requer acesso à rede)
mkdir -p data/pantheon
wget -O data/pantheon/lcparam_full_long_zhel.txt \
  "https://raw.githubusercontent.com/PantheonPlusSH0ES/DataRelease/main/Pantheon%2B_Data/4_DISTANCES_AND_COVAR/Pantheon%2B.SH0ES.STAT%2BSYST.cov"

# Opção B — clone parcial (mais confiável)
git clone --depth 1 --filter=blob:none --sparse \
  https://github.com/PantheonPlusSH0ES/DataRelease.git /tmp/pantheon_release
cd /tmp/pantheon_release
git sparse-checkout set "Pantheon+_Data/4_DISTANCES_AND_COVAR/"
cp Pantheon+_Data/4_DISTANCES_AND_COVAR/lcparam_full_long_zhel.txt \
   $(git rev-parse --show-toplevel)/data/pantheon/

# Opção C — via Python (usado pelo pipeline rll_vs_lcdm.py)
python scripts/verify_pantheon_inputs.py --fetch --json
```

## 4. Verificação de integridade

Após o download, verificar:

```bash
python scripts/verify_pantheon_inputs.py --json
```

Saída esperada (`[VAZIO]` se hash não verificado ainda):

```json
{
  "file": "data/pantheon/lcparam_full_long_zhel.txt",
  "exists": true,
  "lines_expected": 1701,
  "sha256_expected": "[VAZIO — registrar após primeiro download verificado]",
  "status": "DECLARED_BY_AUTHOR"
}
```

> **Instrução para o mantenedor:** após o primeiro download bem-sucedido,
> calcular e registrar o hash SHA-256:
> ```bash
> sha256sum data/pantheon/lcparam_full_long_zhel.txt
> ```
> Substituir `[VAZIO]` acima pelo valor calculado e marcar `status: VERIFIED`.

## 5. Arquivos adicionais esperados

| Arquivo | Fonte | Uso no pipeline |
|---------|-------|----------------|
| `Pantheon+.SH0ES.STAT+SYST.cov` | mesmo repositório | covariância completa (χ² correto) |
| `desi_dr2_bao_primary_points.csv` | `data/real/cosmology/` | BAO DESI DR2 |
| `desi_dr2_bao_covariance_summary.csv` | `data/real/cosmology/` | covariância BAO 2×2 |
| `fsigma8_growth.csv` | `data/real/cosmology/` | crescimento estrutural |

## 6. Política de dados externos

- Dados externos **não são redistribuídos** neste repositório (respeitar licença da fonte).
- Este arquivo documenta **como obtê-los** de forma reprodutível.
- Todo resultado que depende de dados externos deve registrar versão, data de download e hash.
- Caso a fonte mude de URL, atualizar este arquivo e abrir issue com label `data-provenance`.

## 7. Desbloqueio do pipeline

Com `data/pantheon/lcparam_full_long_zhel.txt` presente, o pipeline completo
fica disponível:

```bash
# Validação completa Hz + BAO + Pantheon+ vs ΛCDM e w0waCDM
python rll_vs_lcdm.py \
  --adversary both \
  --with-bayes \
  --with-growth \
  --bao data/real/cosmology/desi_dr2_bao_primary_points.csv \
  --bao-covariance data/real/cosmology/desi_dr2_bao_covariance_summary.csv

# Saídas esperadas
# results/rll_model_comparison_summary.json
# results/rll_model_comparison_predictions.csv
```

## 8. Referências normativas

- Wilkinson et al. 2016 — FAIR Guiding Principles (doi:10.1038/sdata.2016.18)
- Peng 2011 — Reproducible Research in Computational Science (doi:10.1126/science.1213847)
- W3C PROV-DM — https://www.w3.org/TR/prov-dm/

---

*[VAZIO] → preenchido após primeiro fetch verificado · status: DECLARED_BY_AUTHOR*
*ψ→χ→ρ→Δ→Σ→Ω · RAFCODE-Φ-∆RafaelVerboΩ-𓂀ΔΦΩ*
