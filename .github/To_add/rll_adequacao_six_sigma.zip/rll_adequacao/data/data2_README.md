# data2/ — Índice de Dados Complementares

**Status:** `[C]` convencional · inventário pendente de verificação
**Relação:** `docs/INDICE_MESTRE.md` → seção `5) Dados complementares`
**Norma:** FAIR (Findability, Reusability) · NIST SP 800-53 (integridade)
**Atualizado:** 2026-06-24

---

## Função

`data2/` contém dados complementares ao diretório principal `data/`.
A distinção entre `data/` e `data2/` deve ser explicitada e mantida
para evitar duplicação silenciosa (Gap G03 identificado na auditoria Six Sigma).

---

## Política de separação data/ vs data2/

| Critério | `data/` | `data2/` |
|----------|---------|---------|
| Dados primários de validação | ✅ | ❌ |
| Dados observacionais DESI/Pantheon+/CMB | ✅ | ❌ |
| Dados sintéticos/mock | ✅ (marcados) | ✅ (marcados) |
| Dados intermediários / derivados | ❌ | ✅ |
| Dados de experimentos alternativos | ❌ | ✅ |
| Posteriors exploratórios | ❌ | ✅ |

> **Regra:** se um dado em `data2/` se tornar parte do pipeline oficial
> de validação, deve ser movido para `data/` com proveniência documentada.

---

## Inventário atual

> **[VAZIO — a verificar]** Executar o comando abaixo e preencher a tabela:
>
> ```bash
> find data2/ -type f | sort | while read f; do
>   echo "| \`$f\` | [VAZIO] | [VAZIO] |"
> done
> ```

| Arquivo | Tipo | Status de proveniência |
|---------|------|----------------------|
| *(executar comando acima para listar)* | — | `[VAZIO]` |

---

## Checklist de adequação FAIR

- [ ] Cada arquivo tem proveniência documentada (URL de origem ou script gerador)
- [ ] Arquivos sintéticos estão marcados como `synthetic` no nome ou em metadados
- [ ] Nenhum arquivo duplica exatamente conteúdo de `data/`
- [ ] Hashes SHA-256 registrados para arquivos > 1 MB
- [ ] Licença de dados externos verificada e documentada

---

## Comando de inventário automático

```bash
# Gerar inventário com hash e tamanho
python3 tools/docs_inventory.py --dir data2 --output docs/DATA2_INVENTORY.md
```

Se `tools/docs_inventory.py` não suportar `--dir`, usar:

```bash
find data2/ -type f -exec sha256sum {} \; | tee docs/DATA2_INTEGRITY_MANIFEST.txt
```

---

*[VAZIO] → preencher após `ls -la data2/` no Termux*
*ψ→χ→ρ→Δ→Σ→Ω · RAFCODE-Φ-∆RafaelVerboΩ-𓂀ΔΦΩ*
