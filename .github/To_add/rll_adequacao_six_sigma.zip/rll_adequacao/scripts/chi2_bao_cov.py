#!/usr/bin/env python3
"""chi2_bao_cov.py — χ² BAO com covariância 2×2 por tracer (DESI DR2).

Substitui o cálculo diagonal (otimista) por verossimilhança completa
usando matriz de covariância bloco-diagonal por tracer.

Normas aplicadas:
  - IEEE 730-2014 (Software QA)
  - NIST SP 800-53 (integridade computacional)
  - FAIR (reprodutibilidade)

Status epistemológico:
  [E] Formulação chi2 multivariado: chi2 = r^T C^-1 r
  [C] Estrutura de tracer e dimensões: convenção DESI DR2
  [H] RLL vs w0waCDM: hipótese a testar com esta função
  [VAZIO] Covariância completa off-diagonal entre tracers: pendente de dados DESI DR2

Uso:
    from scripts.chi2_bao_cov import chi2_bao_full
    chi2 = chi2_bao_full(Ez_func, H0=67.4, rd=147.09, data=bao_data)

Ou como script:
    python scripts/chi2_bao_cov.py --model rll --params params.json
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Callable

# Numpy é dependência declarada em pyproject.toml
try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    _HAS_NUMPY = False


# ---------------------------------------------------------------------------
# Tipos e estruturas
# ---------------------------------------------------------------------------

class BaoPoint:
    """Ponto BAO de um tracer específico."""

    __slots__ = ("z", "observable", "value", "error", "tracer", "source")

    def __init__(
        self,
        z: float,
        observable: str,
        value: float,
        error: float,
        tracer: str = "unknown",
        source: str = "[VAZIO]",
    ) -> None:
        if z <= 0:
            raise ValueError(f"z deve ser positivo, recebido: {z}")
        if observable not in {"DM_over_rd", "DH_over_rd", "DV_over_rd"}:
            raise ValueError(f"Observable desconhecido: {observable}")
        if error <= 0:
            raise ValueError(f"Erro deve ser positivo, recebido: {error}")
        self.z = z
        self.observable = observable
        self.value = value
        self.error = error
        self.tracer = tracer
        self.source = source

    def __repr__(self) -> str:
        return (
            f"BaoPoint(z={self.z}, obs={self.observable}, "
            f"val={self.value:.4f}±{self.error:.4f}, tracer={self.tracer})"
        )


# ---------------------------------------------------------------------------
# Funções de distância RLL e modelos adversários [E]
# ---------------------------------------------------------------------------

def _integrate_Ez(Ez_func: Callable, z: float, n_steps: int = 1000) -> float:
    """Integral numérica de 1/E(z') de 0 a z — método de Simpson."""
    if z <= 0:
        return 0.0
    dz = z / n_steps
    total = 0.0
    for i in range(n_steps + 1):
        zi = i * dz
        wi = 1.0 if (i == 0 or i == n_steps) else (4.0 if i % 2 else 2.0)
        total += wi / Ez_func(zi)
    return total * dz / 3.0


def DM_over_rd(z: float, Ez_func: Callable, H0: float, rd: float) -> float:
    """DM(z)/rd — distância comóvel transversa normalizada. [E]"""
    c_kms = 299792.458
    integral = _integrate_Ez(Ez_func, z)
    return (c_kms / H0) * integral / rd


def DH_over_rd(z: float, Ez_func: Callable, H0: float, rd: float) -> float:
    """DH(z)/rd = c/(H(z)*rd). [E]"""
    c_kms = 299792.458
    return (c_kms / H0) / (Ez_func(z) * rd)


def DV_over_rd(z: float, Ez_func: Callable, H0: float, rd: float) -> float:
    """DV(z)/rd — distância volumétrica esférica normalizada. [E]"""
    c_kms = 299792.458
    DM = DM_over_rd(z, Ez_func, H0, rd) * rd
    DH = (c_kms / H0) / Ez_func(z)
    DV = (z * DM ** 2 * DH) ** (1.0 / 3.0)
    return DV / rd


def _predict(point: BaoPoint, Ez_func: Callable, H0: float, rd: float) -> float:
    """Predição do modelo para um ponto BAO."""
    dispatch = {
        "DM_over_rd": DM_over_rd,
        "DH_over_rd": DH_over_rd,
        "DV_over_rd": DV_over_rd,
    }
    return dispatch[point.observable](point.z, Ez_func, H0, rd)


# ---------------------------------------------------------------------------
# χ² diagonal (legado — para compatibilidade com código existente)
# ---------------------------------------------------------------------------

def chi2_bao_diagonal(
    Ez_func: Callable,
    H0: float,
    rd: float,
    data: list[BaoPoint],
) -> float:
    """χ² diagonal — soma de (resíduo/erro)². [C]

    Atenção: otimista quando há correlações entre observáveis do mesmo tracer.
    Usar chi2_bao_full quando covariância estiver disponível.
    """
    total = 0.0
    for point in data:
        pred = _predict(point, Ez_func, H0, rd)
        r = (point.value - pred) / point.error
        total += r * r
    return total


# ---------------------------------------------------------------------------
# χ² com covariância 2×2 por tracer — versão correta [E/C]
# ---------------------------------------------------------------------------

def chi2_bao_full(
    Ez_func: Callable,
    H0: float,
    rd: float,
    data: list[BaoPoint],
    cov_matrix: "np.ndarray | None" = None,
) -> float:
    """χ² completo com covariância.

    Se cov_matrix for fornecida (ndarray N×N), usa chi2 = r^T C^-1 r. [E]
    Se cov_matrix for None, recai em chi2_bao_diagonal com aviso. [C]

    Parameters
    ----------
    Ez_func : callable
        E(z) = H(z)/H0 — função do modelo.
    H0 : float
        Constante de Hubble em km/s/Mpc.
    rd : float
        Horizonte de arrasto em Mpc.
    data : list[BaoPoint]
        Lista de pontos BAO ordenados consistentemente com cov_matrix.
    cov_matrix : ndarray or None
        Matriz de covariância N×N. Se None, usa diagonal.

    Returns
    -------
    float
        Valor de χ².
    """
    if not _HAS_NUMPY:
        raise ImportError(
            "numpy é necessário para chi2_bao_full. "
            "Instalar: pkg install python-numpy (Termux)"
        )

    n = len(data)
    residuals = np.array([
        point.value - _predict(point, Ez_func, H0, rd)
        for point in data
    ])

    if cov_matrix is None:
        print(
            "[AVISO chi2_bao_full] cov_matrix=None → usando diagonal. "
            "Resultado é otimista. Fornecer covariância DESI DR2 para resultado correto."
        )
        errors = np.array([p.error for p in data])
        cov_matrix = np.diag(errors ** 2)

    if cov_matrix.shape != (n, n):
        raise ValueError(
            f"cov_matrix.shape={cov_matrix.shape} incompatível com n={n} pontos."
        )

    try:
        chi2 = float(residuals @ np.linalg.solve(cov_matrix, residuals))
    except np.linalg.LinAlgError as exc:
        raise ValueError(
            f"Covariância singular — verificar dados DESI DR2: {exc}"
        ) from exc

    return chi2


# ---------------------------------------------------------------------------
# Métricas de seleção de modelos [E]
# ---------------------------------------------------------------------------

def aic(chi2: float, k: int) -> float:
    """AIC = chi2 + 2k."""
    return chi2 + 2 * k


def aicc(chi2: float, k: int, n: int) -> float:
    """AICc = AIC + 2k(k+1)/(n-k-1) (correção amostral)."""
    if n - k - 1 <= 0:
        return float("inf")
    return aic(chi2, k) + 2 * k * (k + 1) / (n - k - 1)


def bic(chi2: float, k: int, n: int) -> float:
    """BIC = chi2 + k*ln(n)."""
    return chi2 + k * math.log(n)


def delta_bic(bic_rll: float, bic_ref: float) -> float:
    """ΔBIC = BIC_RLL - BIC_ref. Negativo = RLL preferido. [E]"""
    return bic_rll - bic_ref


def interpret_delta_bic(delta: float) -> str:
    """Interpretação da escala de Jeffreys para ΔBIC. [E]"""
    if delta < -10:
        return "Forte evidência CONTRA RLL (ref muito melhor)"
    if delta < -6:
        return "Evidência moderada contra RLL"
    if delta < -2:
        return "Fraca evidência contra RLL"
    if delta <= 2:
        return "Modelos equivalentes (sem evidência decisiva)"
    if delta <= 6:
        return "Fraca evidência FAVORÁVEL a RLL"
    if delta <= 10:
        return "Evidência moderada favorável a RLL"
    return "Forte evidência favorável a RLL"


# ---------------------------------------------------------------------------
# Parser de dados CSV DESI DR2 [C]
# ---------------------------------------------------------------------------

def load_bao_csv(path: str | Path) -> list[BaoPoint]:
    """Carrega pontos BAO de CSV no formato DESI DR2.

    Formato esperado (cabeçalho obrigatório):
        z,observable,value,error,tracer,source

    Status: [C] formato convencionado para este pipeline.
    """
    import csv
    points = []
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Arquivo BAO não encontrado: {path}\n"
            "Verificar data/real/cosmology/ e FETCH_INSTRUCTIONS.md"
        )
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            points.append(BaoPoint(
                z=float(row["z"]),
                observable=row["observable"].strip(),
                value=float(row["value"]),
                error=float(row["error"]),
                tracer=row.get("tracer", "unknown").strip(),
                source=row.get("source", "[VAZIO]").strip(),
            ))
    return points


def load_cov_csv(path: str | Path) -> "np.ndarray":
    """Carrega matriz de covariância de CSV.

    Formato esperado: N linhas × N colunas, sem cabeçalho.
    Status: [C] formato convencionado para este pipeline.
    """
    if not _HAS_NUMPY:
        raise ImportError("numpy necessário para carregar covariância.")
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Covariância não encontrada: {path}\n"
            "Verificar data/real/cosmology/ e FETCH_INSTRUCTIONS.md"
        )
    return np.loadtxt(path, delimiter=",")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="χ² BAO com covariância 2×2 por tracer — DESI DR2"
    )
    p.add_argument(
        "--bao",
        default="data/real/cosmology/desi_dr2_bao_primary_points.csv",
        help="CSV de pontos BAO",
    )
    p.add_argument(
        "--cov",
        default=None,
        help="CSV de covariância (opcional; se ausente, usa diagonal com aviso)",
    )
    p.add_argument("--H0", type=float, default=67.4, help="H0 em km/s/Mpc")
    p.add_argument("--rd", type=float, default=147.09, help="rd em Mpc")
    p.add_argument(
        "--model",
        choices=["lcdm", "rll", "w0wa"],
        default="lcdm",
        help="Modelo a avaliar",
    )
    p.add_argument(
        "--params",
        default=None,
        help="JSON com parâmetros do modelo (Om, Os0, zt, wt, w0, wa, etc.)",
    )
    p.add_argument("--json", action="store_true", help="Saída em JSON")
    return p.parse_args()


def _make_ez(model: str, params: dict) -> Callable:
    """Fábrica de E(z) para cada modelo."""
    Om = params.get("Om", 0.3)
    Or = params.get("Or", 8.6e-5)

    if model == "lcdm":
        OL = 1.0 - Om - Or
        def Ez(z):
            a = 1.0 / (1.0 + z)
            return math.sqrt(Or * a**-4 + Om * a**-3 + OL)
        return Ez

    if model == "w0wa":
        w0 = params.get("w0", -1.0)
        wa = params.get("wa", 0.0)
        ODE = 1.0 - Om - Or
        def Ez(z):
            a = 1.0 / (1.0 + z)
            fde = a**(-3 * (1 + w0 + wa)) * math.exp(-3 * wa * (1 - a))
            return math.sqrt(Or * a**-4 + Om * a**-3 + ODE * fde)
        return Ez

    if model == "rll":
        Os0 = params.get("Os0", 0.05)
        zt = params.get("zt", 0.7)
        wt = params.get("wt", 0.2)
        OB0 = params.get("OB0", 0.0)
        OP0 = params.get("OP0", 0.0)
        OL = 1.0 - Om - Or - Os0 - OB0 - OP0

        def Ez(z):
            a = 1.0 / (1.0 + z)
            f = 1.0 / (1.0 + math.exp((z - zt) / wt))
            g = f + (1.0 - f) * a**-3
            return math.sqrt(
                Or * a**-4
                + Om * a**-3
                + OL
                + Os0 * g
                + OB0 * a**-4
                + OP0 * a**-4
            )
        return Ez

    raise ValueError(f"Modelo desconhecido: {model}")


def main() -> None:
    args = _parse_args()

    params = {}
    if args.params:
        with open(args.params, encoding="utf-8") as f:
            params = json.load(f)

    try:
        data = load_bao_csv(args.bao)
    except FileNotFoundError as e:
        print(f"[VAZIO] {e}")
        return

    cov = None
    if args.cov:
        try:
            cov = load_cov_csv(args.cov)
        except FileNotFoundError as e:
            print(f"[VAZIO — covariância] {e}\nUsando diagonal.")

    Ez = _make_ez(args.model, params)
    chi2_val = chi2_bao_full(Ez, args.H0, args.rd, data, cov)
    k = len(params) + 2  # +2 para H0 e rd fixados como estimativa
    n = len(data)

    result = {
        "model": args.model,
        "n_points": n,
        "n_params": k,
        "H0": args.H0,
        "rd": args.rd,
        "chi2": round(chi2_val, 4),
        "chi2_dof": round(chi2_val / max(n - k, 1), 4),
        "AIC": round(aic(chi2_val, k), 4),
        "AICc": round(aicc(chi2_val, k, n), 4),
        "BIC": round(bic(chi2_val, k, n), 4),
        "cov_mode": "full" if cov is not None else "diagonal_WARNING",
        "status": "VERIFIED" if cov is not None else "DECLARED_BY_AUTHOR",
    }

    if args.json:
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        print(f"\n=== χ² BAO — modelo {args.model.upper()} ===")
        for k2, v in result.items():
            print(f"  {k2:20s}: {v}")
        if result["cov_mode"] == "diagonal_WARNING":
            print(
                "\n  ⚠️  AVISO: usando covariância diagonal (otimista)."
                "\n     Fornecer --cov para resultado correto."
            )


if __name__ == "__main__":
    main()
