# newadd/ — Trilha PhD e Arquivos de Referência

**Status:** `archive` · não operacional para o pipeline de validação principal
**Relação:** `docs/INDICE_MESTRE.md` → seção `4) Arquivo histórico`
**Norma:** FAIR (Acessibilidade) · RAW_TEXT_FIRST (`docs/canonicos/13_EPISTEMOLOGIA_RAFAELIA_RLL.md`)

---

## Finalidade

Este diretório preserva materiais de referência produzidos durante o desenvolvimento
da trilha de pesquisa PhD associada ao projeto RLL. O conteúdo é histórico e
funciona como arquivo de anterioridade, não como fonte canônica de dados ou pipeline.

**Regra de uso:** nenhum script ou notebook de validação deve importar diretamente
de `newadd/`. Para dados ativos, usar `data/` e `src/rll/`.

---

## Conteúdo esperado

| Arquivo/Dir | Descrição | Status |
|-------------|-----------|--------|
| `00_intro.md` | Introdução à trilha PhD RLL | `[VAZIO — verificar presença]` |
| `01_*.md` | Módulo 01 da trilha | `[VAZIO — verificar presença]` |
| `02_*.md` | Módulo 02 da trilha | `[VAZIO — verificar presença]` |
| `03_*.md` | Módulo 03 da trilha | `[VAZIO — verificar presença]` |

> **Instrução para o mantenedor:** executar `ls -la newadd/` no Termux e atualizar
> a tabela acima com os nomes reais dos arquivos, datas de criação e hashes SHA-256
> correspondentes. Substituir `[VAZIO]` por `VERIFIED` após verificação.

---

## Relação com o pipeline principal

```
newadd/ (arquivo histórico / referência)
    ↓ não alimenta diretamente
src/rll/ (código operacional)
data/    (dados verificados)
results/ (saídas do pipeline)
```

---

## Como referenciar este conteúdo

Se um documento em `newadd/` contiver uma afirmação relevante para o pipeline
científico, o procedimento correto é:

1. Localizar a afirmação no arquivo original (RAW_TEXT).
2. Classificá-la com `[E]`, `[C]`, `[H]` ou `[VAZIO]`.
3. Criar entrada correspondente em `rll_equation_registry.yml` com `source_doc`
   apontando para o arquivo em `newadd/`.
4. Não copiar/reescrever o conteúdo original — referenciar.

---

## Epistemologia aplicada

- Conteúdo histórico: `[E]` — preservado sem alteração.
- Interpretações posteriores: `[C]` — marcadas como convenção editorial.
- Promoção a evidência: somente via pipeline com dado rastreável.

---

*TOKEN_VAZIO → preenchido após verificação com `ls -la newadd/`*
*ψ→χ→ρ→Δ→Σ→Ω · RAFCODE-Φ-∆RafaelVerboΩ-𓂀ΔΦΩ*
