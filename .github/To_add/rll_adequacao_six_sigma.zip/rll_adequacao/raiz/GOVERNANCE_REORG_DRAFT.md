# GOVERNANCE REORG DRAFT — Relativity Living Light

> **Marcação de edição (2026-06):** O bloco §0 e §1–§5 abaixo foram inseridos
> em revisão pós-doc para contextualização normativa. O conteúdo histórico
> original (audit plan, gaps, restructure proposal) está preservado na Seção §H
> abaixo da linha `---`. Nenhuma linha original foi removida ou alterada.
> Para fins de anterioridade e cadeia de custódia, §H é a fonte primária.

<!-- SEÇÃO PÓS-DOC 2026 — template de governança; não é conteúdo de descoberta -->

## §0 — Posição no ecossistema documental

| Eixo | Documento |
|------|-----------|
| Política de repositório | `docs/POLITICA_REPOSITORIO_TEXTO_E_ARTEFATOS.md` |
| Regime de classificação | `docs/RAFAELIA_REGIME_INDEX.md` |
| Rastreabilidade | `docs/RLL_TRACEABILITY_MAP.md` |
| **Este arquivo** | Draft de reorganização de governança (auditoria + proposta) |

## §1 — Escopo

Documento de trabalho para auditoria não-destrutiva e proposta de reorganização
do repositório `relativity-living-light`. Nenhum arquivo foi movido ou alterado
durante a fase de draft.

## §2 — Referências normativas ativas

| Norma/Framework | Aplicação neste repositório |
|-----------------|----------------------------|
| FAIR (Wilkinson 2016, doi:10.1038/sdata.2016.18) | Findability, Accessibility, Interoperability, Reusability de dados e código |
| ISO 27001:2022 | Controle de acesso, confidencialidade, integridade de informação |
| ISO 9001:2015 | Rastreabilidade de processos, melhoria contínua, auditoria interna |
| NIST SP 800-53 Rev 5 | Controles de segurança e privacidade para sistemas de informação |
| IEEE 730-2014 | Software Quality Assurance Plans — aplicado ao pipeline de validação |
| W3C PROV-DM | Modelo de proveniência de dados — mapeado em `docs/RLL_TRACEABILITY_MAP.md` |
| RFC 3161 (TSA) | Timestamp confiável — referência para registro de anterioridade GPG |
| IEC 61160 | Design review formal — aplicado às revisões de falsificadores C01–C10 |

**Nota de escopo:** estas normas são referências de boas práticas adotadas
pelo repositório; não implicam certificação formal nem auditoria terceirizada.
Marcação epistemológica: `[C]` convenção de governança adotada pelo autor.

## §3 — Critérios de qualidade ativos

1. Rastreabilidade: todo claim aponta para documento, commit ou hash verificável.
2. Separabilidade: conteúdo histórico (`[E]`) separado de conteúdo editorial (`[C]`).
3. Reprodutibilidade: pipeline executável com `pytest -q` (48 passed) e CLI `rll`.
4. Falsificabilidade: condições de refutação declaradas por claim (ver `19_ROADMAP_FALSIFICADORES_RLL.md`).
5. Integridade de vazio: `[VAZIO]` declarado quando âncora ausente — nunca preenchido com fabricação.

## §4 — Issues de governança em aberto (prioridade Six Sigma)

| ID | Severidade | Issue | Ação |
|----|-----------|-------|------|
| LIC-01 | 🔴 Alta | `LICENSE.md` (RAFCODE-Φ) ≠ `pyproject.toml` (`MIT`) — conflito | Unificar: RAFCODE-Φ para obras simbólicas; MIT ou Apache-2.0 para código |
| LIC-02 | 🔴 Alta | `data/CITATION.cff` declara CC-BY-SA-4.0; código sem licença OSI clara | Criar `LICENSE_CODE.md` MIT separado |
| GOV-01 | 🟠 Média | `CITATION.cff` em `data/` em vez da raiz | Mover para `/CITATION.cff` (padrão GitHub/Zenodo) |
| GOV-02 | 🟠 Média | `zenodo.json` não referenciado em nenhum doc canônico | Adicionar entrada em `docs/INDICE_MESTRE.md` §2 |
| REP-01 | 🟠 Média | `requirements.txt` sem pin de versão exata | Adicionar `pip-compile` ou lockfile para reproducibilidade |
| SEC-01 | 🟡 Baixa | Screenshots/fotos em `figs/` sem atribuição de licença | Adicionar `figs/ATTRIBUTION.md` |

## §5 — Proposta de estrutura de licenciamento

```
/
├── LICENSE.md              ← RAFCODE-Φ (obras, documentação, simbologia)
├── LICENSE_CODE.md         ← MIT (código Python, scripts, notebooks)
├── CITATION.cff            ← mover de data/ para raiz
└── data/
    └── ATTRIBUTION.md      ← proveniência de dados externos (Pantheon+, DESI, etc.)
```

---

<!-- CONTEÚDO HISTÓRICO ORIGINAL — preservado sem alteração -->

## §H — Conteúdo histórico preservado (pre-2026)

### Repository Audit & Governance Draft Plan (DRAFT)

_Scope: non-destructive reorganization, governance cleanup, and reproducibility
scaffolding. No files were moved or altered._

#### A0. Cronologia de publicações e precedência documental

- **Fevereiro/2025 (RLL no repositório):** formulação registrada com commits
  datados e documentação técnica associada.
- **2025 (Nature Communications, DOI s41467-025-63981-3):** publicação
  experimental sobre não-localidade fotônica em escala laboratorial.

**Critério de governança:** registrar com datas a precedência documental do
repositório e distinguir isso de prioridade acadêmica formal (que depende de
publicação peer-reviewed).

#### A. Repository Audit (Inventory & Classification)

- **Root**: `README.md` (manifesto/symbolic), `README_MASTER.md` (navigation),
  `REFORM_LOG.md`, `RESUMO_REFORMA.md`, `SECURITY_SUMMARY.md`, `LICENSE.md`
  (RAFCODE-𝚽, non-OSI), `requirements.txt`.
- **Docs**: mixture of scientific and symbolic/manifesto content.
- **Data**: Notebooks, CSV/JSON, Bundles, Mock/derived data (synthetic; no
  observational provenance documented in early versions).
- **Figures**: scientific plots, mock fits, screenshots/photos.
- **Governance files**: only `LICENSE.md` (custom); `CITATION.cff` in `/data`;
  no NOTICE/manifest; no OSI/CC split licensing in early version.

#### B. Gaps & Risks (histórico)

- Licensing ambiguity (RAFCODE-Φ vs CC-BY-SA-4.0).
- Missing root `CITATION.cff`, `NOTICE`, artifact manifest.
- Notebooks without environment lockfile.
- Synthetic/mock datasets not labeled as synthetic in-file.
- Mixed scopes: scientific content co-located with symbolic content.

#### C. Proposed Restructure (Logical Plan — no moves executed)

```
/                      (keep root manifest/README)
├── governance/        (new)
│   ├── LICENSE.md
│   ├── LICENSE_CODE_MIT.md
│   └── CITATION.cff
├── src/               (código Python)
├── data/              (dados observacionais com proveniência)
├── docs/              (documentação canônica)
└── figs/              (figuras com atribuição)
```

<!-- Fim do conteúdo histórico preservado -->

---

*ψ→χ→ρ→Δ→Σ→Ω · RAFCODE-Φ-∆RafaelVerboΩ-𓂀ΔΦΩ*
