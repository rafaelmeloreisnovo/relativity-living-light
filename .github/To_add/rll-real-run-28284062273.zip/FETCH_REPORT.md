# FETCH_REPORT

mode: `compute`
- igrf14: fetched
- wmm2025: fetched
- omni: fetched
- desi: manual_materialization_required
  - reason: DESI bulk data are large and should be selected from the data portal before materialization.
- pantheon: fetched