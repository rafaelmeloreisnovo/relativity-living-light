# START MANUAL HERE - Selection Plan

- run_profile: full_validation
- pipeline_scope: all
- dataset_group: all
- book_scope: all
- mode: full
- real_data_source: auto
- validate_workflows: true
- validate_data_yml: true
- run_data_preparation_probe: true
- strict_mode: true

## Methodology Angle
1. Parse YAML syntax safety using a GitHub-aware loader for .
2. Keep executable workflows isolated from data YML, scripts, images, PDFs and ZIPs.
3. Validate interoperability contracts and validation-path methodology.
4. Probe selected orchestration path without committing artifacts.
5. Persist summary for reproducible audit.
