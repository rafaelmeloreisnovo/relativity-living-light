# Methodology Summary

This run formalized YAML and pipeline selection with explicit controls:
- Scope: all
- Book scope: all
- Dataset group: all
- Mode: full
- Profile: full_validation

Output probe path:
- artifacts/manual-start/probe

Validation-path methodology file:
- docs/pipelines/validation_paths/CAMINHOS_VALIDACAO_NOVOS.yml

Real-validation executable bundle:
- validacao_real/

This supports reproducibility and clearer run selection semantics.
