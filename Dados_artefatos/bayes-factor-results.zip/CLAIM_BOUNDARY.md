# Claim Boundary

- Canonical workflow policy: \
- Boundary: Real-data auxiliary workflow only; outputs cannot validate RLL, cosmology, superiority, or non-synthetic status beyond the explicit checks in this run.
- Synthetic boundary: mock, synthetic, demo, fixture, example, placeholder, and generated test payloads must not be promoted as real observational evidence.
