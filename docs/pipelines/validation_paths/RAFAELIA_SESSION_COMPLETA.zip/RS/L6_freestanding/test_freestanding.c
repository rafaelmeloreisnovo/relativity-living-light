/*
 * test_freestanding.c — testa raf_morphcode.h com libc mínima
 * Compila com: gcc -O2 -march=native test_freestanding.c -o test_fs
 */
#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include "raf_morphcode.h"

/* VecRec simulado */
typedef struct __attribute__((packed, aligned(32))) {
    float v3[3]; float inv_norm;
    uint64_t id; uint32_t layer; uint32_t doc_ref;
} VecRec;

#define N_RECS 100000
static VecRec recs[N_RECS];

/* init Newton-Raphson rsqrt sem sqrtf */
static float fast_inv_norm3(const float v[3]) {
    float s = v[0]*v[0]+v[1]*v[1]+v[2]*v[2];
    if (s < 1e-12f) return 0.0f;
    float r = 1.0f;
    r = r*(1.5f - 0.5f*s*r*r);
    r = r*(1.5f - 0.5f*s*r*r);
    r = r*(1.5f - 0.5f*s*r*r);
    r = r*(1.5f - 0.5f*s*r*r);
    return r;
}

int main(void) {
    printf("=== RAFAELIA Freestanding Test ===\n");
    printf("Arch: %s  Cap: 0x%02X\n", MC_ARCH_NAME, MC_CAPABILITY_BITS);

    /* seed recs com padrão Fibonacci-Rafael */
    for (int i = 0; i < N_RECS; i++) {
        recs[i].v3[0] = (float)(i % 100) / 100.0f - 0.5f;
        recs[i].v3[1] = (float)((i*7)%100)/100.0f - 0.5f;
        recs[i].v3[2] = (float)((i*13)%100)/100.0f - 0.5f;
        recs[i].inv_norm = fast_inv_norm3(recs[i].v3);
        recs[i].id = (uint64_t)i;
        recs[i].layer = (uint32_t)(i % 8);
        recs[i].doc_ref = (uint32_t)i;
    }

    /* query */
    float q[3] = {0.577f, 0.577f, 0.577f};
    float inv_q = fast_inv_norm3(q);

    /* benchmark: 10 rounds */
    struct timespec t0, t1;
    long best_ns = (long)2e9;
    int best_idx = -1; float best_score = -2.0f;

    for (int round = 0; round < 10; round++) {
        clock_gettime(CLOCK_MONOTONIC, &t0);
        /* cosine search scalar */
        for (int i = 0; i < N_RECS; i++) {
            float dot = recs[i].v3[0]*q[0]+recs[i].v3[1]*q[1]+recs[i].v3[2]*q[2];
            float s = dot * inv_q * recs[i].inv_norm;
            if (s > best_score) { best_score = s; best_idx = i; }
        }
        clock_gettime(CLOCK_MONOTONIC, &t1);
        long ns = (t1.tv_sec-t0.tv_sec)*1000000000L+(t1.tv_nsec-t0.tv_nsec);
        if (ns < best_ns) best_ns = ns;
    }

    long ns_per = best_ns / N_RECS;
    printf("Search %d recs: best=%ldns total / %ldns per-rec\n",
           N_RECS, best_ns, ns_per);
    printf("Target: <594ns/rec | Got: %ldns | %s\n",
           ns_per, ns_per < 594 ? "PASS" : "NEEDS_NEON");
    printf("Best: idx=%d score=%.4f\n", best_idx, best_score);

    /* test CRC32C */
    uint32_t crc = 0xFFFFFFFF;
    MC_CRC32C_W(crc, 0x52414641u); /* 'RAFA' */
    printf("CRC32C('RAFA') = 0x%08X\n", crc ^ 0xFFFFFFFFu);

    /* test watchdog */
    MC_WD_INIT(5);
    int ticks = 0;
    while (MC_WD_ALIVE) { MC_WD_TICK; ticks++; }
    printf("Watchdog: %d ticks (expected 5)\n", ticks);

    /* test checkpoint */
    static MCCheckpoint cp;
    MC_CHECKPOINT_INIT(&cp);
    MC_CHECKPOINT_SAVE(&cp, 1L, 2L, 3L, 4L);
    printf("Checkpoint valid: %s guard: 0x%08X seq: %u\n",
           MC_CHECKPOINT_VALID(&cp) ? "YES" : "NO",
           cp.guard, cp.seq);

    printf("=== Ω=Amor · FIAT LUX ===\n");
    return 0;
}
