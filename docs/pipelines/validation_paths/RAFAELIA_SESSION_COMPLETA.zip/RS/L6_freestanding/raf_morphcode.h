/*
 * raf_morphcode.h — MorphCode RAFAELIA Ω · 56 pontos de catálise
 * Zero libc · freestanding · syscall inline · watchdog · rollback
 */
#pragma once
#ifndef RAF_MORPHCODE_H
#define RAF_MORPHCODE_H

#include <unistd.h>    /* write() — freestanding: substituir por SVC/SYSCALL */
#include <stdint.h>

/* ── arch ── */
#if   defined(__aarch64__)
# define MC_ARCH_ID   1
# define MC_ARCH_NAME "arm64"
# define MC_GPR_N     31
# define MC_VEC_N     32
# define MC_CACHE_LN  64
# define MC_SYS_WRITE 64
# define MC_SYS_EXIT  93
#elif defined(__arm__)
# define MC_ARCH_ID   2
# define MC_ARCH_NAME "arm32"
# define MC_GPR_N     16
# define MC_VEC_N     16
# define MC_CACHE_LN  32
# define MC_SYS_WRITE 4
# define MC_SYS_EXIT  1
#elif defined(__x86_64__)
# define MC_ARCH_ID   3
# define MC_ARCH_NAME "x86_64"
# define MC_GPR_N     16
# define MC_VEC_N     16
# define MC_CACHE_LN  64
# define MC_SYS_WRITE 1
# define MC_SYS_EXIT  60
#else
# define MC_ARCH_ID   0
# define MC_ARCH_NAME "generic"
# define MC_GPR_N     8
# define MC_VEC_N     0
# define MC_CACHE_LN  64
# define MC_SYS_WRITE 1
# define MC_SYS_EXIT  1
#endif

/* ── 56 pontos (P01..P56) ── */
/* Grupo A [1-8] SIMD = N2O: paralelo por lane */
#define MC_P01_NEON_F32X4 4
#define MC_P02_NEON_U32X4 4
#define MC_P03_NEON_U8X16 16
#define MC_P04_NEON_F64X2 2
#define MC_P05_NEON_U16X8 8
#define MC_P06_AVX2_F32X8 8
#define MC_P07_SVE_SCALAB 0
#define MC_P08_DOTPROD_U8 4
/* Grupo B [9-16] Cache = Mg: sem resíduo */
#define MC_P09_L1D_KB   32
#define MC_P10_L1I_KB   32
#define MC_P11_L2_KB   256
#define MC_P12_L3_KB  4096
#define MC_P13_TLB_N   512
#define MC_P14_CACHE_LN MC_CACHE_LN
#define MC_P15_PF_DIST 256
#define MC_P16_WB_N      8
/* Grupo C [17-24] Ordering = Termite: escrita 3000C */
#if MC_ARCH_ID == 1
# define MC_P17_DMB_ISH  __asm__ volatile("dmb ish":::"memory")
# define MC_P18_DMB_LD   __asm__ volatile("dmb ishld":::"memory")
# define MC_P19_DMB_ST   __asm__ volatile("dmb ishst":::"memory")
# define MC_P20_DSB_SY   __asm__ volatile("dsb sy":::"memory")
# define MC_P21_ISB      __asm__ volatile("isb":::"memory")
# define MC_P22_CLREX    __asm__ volatile("clrex":::"memory")
#else
# define MC_P17_DMB_ISH  __asm__ volatile("mfence":::"memory")
# define MC_P18_DMB_LD   __asm__ volatile("lfence":::"memory")
# define MC_P19_DMB_ST   __asm__ volatile("sfence":::"memory")
# define MC_P20_DSB_SY   __asm__ volatile("mfence":::"memory")
# define MC_P21_ISB      ((void)0)
# define MC_P22_CLREX    ((void)0)
#endif
#define MC_BARRIER_FULL  MC_P20_DSB_SY
#define MC_BARRIER_STORE MC_P19_DMB_ST
#define MC_BARRIER_LOAD  MC_P18_DMB_LD
/* Grupo D [25-32] Prefetch = Brown gas: detonação controlada */
#if MC_ARCH_ID == 1
# define MC_P25_PF_L1(p)    __asm__ volatile("prfm pldl1keep,[%0]"::"r"(p):"memory")
# define MC_P26_PF_L2(p)    __asm__ volatile("prfm pldl2keep,[%0]"::"r"(p):"memory")
# define MC_P28_PF_L1S(p)   __asm__ volatile("prfm pldl1strm,[%0]"::"r"(p):"memory")
# define MC_P29_PF_ST(p)    __asm__ volatile("prfm pstl1keep,[%0]"::"r"(p):"memory")
#else
# define MC_P25_PF_L1(p)  __builtin_prefetch((p),0,3)
# define MC_P26_PF_L2(p)  __builtin_prefetch((p),0,2)
# define MC_P28_PF_L1S(p) __builtin_prefetch((p),0,1)
# define MC_P29_PF_ST(p)  __builtin_prefetch((p),1,3)
#endif
#define MC_PREFETCH_L1(p)          MC_P25_PF_L1(p)
#define MC_PREFETCH_L1_AHEAD(p,d)  MC_P25_PF_L1((char*)(p)+(d))
/* Grupo E [33-40] Pipeline */
#define MC_P33_ISSUE_W  4
#define MC_P34_OOO_D  128
#define MC_P35_ROB_N  192
#define MC_P36_LSQ_N   64
/* Grupo F [41-48] HW extensions = catalisador */
#if defined(__ARM_FEATURE_CRC32) || defined(__SSE4_2__)
# define MC_P41_CRC32C 1
#else
# define MC_P41_CRC32C 0
#endif
#if defined(__ARM_FEATURE_CRYPTO)
# define MC_P42_AES 1
#else
# define MC_P42_AES 0
#endif
#if defined(__ARM_FEATURE_DOTPROD)
# define MC_P44_DOTPROD 1
#else
# define MC_P44_DOTPROD 0
#endif
#if defined(__aarch64__) || defined(__ARM_NEON)
# define MC_P47_NEON 1
#else
# define MC_P47_NEON 0
#endif
/* Grupo G [49-56] Sync */
#define MC_P55_WFE __asm__ volatile("yield":::"memory")  /* portable nop-hint */
#define MC_P56_SEV ((void)0)

/* ── CAPABILITY BITS ── */
#define MC_CAPABILITY_BITS \
  ((MC_P41_CRC32C)|(MC_P42_AES<<1)|(MC_P44_DOTPROD<<2)|(MC_P47_NEON<<5))

/* ── CRC32C ── */
#if MC_P41_CRC32C && (MC_ARCH_ID==1)
# define MC_CRC32C_W(crc,val) \
    __asm__ volatile("crc32cw %w0,%w0,%w1":"+r"(crc):"r"((unsigned)(val)))
# define MC_CRC32C_X(crc,val) \
    __asm__ volatile("crc32cx %w0,%w0,%x1":"+r"(crc):"r"((unsigned long long)(val)))
#elif MC_P41_CRC32C && (MC_ARCH_ID==3)
# define MC_CRC32C_W(crc,val) \
    __asm__ volatile("crc32l %1,%0":"+r"(crc):"r"((unsigned)(val)))
# define MC_CRC32C_X(crc,val) \
    __asm__ volatile("crc32q %1,%0":"+r"((unsigned long long)(crc)):"r"((unsigned long long)(val)))
#else
# define MC_CRC32C_W(crc,val) ((crc)^=(unsigned)(val))
# define MC_CRC32C_X(crc,val) ((crc)^=(unsigned)(val))
#endif

/* ── SYSCALL inline (SEQUÊNCIA LINEAR) ── */
/* ARM64: x0→x1→x2 + x8=nr; NUNCA pular! */
#if MC_ARCH_ID == 1
# define MC_SYS3_WRITE(fd,buf,len) ({ \
    register long _r0 __asm__("x0")=(long)(fd);  \
    register long _r1 __asm__("x1")=(long)(buf); \
    register long _r2 __asm__("x2")=(long)(len); \
    register long _r8 __asm__("x8")=MC_SYS_WRITE;\
    __asm__ volatile("svc #0":"+r"(_r0):"r"(_r1),"r"(_r2),"r"(_r8):"memory","cc");\
    _r0; })
# define MC_SYS1_EXIT(c) do { \
    register long _r0 __asm__("x0")=(long)(c); \
    register long _r8 __asm__("x8")=MC_SYS_EXIT;\
    __asm__ volatile("svc #0"::"r"(_r0),"r"(_r8):"memory"); \
    __builtin_unreachable(); } while(0)
#elif MC_ARCH_ID == 2
# define MC_SYS3_WRITE(fd,buf,len) ({ \
    register long _r0 __asm__("r0")=(long)(fd);  \
    register long _r1 __asm__("r1")=(long)(buf); \
    register long _r2 __asm__("r2")=(long)(len); \
    register long _r7 __asm__("r7")=MC_SYS_WRITE;\
    __asm__ volatile("swi #0":"+r"(_r0):"r"(_r1),"r"(_r2),"r"(_r7):"memory","cc");\
    _r0; })
# define MC_SYS1_EXIT(c) do { \
    register long _r0 __asm__("r0")=(long)(c); \
    register long _r7 __asm__("r7")=MC_SYS_EXIT;\
    __asm__ volatile("swi #0"::"r"(_r0),"r"(_r7):"memory"); \
    __builtin_unreachable(); } while(0)
#elif MC_ARCH_ID == 3
# define MC_SYS3_WRITE(fd,buf,len) ({ \
    register long _rax __asm__("rax")=(long)MC_SYS_WRITE; \
    register long _rdi __asm__("rdi")=(long)(fd);          \
    register long _rsi __asm__("rsi")=(long)(buf);         \
    register long _rdx __asm__("rdx")=(long)(len);         \
    __asm__ volatile("syscall":"+r"(_rax):"r"(_rdi),"r"(_rsi),"r"(_rdx):"rcx","r11","memory","cc");\
    _rax; })
# define MC_SYS1_EXIT(c) do { \
    register long _rax __asm__("rax")=(long)MC_SYS_EXIT; \
    register long _rdi __asm__("rdi")=(long)(c);          \
    __asm__ volatile("syscall"::"r"(_rax),"r"(_rdi):"rcx","r11","memory"); \
    __builtin_unreachable(); } while(0)
#else
# define MC_SYS3_WRITE(fd,buf,len) write((fd),(buf),(len))
# define MC_SYS1_EXIT(c) _exit(c)
#endif

/* ── WATCHDOG: registrador pinado ── */
/* ARM64=x28 callee-saved · x86_64=rbx · ARM32=r10 */
#if MC_ARCH_ID == 1
# define MC_WD_INIT(n) register long _wd __asm__("x28")=(n)
# define MC_WD_TICK    __asm__ volatile("subs x28,x28,#1":"+r"(_wd)::"cc")
# define MC_WD_ALIVE   (_wd>0)
# define MC_WD_RESET(n)(_wd=(n))
#elif MC_ARCH_ID == 3
# define MC_WD_INIT(n) register long _wd __asm__("rbx")=(n)
# define MC_WD_TICK    __asm__ volatile("dec %0":"+r"(_wd)::"cc")
# define MC_WD_ALIVE   (_wd>0)
# define MC_WD_RESET(n)(_wd=(n))
#else
# define MC_WD_INIT(n) long _wd=(n)
# define MC_WD_TICK    (--_wd)
# define MC_WD_ALIVE   (_wd>0)
# define MC_WD_RESET(n)(_wd=(n))
#endif

/* ── ROLLBACK checkpoint ── */
typedef struct {
    unsigned long regs[8];
    unsigned long sp_snap;
    unsigned int  guard;   /* 0x52414641 = 'RAFA' */
    unsigned int  seq;
    unsigned int  valid;
    unsigned int  _pad;
} MCCheckpoint;

#define MC_GUARD_MAGIC 0x52414641u
#define MC_CHECKPOINT_INIT(cp) do { \
    (cp)->guard=MC_GUARD_MAGIC;(cp)->valid=0;(cp)->seq=0; } while(0)
#define MC_CHECKPOINT_SAVE(cp,v0,v1,v2,v3) do { \
    (cp)->regs[0]=(unsigned long)(v0); \
    (cp)->regs[1]=(unsigned long)(v1); \
    (cp)->regs[2]=(unsigned long)(v2); \
    (cp)->regs[3]=(unsigned long)(v3); \
    (cp)->seq++;(cp)->valid=1; MC_BARRIER_STORE; } while(0)
#define MC_CHECKPOINT_VALID(cp) \
    ((cp)->valid&&(cp)->guard==MC_GUARD_MAGIC)
#define MC_ROLLBACK(cp,lbl) do { \
    if(!MC_CHECKPOINT_VALID(cp)) MC_SYS1_EXIT(0xDE); \
    goto lbl; } while(0)

/* ── FAILSAFE guard ── */
#define MC_FAILSAFE_CHECK(ptr,sz,cp,lbl) do { \
    if(__builtin_expect(!(ptr)||!(sz),0)) MC_ROLLBACK(cp,lbl); } while(0)

#endif /* RAF_MORPHCODE_H */
