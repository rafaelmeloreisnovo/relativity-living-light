/*
 * gaia_train.c v2 — text / image / JSON ingestion
 * Uses gaia_store_train_insert (dual-hash + inv_norm VecDB)
 */
#include "../include/gaia.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

#define GAIA_PI  3.14159265358979323846
#define GAIA_PHI 1.6180339887498948482

void gaia_raf_step(GaiaCtx *g) {
    double n      = (double)(g->trained_total + 1);
    double entropy= 1.0 / n;
    double coher  = 1.0 - entropy;
    double phi_e  = entropy * coher;
    double e_verbo= coher;
    double spiral = pow(0.8660254037844386, GAIA_PI * GAIA_PHI);
    if (g->R_t == 0.0) g->R_t = 3.0;
    g->R_t       *= phi_e * e_verbo * spiral;
    g->phi_ethica = phi_e;
}

void gaia_train_text(GaiaCtx *g, const char *buf, size_t len,
                     uint32_t layer, uint32_t doc_ref) {
    if (!g || !buf || !len) return;
    gaia_store_train_insert(g, (const uint8_t*)buf, len, layer, doc_ref);
    gaia_raf_step(g);
}

#define TILE_SZ 16
void gaia_train_image(GaiaCtx *g, const char *ppm_path) {
    if (!g || !ppm_path) return;
    FILE *f = fopen(ppm_path, "rb");
    if (!f) return;
    char magic[4]={0}; int W=0,H=0,maxval=0;
    if (fscanf(f, "%3s %d %d %d ", magic, &W, &H, &maxval)!=4
        || magic[0]!='P'||magic[1]!='6') { fclose(f); return; }
    if (W<=0||H<=0||W>8192||H>8192) { fclose(f); return; }
    static uint8_t row_buf[8192*3];
    static uint8_t tile[TILE_SZ*TILE_SZ*3];
    uint32_t tiles=0;
    for (int y=0;y<H;y+=TILE_SZ) {
        int rows=(y+TILE_SZ<=H)?TILE_SZ:(H-y);
        for (int ty=0;ty<rows;ty++) {
            size_t rb=(size_t)(W*3); if(rb>sizeof(row_buf))rb=sizeof(row_buf);
            if (fread(row_buf,1,rb,f)!=rb) goto done;
            memcpy(tile+ty*(TILE_SZ*3), row_buf, TILE_SZ*3);
        }
        uint32_t layer=(uint32_t)((y/TILE_SZ)%GAIA_ZIPRAF_LAYERS);
        for (int x=0;x<W;x+=TILE_SZ) {
            gaia_store_train_insert(g,tile,sizeof(tile),layer,(uint32_t)(y*W+x));
            tiles++;
        }
    }
done:
    fclose(f); g->trained_imgs++;
    fprintf(stderr,"  [img] %s: %u tiles\n", ppm_path, tiles);
}

#define JSON_CHUNK   (64*1024)
#define JSON_OVERLAP 256
void gaia_train_json_file(GaiaCtx *g, const char *path) {
    if (!g||!path) return;
    FILE *f=fopen(path,"rb"); if(!f) return;
    static char buf[JSON_CHUNK+JSON_OVERLAP+2];
    static char token[514];
    uint64_t chunks=0, found=0;
    size_t overlap=0;
    while (1) {
        size_t nr=fread(buf+overlap,1,JSON_CHUNK,f); if(!nr) break;
        size_t total=overlap+nr; buf[total]=0;
        const char *p=buf;
        while ((size_t)(p-buf)<total) {
            if (*p!='"'){p++;continue;}
            p++;
            const char *s=p; size_t sl=0;
            while(*p&&*p!='"'&&sl<512){p++;sl++;}
            if(*p=='"'&&sl>=3){
                memcpy(token,s,sl);token[sl]=0;
                gaia_train_text(g,token,sl,(uint32_t)(found%GAIA_ZIPRAF_LAYERS),0);
                found++;
            }
            if(*p=='"')p++;
        }
        size_t keep=(total>JSON_OVERLAP)?JSON_OVERLAP:total;
        memmove(buf,buf+total-keep,keep); overlap=keep; chunks++;
        if(chunks%100==0)
            fprintf(stderr,"  [json] %llu chunks %llu tokens\n",
                (unsigned long long)chunks,(unsigned long long)found);
    }
    fclose(f); g->trained_json++;
    fprintf(stderr,"  [json] done %llu tokens\n",(unsigned long long)found);
}
