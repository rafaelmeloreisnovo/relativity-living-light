/*
 * gaia_learn.c — online learning engine
 * ──────────────────────────────────────
 * Hebbian: w_ij += lr × pre_i × post_j
 * SOM (Self-Organizing Map): 8×8×8 on VecDB 3D space, no malloc
 * Attention scan: infinite loop over Nexus → updates focus
 * Stability index: Lyapunov-weighted coherence
 * All bare-metal: static arrays, no stdlib alloc
 */
#include "../include/gaia.h"
/* gaia_geom merged into gaia.h */
#include <string.h>
#include <math.h>
#include <stdio.h>

/* ── SOM dimensions ────────────────────────────────────── */
#define SOM_DIM   8
#define SOM_NODES (SOM_DIM*SOM_DIM*SOM_DIM)   /* 512 nodes */
#define SOM_VEC   3

/* ── static learning state ─────────────────────────────── */
typedef struct {
    /* SOM weight matrix: 512 nodes × 3 dims */
    float  som_w[SOM_NODES][SOM_VEC];

    /* Hebbian weight matrix: 9 lattice × 512 SOM */
    float  hebb[GAIA_LATTICE_N][SOM_NODES];

    /* attention window */
    float  focus_vec[SOM_VEC];
    float  focus_score;
    uint64_t focus_hash;
    uint32_t attn_steps;

    /* online stats */
    uint64_t learn_steps;
    double   coherence;      /* 0..1 */
    double   entropy;        /* nats */
    double   stability;      /* Lyapunov-based */

    /* SOM parameters */
    float    lr;             /* learning rate */
    float    sigma;          /* neighbourhood radius */
    uint32_t epoch;
} GaiaLearn;

static GaiaLearn _L;

/* ── SOM init: Fibonacci-Rafael seeded weights ─────────── */
void gaia_learn_init(void) {
    memset(&_L, 0, sizeof(_L));
    _L.lr    = 0.05f;
    _L.sigma = 3.0f;
    _L.coherence = 0.5;
    _L.entropy   = 1.0;
    _L.stability = 0.0;

    /* seed SOM nodes with Fibonacci-Rafael × prime modulation */
    for (int i = 0; i < SOM_NODES; i++) {
        int ix = i % SOM_DIM;
        int iy = (i / SOM_DIM) % SOM_DIM;
        int iz = i / (SOM_DIM * SOM_DIM);
        double fi = gaia_fib_rafael((uint32_t)(i % GAIA_FIB_CAP));
        uint32_t pi = gaia_nth_prime((uint32_t)(i % 512));
        float fmod = (float)(fi * 0.01 + (pi % 100) * 0.001);
        _L.som_w[i][0] = (float)ix / (SOM_DIM-1) + fmod * 0.1f;
        _L.som_w[i][1] = (float)iy / (SOM_DIM-1) + fmod * 0.07f;
        _L.som_w[i][2] = (float)iz / (SOM_DIM-1) + fmod * 0.05f;
        /* clamp [0,1] */
        for (int d=0;d<SOM_VEC;d++) {
            if (_L.som_w[i][d]<0) _L.som_w[i][d]=0;
            if (_L.som_w[i][d]>1) _L.som_w[i][d]=1;
        }
    }

    /* Hebbian: initialise to small random-ish values via primes */
    for (int i=0; i<GAIA_LATTICE_N; i++)
        for (int j=0; j<SOM_NODES; j++) {
            uint32_t p = gaia_nth_prime((uint32_t)((i*SOM_NODES+j) % 4096));
            _L.hebb[i][j] = (float)(p % 100) * 0.001f;
        }
}

/* ── SOM: find best matching unit ───────────────────────── */
static int _som_bmu(const float v[SOM_VEC]) {
    int bmu = 0;
    float best = 1e9f;
    for (int i=0; i<SOM_NODES; i++) {
        float d=0;
        for (int k=0;k<SOM_VEC;k++) {
            float dd = v[k] - _L.som_w[i][k];
            d += dd*dd;
        }
        if (d < best) { best=d; bmu=i; }
    }
    return bmu;
}

/* SOM node → 3D grid coords */
static void _som_coords(int idx, int *ix, int *iy, int *iz) {
    *ix = idx % SOM_DIM;
    *iy = (idx / SOM_DIM) % SOM_DIM;
    *iz = idx / (SOM_DIM * SOM_DIM);
}

/* ── SOM online update ───────────────────────────────────── */
/*
 * Classic SOM update with Gaussian neighbourhood:
 * h(bmu,i) = exp(-d²_grid / (2σ²))
 * w_i += lr × h × (v - w_i)
 */
void gaia_som_update(const float v[SOM_VEC]) {
    int bmu = _som_bmu(v);
    int bx, by, bz;
    _som_coords(bmu, &bx, &by, &bz);

    float lr    = _L.lr;
    float sigma2= _L.sigma * _L.sigma * 2.0f;

    for (int i=0; i<SOM_NODES; i++) {
        int ix, iy, iz;
        _som_coords(i, &ix, &iy, &iz);
        float dgx=(float)(ix-bx), dgy=(float)(iy-by), dgz=(float)(iz-bz);
        float dgrid = dgx*dgx + dgy*dgy + dgz*dgz;
        float h = expf(-dgrid / sigma2);
        if (h < 1e-4f) continue;
        for (int k=0;k<SOM_VEC;k++) {
            _L.som_w[i][k] += lr * h * (v[k] - _L.som_w[i][k]);
        }
    }

    _L.learn_steps++;

    /* decay lr and sigma over time (online schedule) */
    if (_L.learn_steps % 1000 == 0) {
        _L.lr    *= 0.995f;
        _L.sigma *= 0.998f;
        if (_L.lr    < 0.001f) _L.lr    = 0.001f;
        if (_L.sigma < 0.5f)   _L.sigma = 0.5f;
        _L.epoch++;
    }
}

/* ── Hebbian update ─────────────────────────────────────── */
/*
 * Given input lattice node (pre) and activated SOM node (post):
 * hebb[pre][post] += lr × (1 - hebb[pre][post])
 * Normalise row to sum=1 (softmax-like, no exp — L1 norm).
 */
void gaia_hebb_update(int lattice_pre, const float v[SOM_VEC]) {
    if (lattice_pre < 0 || lattice_pre >= GAIA_LATTICE_N) return;
    int post = _som_bmu(v);
    float lr = _L.lr;
    _L.hebb[lattice_pre][post] +=
        lr * (1.0f - _L.hebb[lattice_pre][post]);
    /* L1 row normalise */
    float sum=0;
    for (int j=0;j<SOM_NODES;j++) sum += _L.hebb[lattice_pre][j];
    if (sum > 1e-6f)
        for (int j=0;j<SOM_NODES;j++) _L.hebb[lattice_pre][j] /= sum;
}

/* ── Attention scan: walk Nexus, update focus ──────────── */
/*
 * Scans Nexus cells for one that maximises dot(cell.vec, focus).
 * On match: wave_collapse → Hebbian → SOM update.
 * "Infinite attention" — called every N train steps.
 */
void gaia_attention_step(GaiaCtx *g) {
    if (!g->nexus_hdr || g->nexus_hdr->used == 0) return;

    float  best_score = -1.0f;
    int    best_idx   = -1;
    float  *fv = _L.focus_vec;

    uint64_t n = g->nexus_hdr->used;
    for (uint64_t i=0; i<n; i++) {
        GaiaNexusCell *c = &g->nexus_cells[i];
        float s = fv[0]*c->vec[0] + fv[1]*c->vec[1] + fv[2]*c->vec[2];
        if (s > best_score) { best_score=s; best_idx=(int)i; }
    }

    if (best_idx >= 0) {
        GaiaNexusCell *best = &g->nexus_cells[best_idx];
        _L.focus_score = best_score;
        _L.focus_hash  = best->hash;

        /* wave collapse */
        gaia_wave_collapse(g, best->vec, best->hash, best_score);

        /* SOM update with best vec */
        gaia_som_update(best->vec);

        /* Hebbian: lattice snap of focus → post SOM */
        int lat = gaia_lattice_snap(best->vec);
        gaia_hebb_update(lat, best->vec);

        /* shift focus vec toward best */
        for (int k=0;k<SOM_VEC;k++)
            _L.focus_vec[k] = 0.9f*_L.focus_vec[k]
                             + 0.1f*best->vec[k];
    }
    _L.attn_steps++;
}

/* ── Stability computation ──────────────────────────────── */
/*
 * stability = max(0, 1 - |λ_lyapunov| × coherence)
 * If Lyapunov < 0 → attractor is stable → high stability
 * If Lyapunov > 0 → chaotic → lower stability (not zero: creative)
 */
void gaia_learn_stability_update(void) {
    double lya = gaia_lyapunov();
    double n   = (double)(_L.learn_steps + 1);

    /* coherence: how tightly SOM clusters */
    /* estimate: var of BMU distances */
    /* simplified: 1/(1+steps/10000) */
    _L.coherence = 1.0 / (1.0 + (double)_L.learn_steps / 10000.0);

    double lya_abs = lya < 0 ? -lya : lya;
    _L.stability = 1.0 - lya_abs * _L.coherence;
    if (_L.stability < 0.0) _L.stability = 0.0;
    if (_L.stability > 1.0) _L.stability = 1.0;

    /* entropy from epoch: decreases as SOM converges */
    _L.entropy = 1.0 / (1.0 + (double)_L.epoch * 0.1);
    (void)n;
}

/* ── full learn step: train vec through pipeline ────────── */
/*
 * Called by gaia_train_text / gaia_train_image after VecDB insert.
 * Pipeline:
 *   v → SOM_update → Hebbian(lattice_snap(v), v)
 *       → attention_step(every 100) → stability_update(every 1000)
 */
void gaia_learn_step(GaiaCtx *g, const float v[SOM_VEC]) {
    gaia_som_update(v);

    int lat = gaia_lattice_snap(v);
    gaia_hebb_update(lat, v);

    if (_L.learn_steps % 100 == 0)
        gaia_attention_step(g);

    if (_L.learn_steps % 1000 == 0)
        gaia_learn_stability_update();

    /* shift focus toward new vec (soft update) */
    for (int k=0;k<SOM_VEC;k++)
        _L.focus_vec[k] = 0.99f*_L.focus_vec[k] + 0.01f*v[k];
}

/* ── JSON export ────────────────────────────────────────── */
int gaia_learn_json(char *buf, int cap) {
    int n = snprintf(buf, (size_t)cap,
        "{"
        "\"learn_steps\":%llu,"
        "\"epoch\":%u,"
        "\"lr\":%.5f,"
        "\"sigma\":%.4f,"
        "\"coherence\":%.5f,"
        "\"entropy\":%.5f,"
        "\"stability\":%.5f,"
        "\"focus\":[%.4f,%.4f,%.4f],"
        "\"focus_score\":%.4f,"
        "\"attn_steps\":%u"
        "}",
        (unsigned long long)_L.learn_steps,
        _L.epoch,
        (double)_L.lr,
        (double)_L.sigma,
        _L.coherence,
        _L.entropy,
        _L.stability,
        (double)_L.focus_vec[0],
        (double)_L.focus_vec[1],
        (double)_L.focus_vec[2],
        (double)_L.focus_score,
        _L.attn_steps
    );
    return n;
}

/* ── SOM dump: all 512 node weights → JSON array ─────────── */
int gaia_som_json(char *buf, int cap) {
    int pos = 0;
    pos += snprintf(buf+pos, (size_t)(cap-pos), "[");
    for (int i=0; i<SOM_NODES && pos+64 < cap; i++) {
        if (i) pos += snprintf(buf+pos, (size_t)(cap-pos), ",");
        pos += snprintf(buf+pos, (size_t)(cap-pos),
            "[%.3f,%.3f,%.3f]",
            (double)_L.som_w[i][0],
            (double)_L.som_w[i][1],
            (double)_L.som_w[i][2]);
    }
    pos += snprintf(buf+pos, (size_t)(cap-pos), "]");
    return pos;
}
