/*
 * gaia_store.c v2 — VecDB+inv_norm cosine-ready, GaiaStatus, dual hash
 */
#include "../include/gaia.h"
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>

#define VECDB_MAGIC  0x56454344u
#define NEXUS_MAGIC  0x4E455855u
#define ZIPRAF_MAGIC 0x5A524146u

#define VECDB_FILE_SIZE  (sizeof(GaiaStoreHdr) + GAIA_VECDB_CAP  * sizeof(GaiaVecRec))
#define NEXUS_FILE_SIZE  (sizeof(GaiaNexusHdr)  + GAIA_NEXUS_CAP  * sizeof(GaiaNexusCell))
#define ZIPRAF_FILE_SIZE (sizeof(GaiaZipHdr)    + GAIA_ZIPRAF_CAP * sizeof(GaiaZipEntry))

static int _mmap_file(const char *path, size_t sz,
                       void **hdr_out, void **data_out, size_t hdr_sz) {
    int fd = open(path, O_RDWR|O_CREAT, 0644);
    if (fd < 0) { perror(path); return -1; }
    struct stat st;
    if (fstat(fd,&st)==0 && (size_t)st.st_size < sz) ftruncate(fd,(off_t)sz);
    void *base = mmap(NULL, sz, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
    if (base==MAP_FAILED) { perror("mmap"); close(fd); return -1; }
    *hdr_out  = base;
    *data_out = (uint8_t*)base + hdr_sz;
    return fd;
}

/* ── VecDB ── */
static int _vecdb_open(GaiaCtx *g, const char *path) {
    void *h, *d;
    g->vecdb_fd = _mmap_file(path, VECDB_FILE_SIZE, &h, &d, sizeof(GaiaStoreHdr));
    if (g->vecdb_fd < 0) return -1;
    g->vecdb_hdr  = (GaiaStoreHdr*)h;
    g->vecdb_recs = (GaiaVecRec*)d;
    if (g->vecdb_hdr->magic != VECDB_MAGIC) {
        memset(h, 0, sizeof(GaiaStoreHdr));
        g->vecdb_hdr->magic=VECDB_MAGIC; g->vecdb_hdr->version=2;
        g->vecdb_hdr->cap=GAIA_VECDB_CAP; g->vecdb_hdr->used=0;
    }
    return 0;
}

/* v2: store float inv_norm for cosine search without sqrtf per comparison */
GaiaStatus gaia_vecdb_insert_v(GaiaCtx *g, const float v[3],
                                uint32_t layer, uint32_t doc_ref) {
    if (!g||!v) return GAIA_ERR_NULL;
    if (g->vecdb_hdr->used >= g->vecdb_hdr->cap) return GAIA_ERR_RANGE;
    uint64_t idx = g->vecdb_hdr->used;
    GaiaVecRec *r = &g->vecdb_recs[idx];
    r->vec[0]=v[0]; r->vec[1]=v[1]; r->vec[2]=v[2];
    float sum = v[0]*v[0]+v[1]*v[1]+v[2]*v[2];
    float inv = 0.0f;
    if (sum > 1e-12f) {
        inv = 1.0f;
        for (int k=0;k<4;k++) inv = inv*(1.5f-0.5f*sum*inv*inv);
    }
    r->inv_norm=inv; r->id=idx; r->layer_flags=layer; r->doc_ref=doc_ref;
    g->vecdb_hdr->used++;
    return GAIA_OK;
}

/* cosine search: dot × inv_q × inv_norm[i] — no sqrtf on hot path */
int gaia_vecdb_search(GaiaCtx *g, const float q[3],
                      int k, uint64_t *refs, float *scores) {
    if (!g||!q||!refs||!scores||k<=0) return 0;
    float sq = q[0]*q[0]+q[1]*q[1]+q[2]*q[2];
    float inv_q = 0.0f;
    if (sq > 1e-12f) {
        inv_q=1.0f;
        for (int i=0;i<4;i++) inv_q=inv_q*(1.5f-0.5f*sq*inv_q*inv_q);
    }
    for (int i=0;i<k;i++){refs[i]=0;scores[i]=-1.0f;}
    uint64_t n = g->vecdb_hdr->used;
    for (uint64_t i=0;i<n;i++) {
        GaiaVecRec *r=&g->vecdb_recs[i];
        float dot=q[0]*r->vec[0]+q[1]*r->vec[1]+q[2]*r->vec[2];
        float s=dot*inv_q*r->inv_norm;
        if (s<=scores[k-1]) continue;
        for (int j=0;j<k;j++) {
            if (s>scores[j]) {
                for (int l=k-1;l>j;l--){scores[l]=scores[l-1];refs[l]=refs[l-1];}
                scores[j]=s; refs[j]=(uint64_t)r->doc_ref; break;
            }
        }
    }
    int found=0; for (int i=0;i<k;i++) if(scores[i]>-0.5f) found++;
    return found;
}

/* ── Nexus ── */
static int _nexus_open(GaiaCtx *g, const char *path) {
    void *h,*d;
    g->nexus_fd=_mmap_file(path,NEXUS_FILE_SIZE,&h,&d,sizeof(GaiaNexusHdr));
    if (g->nexus_fd<0) return -1;
    g->nexus_hdr=(GaiaNexusHdr*)h; g->nexus_cells=(GaiaNexusCell*)d;
    if (g->nexus_hdr->magic!=NEXUS_MAGIC) {
        memset(h,0,sizeof(GaiaNexusHdr));
        g->nexus_hdr->magic=NEXUS_MAGIC; g->nexus_hdr->version=2;
        g->nexus_hdr->cap=GAIA_NEXUS_CAP; g->nexus_hdr->used=0;
    }
    return 0;
}
static void _nexus_insert(GaiaCtx *g, const float v[3], uint64_t hash) {
    if (!g||g->nexus_hdr->used>=g->nexus_hdr->cap) return;
    GaiaNexusCell *c=&g->nexus_cells[g->nexus_hdr->used++];
    c->vec[0]=v[0];c->vec[1]=v[1];c->vec[2]=v[2];c->_pad=0;
    c->hash=hash;
}

/* ── ZipRaf ── */
static int _zipraf_open(GaiaCtx *g, const char *path) {
    void *h,*d;
    g->zipraf_fd=_mmap_file(path,ZIPRAF_FILE_SIZE,&h,&d,sizeof(GaiaZipHdr));
    if (g->zipraf_fd<0) return -1;
    g->zipraf_hdr=(GaiaZipHdr*)h; g->zipraf_entries=(GaiaZipEntry*)d;
    if (g->zipraf_hdr->magic!=ZIPRAF_MAGIC) {
        memset(h,0,sizeof(GaiaZipHdr));
        g->zipraf_hdr->magic=ZIPRAF_MAGIC; g->zipraf_hdr->version=2;
        g->zipraf_hdr->cap=GAIA_ZIPRAF_CAP; g->zipraf_hdr->used=0;
    }
    return 0;
}
static void _zipraf_insert(GaiaCtx *g, uint64_t key_hash, uint32_t layer) {
    if (!g||g->zipraf_hdr->used>=g->zipraf_hdr->cap) return;
    uint64_t idx=g->zipraf_hdr->used;
    GaiaZipEntry *e=&g->zipraf_entries[idx];
    e->key_hash=key_hash;
    e->chain_prev=(idx>0)?g->zipraf_entries[idx-1].key_hash:0;
    e->layer=layer; e->flags=0;
    memcpy(e->payload,&key_hash,8); memset(e->payload+8,0,8);
    g->zipraf_hdr->used++;
}

/* ── public train path (called by gaia_train_text/image) ── */
void gaia_store_train_insert(GaiaCtx *g, const uint8_t *buf, size_t len,
                              uint32_t layer, uint32_t doc_ref) {
    if (!g||!buf||!len) return;
    uint64_t h = gaia_hash_dual(buf, len);
    float v[3]; gaia_project_3d(h, v);
    gaia_vecdb_insert_v(g, v, layer, doc_ref);
    if (g->trained_total % 1000 == 0) _nexus_insert(g, v, h);
    _zipraf_insert(g, h, layer);
    g->trained_total++;
}

/* ── open/close ── */
int gaia_store_open(GaiaCtx *g, const char *base) {
    char p[512]; int r=0;
    snprintf(p,sizeof(p),"%s/gaia.vecdb",base); r|=_vecdb_open(g,p);
    snprintf(p,sizeof(p),"%s/gaia.nexus",base); r|=_nexus_open(g,p);
    snprintf(p,sizeof(p),"%s/gaia.zipraf",base);r|=_zipraf_open(g,p);
    return r;
}
void gaia_store_close(GaiaCtx *g) {
    if (!g) return;
    if (g->vecdb_fd>=0){msync(g->vecdb_hdr,VECDB_FILE_SIZE,MS_SYNC);
        munmap(g->vecdb_hdr,VECDB_FILE_SIZE);close(g->vecdb_fd);g->vecdb_fd=-1;}
    if (g->nexus_fd>=0){msync(g->nexus_hdr,NEXUS_FILE_SIZE,MS_SYNC);
        munmap(g->nexus_hdr,NEXUS_FILE_SIZE);close(g->nexus_fd);g->nexus_fd=-1;}
    if (g->zipraf_fd>=0){msync(g->zipraf_hdr,ZIPRAF_FILE_SIZE,MS_SYNC);
        munmap(g->zipraf_hdr,ZIPRAF_FILE_SIZE);close(g->zipraf_fd);g->zipraf_fd=-1;}
}
