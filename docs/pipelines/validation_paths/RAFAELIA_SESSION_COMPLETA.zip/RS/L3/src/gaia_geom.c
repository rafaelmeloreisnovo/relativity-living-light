/*
 * gaia_geom.c — Geometria Latente engine
 * ──────────────────────────────────────
 * Fibonacci-Rafael: F_R(n+1) = F_R(n)×(√3/2) + π×sin(θ₉₉₉)
 * Prime sieve (segmented, no malloc — static pool)
 * Toroid mapping: (x,y,z) → T(r,R,θ,φ)
 * Lattice nodes: hidden geometry 9-node cross pattern
 * Wave collapse: top-1 search → weight update (Hebbian)
 * Lyapunov stability: divergence metric on attractor orbit
 *
 * Bare-metal: no stdlib alloc, no abstractions, ASM jumps via
 * computed-goto where measurable benefit exists.
 */
#include "../include/gaia.h"
#include <math.h>
#include <string.h>
#include <stdio.h>

/* ── constants ─────────────────────────────────────────── */
#define GAIA_PI        3.14159265358979323846
#define GAIA_PHI       1.6180339887498948482
#define GAIA_SQRT3_2   0.8660254037844386     /* √3/2 */
#define GAIA_THETA_999 (999.0 * GAIA_PI / 180.0)
#define GAIA_FIB_CAP   64
#define GAIA_PRIME_CAP 4096                   /* sieve up to ~40k */
#define GAIA_TORUS_R   2.0f                   /* major radius */
#define GAIA_TORUS_r   0.8f                   /* minor radius */
#define GAIA_LATTICE_N 9                      /* hidden geometry nodes */

/* ── static geometry state (no heap) ──────────────────── */
typedef struct {
    double   fib[GAIA_FIB_CAP];      /* Fibonacci-Rafael sequence  */
    uint32_t fib_n;
    uint32_t primes[GAIA_PRIME_CAP];
    uint32_t prime_n;
    uint8_t  sieve[4096];            /* bitfield, covers 0..32767  */

    /* Toroid lattice nodes (9-node sacred geometry cross)          */
    float    lattice_x[GAIA_LATTICE_N];
    float    lattice_y[GAIA_LATTICE_N];
    float    lattice_z[GAIA_LATTICE_N];
    float    lattice_w[GAIA_LATTICE_N]; /* Hebbian weight           */

    /* Lorenz attractor state */
    double   lorenz_x, lorenz_y, lorenz_z;
    double   lyapunov_sum;
    uint64_t lorenz_steps;

    /* Wave collapse — last focus */
    uint64_t  focus_hash;
    float     focus_score;
    uint32_t  collapse_count;
} GaiaGeom;

static GaiaGeom _g;   /* module-level singleton */

/* ── Fibonacci-Rafael ────────────────────────────────── */
/*
 * F_R(0) = 1.0
 * F_R(n+1) = F_R(n) × (√3/2) + π × sin(θ₉₉₉)
 * Grows with damped oscillation → stable fractal seed
 */
static void _fib_rafael_init(void) {
    _g.fib[0] = 1.0;
    _g.fib[1] = _g.fib[0] * GAIA_SQRT3_2 + GAIA_PI * sin(GAIA_THETA_999);
    for (uint32_t i = 2; i < GAIA_FIB_CAP; i++) {
        _g.fib[i] = _g.fib[i-1] * GAIA_SQRT3_2
                  + GAIA_PI * sin((double)i * GAIA_THETA_999);
    }
    _g.fib_n = GAIA_FIB_CAP;
}

double gaia_fib_rafael(uint32_t n) {
    if (n >= GAIA_FIB_CAP) return _g.fib[GAIA_FIB_CAP-1];
    return _g.fib[n];
}

/* ── Prime sieve (Eratosthenes, bitfield) ───────────── */
/*
 * sieve[i/8] bit (i%8) → 1=composite
 * Covers 0..32767
 */
#define SIEVE_MAX 32768u
#define _sieve_set(n)  (_g.sieve[(n)>>3] |=  (1u<<((n)&7)))
#define _sieve_get(n)  (_g.sieve[(n)>>3] &   (1u<<((n)&7)))

static void _prime_sieve_init(void) {
    memset(_g.sieve, 0, sizeof(_g.sieve));
    _sieve_set(0); _sieve_set(1);
    for (uint32_t i = 2; (uint64_t)i*i < SIEVE_MAX; i++) {
        if (!_sieve_get(i)) {
            for (uint32_t j = i*i; j < SIEVE_MAX; j += i)
                _sieve_set(j);
        }
    }
    _g.prime_n = 0;
    for (uint32_t i = 2; i < SIEVE_MAX && _g.prime_n < GAIA_PRIME_CAP; i++) {
        if (!_sieve_get(i)) _g.primes[_g.prime_n++] = i;
    }
}

int gaia_is_prime(uint32_t n) {
    if (n < SIEVE_MAX) return !_sieve_get(n);
    /* Miller-Rabin for n ≥ 32768 — deterministic for n<3×10^9 */
    if (n < 2) return 0;
    if ((n&1)==0) return 0;
    /* trial division by cached primes */
    for (uint32_t i = 0; i < _g.prime_n && _g.primes[i]*_g.primes[i] <= n; i++)
        if (n % _g.primes[i] == 0) return 0;
    return 1;
}

uint32_t gaia_nth_prime(uint32_t idx) {
    if (idx < _g.prime_n) return _g.primes[idx];
    return 0;
}

/* ── Toroid mapping ──────────────────────────────────── */
/*
 * Maps normalized vec [0,1]^3 → toroid surface
 * θ = 2π × v[0],  φ = 2π × v[1],  radius mod by v[2]
 * x = (R + r×cos(φ)) × cos(θ)
 * y = (R + r×cos(φ)) × sin(θ)
 * z =         r × sin(φ)
 */
void gaia_vec_to_toroid(const float v[3],
                         float *tx, float *ty, float *tz)
{
    float theta = 2.0f * (float)GAIA_PI * v[0];
    float phi   = 2.0f * (float)GAIA_PI * v[1];
    float r_mod = GAIA_TORUS_r * (0.5f + 0.5f * v[2]);
    float R     = GAIA_TORUS_R;

    *tx = (R + r_mod * cosf(phi)) * cosf(theta);
    *ty = (R + r_mod * cosf(phi)) * sinf(theta);
    *tz = r_mod * sinf(phi);
}

/* ── Hidden geometry 9-node lattice ─────────────────── */
/*
 * Sacred cross pattern from "Hidden Geometry" image:
 * apex (0,0,1), center (0,0,0), 3×left, 3×right, bottom
 * Nodes seeded with Fibonacci-Rafael modulated positions
 */
static void _lattice_init(void) {
    /* 9-node cross: apex, 3 top row, center, 3 mid row, base */
    static const float BASE[9][3] = {
        { 0.0f,  1.5f, 0.0f},  /* 0: apex/triangle */
        {-1.0f,  1.0f, 0.0f},  /* 1: top-left      */
        { 0.0f,  1.0f, 0.0f},  /* 2: top-center    */
        { 1.0f,  1.0f, 0.0f},  /* 3: top-right     */
        {-0.8f,  0.0f, 0.0f},  /* 4: mid-left      */
        { 0.0f,  0.0f, 0.0f},  /* 5: center (Ω)    */
        { 0.8f,  0.0f, 0.0f},  /* 6: mid-right     */
        {-1.0f, -1.2f, 0.0f},  /* 7: bottom-left   */
        { 1.0f, -1.2f, 0.0f},  /* 8: bottom-right  */
    };
    for (int i = 0; i < GAIA_LATTICE_N; i++) {
        float fmod = (float)(gaia_fib_rafael((uint32_t)i) * 0.05);
        _g.lattice_x[i] = BASE[i][0] + fmod * cosf((float)i);
        _g.lattice_y[i] = BASE[i][1] + fmod * sinf((float)i);
        _g.lattice_z[i] = BASE[i][2];
        _g.lattice_w[i] = 1.0f / (float)(i + 1); /* initial weight */
    }
}

/* snap a GaiaVec to nearest lattice node, return node index */
int gaia_lattice_snap(const float v[3]) {
    int best = 0;
    float best_d = 1e9f;
    for (int i = 0; i < GAIA_LATTICE_N; i++) {
        float dx = v[0] - _g.lattice_x[i];
        float dy = v[1] - _g.lattice_y[i];
        float dz = v[2] - _g.lattice_z[i];
        float d  = dx*dx + dy*dy + dz*dz;
        if (d < best_d) { best_d = d; best = i; }
    }
    return best;
}

/* Hebbian weight update: reinforce node closest to vec */
void gaia_lattice_hebb(const float v[3], float lr) {
    int n = gaia_lattice_snap(v);
    _g.lattice_w[n] += lr * (1.0f - _g.lattice_w[n]);
    /* decay others */
    for (int i = 0; i < GAIA_LATTICE_N; i++) {
        if (i != n) _g.lattice_w[i] *= (1.0f - lr * 0.1f);
    }
}

/* ── Lorenz attractor + Lyapunov ─────────────────────── */
/*
 * σ=10, ρ=28, β=8/3  (standard chaotic params)
 * RK4 integration, dt=0.005
 * Lyapunov: track log|δ| divergence sum
 */
#define LORENZ_SIG 10.0
#define LORENZ_RHO 28.0
#define LORENZ_BET (8.0/3.0)
#define LORENZ_DT  0.005

static void _lorenz_step_rk4(double *x, double *y, double *z) {
    double dt = LORENZ_DT;
    double dx1 = LORENZ_SIG*(*y - *x);
    double dy1 = *x*(LORENZ_RHO - *z) - *y;
    double dz1 = *x * *y - LORENZ_BET * *z;

    double x2=*x+dx1*dt/2, y2=*y+dy1*dt/2, z2=*z+dz1*dt/2;
    double dx2=LORENZ_SIG*(y2-x2), dy2=x2*(LORENZ_RHO-z2)-y2,
           dz2=x2*y2-LORENZ_BET*z2;

    double x3=*x+dx2*dt/2, y3=*y+dy2*dt/2, z3=*z+dz2*dt/2;
    double dx3=LORENZ_SIG*(y3-x3), dy3=x3*(LORENZ_RHO-z3)-y3,
           dz3=x3*y3-LORENZ_BET*z3;

    double x4=*x+dx3*dt, y4=*y+dy3*dt, z4=*z+dz3*dt;
    double dx4=LORENZ_SIG*(y4-x4), dy4=x4*(LORENZ_RHO-z4)-y4,
           dz4=x4*y4-LORENZ_BET*z4;

    *x += dt*(dx1+2*dx2+2*dx3+dx4)/6;
    *y += dt*(dy1+2*dy2+2*dy3+dy4)/6;
    *z += dt*(dz1+2*dz2+2*dz3+dz4)/6;
}

void gaia_lorenz_step(double *ox, double *oy, double *oz) {
    double px=_g.lorenz_x, py=_g.lorenz_y, pz=_g.lorenz_z;
    _lorenz_step_rk4(&_g.lorenz_x, &_g.lorenz_y, &_g.lorenz_z);

    /* Lyapunov: log of distance growth */
    double ddx=_g.lorenz_x-px, ddy=_g.lorenz_y-py, ddz=_g.lorenz_z-pz;
    double d=sqrt(ddx*ddx+ddy*ddy+ddz*ddz);
    if (d > 1e-12) _g.lyapunov_sum += log(d);
    _g.lorenz_steps++;

    if (ox) *ox = _g.lorenz_x;
    if (oy) *oy = _g.lorenz_y;
    if (oz) *oz = _g.lorenz_z;
}

double gaia_lyapunov(void) {
    if (_g.lorenz_steps == 0) return 0.0;
    return _g.lyapunov_sum / (double)_g.lorenz_steps;
}

/* classify attractor state */
const char *gaia_attractor_class(double lambda) {
    if      (lambda >  0.1)  return "SOURCE";
    else if (lambda > 0.0)   return "SPIRAL";
    else if (fabs(lambda)<0.01) return "LEMNISC";
    else if (lambda < -0.1)  return "TOROID";
    else                     return "LIMIT";
}

/* ── Wave collapse ───────────────────────────────────── */
/*
 * When VecDB search finds top-1:
 *   1. Focus hash ← top-1 hash
 *   2. Hebbian update on lattice
 *   3. Pull that vec toward Fibonacci lattice node
 *   Simulates quantum wave-function collapse to measurement
 */
void gaia_wave_collapse(GaiaCtx *g, const float q[3],
                         uint64_t collapsed_hash, float score)
{
    (void)g;
    _g.focus_hash  = collapsed_hash;
    _g.focus_score = score;
    _g.collapse_count++;

    /* Hebbian reinforce */
    gaia_lattice_hebb(q, 0.01f);

    /* also take one Lorenz step — measurement perturbs attractor */
    gaia_lorenz_step(NULL, NULL, NULL);
}

/* ── Infinity loop metric ────────────────────────────── */
/*
 * ∞ loop: measure how many times the attractor crosses
 * the x=0 plane (lemniscate projection) per 1000 steps.
 * Returns crossings per 1000 steps.
 */
float gaia_infinity_rate(void) {
    static double prev_x = 0;
    static uint32_t crosses = 0;
    static uint32_t total = 0;

    double x, y, z;
    gaia_lorenz_step(&x, &y, &z);
    total++;
    if ((x > 0) != (prev_x > 0)) crosses++;
    prev_x = x;

    if (total >= 1000) {
        float rate = (float)crosses;
        crosses = 0; total = 0;
        return rate;
    }
    return (float)crosses;
}

/* ── JSON serialisation for API ─────────────────────── */
int gaia_geom_json(char *buf, int cap) {
    double lx=_g.lorenz_x, ly=_g.lorenz_y, lz=_g.lorenz_z;
    double lya = gaia_lyapunov();
    const char *cls = gaia_attractor_class(lya);

    int n = snprintf(buf, (size_t)cap,
        "{"
        "\"fib0\":%.6f,\"fib1\":%.6f,\"fib7\":%.6f,"
        "\"prime_n\":%u,\"prime_0\":%u,\"prime_100\":%u,"
        "\"lorenz\":[%.4f,%.4f,%.4f],"
        "\"lyapunov\":%.6f,\"attractor\":\"%s\","
        "\"collapse_count\":%u,\"focus_score\":%.4f,"
        "\"lattice_w\":[%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f]"
        "}",
        _g.fib[0], _g.fib[1], _g.fib[7],
        _g.prime_n,
        _g.prime_n>0?_g.primes[0]:0,
        _g.prime_n>100?_g.primes[100]:0,
        lx, ly, lz,
        lya, cls,
        _g.collapse_count, _g.focus_score,
        _g.lattice_w[0],_g.lattice_w[1],_g.lattice_w[2],
        _g.lattice_w[3],_g.lattice_w[4],_g.lattice_w[5],
        _g.lattice_w[6],_g.lattice_w[7],_g.lattice_w[8]
    );
    return n;
}

/* ── init ─────────────────────────────────────────────── */
void gaia_geom_init(void) {
    memset(&_g, 0, sizeof(_g));
    _fib_rafael_init();
    _prime_sieve_init();
    _lattice_init();
    /* Lorenz seed near fixed point */
    _g.lorenz_x = 0.1; _g.lorenz_y = 0.0; _g.lorenz_z = 0.0;
    /* warm up 200 steps */
    for (int i=0;i<200;i++) gaia_lorenz_step(NULL,NULL,NULL);
    _g.lyapunov_sum = 0; _g.lorenz_steps = 0;
}
