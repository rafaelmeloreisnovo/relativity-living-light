/*
 * gaia_cpu.c — bare-metal CPU detection
 * x86-64: CPUID instruction  |  ARM64: MIDR_EL1 + /proc/cpuinfo
 * No libc hot paths. Reads /proc/cpuinfo only for brand string.
 */
#include "../include/gaia.h"
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

/* ── write helpers (no printf) ─────────────────────── */
static void _memzero(void *p, size_t n) {
    uint8_t *b = (uint8_t*)p;
    while (n--) *b++ = 0;
}
static size_t _strlen(const char *s) {
    size_t n=0; while(s[n]) n++; return n;
}
static void _memcpy(void *d, const void *s, size_t n) {
    uint8_t *D=(uint8_t*)d; const uint8_t *S=(const uint8_t*)s;
    while(n--) *D++=*S++;
}

/* ── x86-64 CPUID ───────────────────────────────────── */
#if defined(__x86_64__) || defined(_M_X64)

static void _cpuid(uint32_t leaf, uint32_t sub,
                   uint32_t *a, uint32_t *b, uint32_t *c, uint32_t *d)
{
    __asm__ volatile (
        "cpuid"
        : "=a"(*a), "=b"(*b), "=c"(*c), "=d"(*d)
        : "a"(leaf), "c"(sub)
    );
}

static void _cpuid_brand(char brand[48]) {
    uint32_t a,b,c,d;
    _cpuid(0x80000002,0,&a,&b,&c,&d);
    _memcpy(brand,    &a,4); _memcpy(brand+4, &b,4);
    _memcpy(brand+8,  &c,4); _memcpy(brand+12,&d,4);
    _cpuid(0x80000003,0,&a,&b,&c,&d);
    _memcpy(brand+16, &a,4); _memcpy(brand+20,&b,4);
    _memcpy(brand+24, &c,4); _memcpy(brand+28,&d,4);
    _cpuid(0x80000004,0,&a,&b,&c,&d);
    _memcpy(brand+32, &a,4); _memcpy(brand+36,&b,4);
    _memcpy(brand+40, &c,4); _memcpy(brand+44,&d,4);
}

static uint32_t _cpuid_cores(void) {
    uint32_t a,b,c,d;
    _cpuid(1,0,&a,&b,&c,&d);
    return (b >> 16) & 0xff;
}

static void _cpuid_cache(GaiaCPU *cpu) {
    uint32_t a,b,c,d,idx=0;
    do {
        _cpuid(4,idx,&a,&b,&c,&d);
        uint32_t type  = a & 0x1f;
        uint32_t level = (a >> 5) & 7;
        if (!type) break;
        uint32_t linesz  = (b & 0xfff) + 1;
        uint32_t parts   = ((b >>12)&0x3ff)+1;
        uint32_t ways    = ((b >>22)&0x3ff)+1;
        uint32_t sets    = c + 1;
        uint32_t sz_kb   = (linesz * parts * ways * sets) >> 10;
        if (level==1 && type==1) cpu->l1d_kb = sz_kb;
        if (level==2)            cpu->l2_kb  = sz_kb;
        if (level==3)            cpu->l3_kb  = sz_kb;
        idx++;
    } while (idx < 32);
}

static void _detect_x86(GaiaCPU *cpu) {
    uint32_t a,b,c,d;
    cpu->arch = 1;

    /* features leaf 1 */
    _cpuid(1,0,&a,&b,&c,&d);
    cpu->has_sse4 = (c >> 19) & 1;     /* SSE4.1 */
    cpu->has_aes  = (c >> 25) & 1;
    cpu->has_crc32= cpu->has_sse4;     /* CRC32 via SSE4.2 bit21 */
    cpu->has_crc32= (c >> 20) & 1;     /* SSE4.2 */
    cpu->cores    = _cpuid_cores();
    if (!cpu->cores) cpu->cores = 1;

    /* avx2 leaf 7 */
    _cpuid(7,0,&a,&b,&c,&d);
    cpu->has_avx2 = (b >> 5) & 1;

    _cpuid_brand(cpu->brand);
    _cpuid_cache(cpu);
    cpu->l3_kb = 0;  /* will be set below */
}
#endif /* x86_64 */

/* ── ARM64 ──────────────────────────────────────────── */
#if defined(__aarch64__)
static void _detect_arm64(GaiaCPU *cpu) {
    cpu->arch = 2;
    /* Read system register — needs EL1, may fault in userspace */
    /* Fallback: /proc/cpuinfo */
    cpu->has_neon = 1; /* all ARMv8 have NEON */
    cpu->has_crc32= 0;
    cpu->cores = 4;    /* conservative default */

    /* try MIDR_EL1 — silently skip if faults */
    /* In Linux userspace we read /proc/cpuinfo instead */
    int fd = open("/proc/cpuinfo", O_RDONLY);
    if (fd < 0) return;
    char buf[4096]; ssize_t n = read(fd, buf, 4095);
    close(fd);
    if (n<=0) return;
    buf[n]=0;

    /* scan for "crc32" in Features line */
    char *p = buf;
    while (*p) {
        if (p[0]=='c'&&p[1]=='r'&&p[2]=='c'&&p[3]=='3'&&p[4]=='2')
            cpu->has_crc32 = 1;
        if (p[0]=='a'&&p[1]=='e'&&p[2]=='s')
            cpu->has_aes = 1;
        p++;
    }
    /* brand from "Model name" or "CPU part" */
    p = buf;
    char *model = 0;
    while (*p) {
        if (p[0]=='M'&&p[1]=='o'&&p[2]=='d'&&p[3]=='e'&&p[4]=='l') {
            model = p; break;
        }
        p++;
    }
    if (model) {
        while (*model && *model!=':') model++;
        if (*model==':') model++;
        while (*model==' ') model++;
        size_t i=0;
        while (model[i] && model[i]!='\n' && i<47)
            cpu->brand[i]=model[i], i++;
        cpu->brand[i]=0;
    }
}
#endif /* aarch64 */

/* ── fallback ───────────────────────────────────────── */
static void _detect_generic(GaiaCPU *cpu) {
    cpu->arch = 0;
    cpu->cores = 1;
    /* read /proc/cpuinfo anyway */
    int fd = open("/proc/cpuinfo", O_RDONLY);
    if (fd < 0) return;
    char buf[2048]; ssize_t n = read(fd,buf,2047);
    close(fd);
    if (n<=0) return;
    buf[n]=0;
    char *p=buf;
    while(*p){ if(p[0]=='c'&&p[1]=='p'&&p[2]=='u'){ break;} p++; }
}

void gaia_cpu_detect(GaiaCPU *cpu) {
    _memzero(cpu, sizeof(*cpu));
#if defined(__x86_64__) || defined(_M_X64)
    _detect_x86(cpu);
#elif defined(__aarch64__)
    _detect_arm64(cpu);
#else
    _detect_generic(cpu);
#endif
    if (!cpu->brand[0]) {
        const char *unk="GAIA_CPU_UNKNOWN";
        size_t l=_strlen(unk); if(l>47) l=47;
        _memcpy(cpu->brand,unk,l); cpu->brand[l]=0;
    }
}
