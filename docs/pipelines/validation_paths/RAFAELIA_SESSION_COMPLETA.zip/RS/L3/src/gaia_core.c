/*
 * gaia_core.c — GaiaVector + GaiaMetric + GaiaProjection + GaiaHash
 *               GaiaAttention + RafEngine registries
 *               (from gaia_core_v2 spec, merged bare-metal)
 */
#include "../include/gaia.h"
#include <string.h>
#include <math.h>

/* ════════════════════════════════════════════════════════════
 * GaiaVector
 * ════════════════════════════════════════════════════════════ */

GaiaStatus gaia_vector_init(GaiaVector *v, float *buf, uint32_t dim) {
    if (!v || !buf || dim == 0) return GAIA_ERR_NULL;
    v->data  = buf;
    v->dim   = dim;
    v->cap   = dim;
    v->flags = 0;
    return gaia_vector_zero(v);
}

GaiaStatus gaia_vector_zero(GaiaVector *v) {
    if (!v || !v->data) return GAIA_ERR_NULL;
    memset(v->data, 0, (size_t)v->dim * sizeof(float));
    return GAIA_OK;
}

float gaia_vector_dot(const GaiaVector *a, const GaiaVector *b) {
    if (!a || !b || !a->data || !b->data || a->dim != b->dim) return 0.0f;
    float s = 0.0f;
    const float *ap = a->data, *bp = b->data;
    uint32_t n = a->dim;
    for (uint32_t i = 0; i < n; i++) s += ap[i] * bp[i];
    return s;
}

GaiaStatus gaia_vector_normalize(GaiaVector *v) {
    if (!v || !v->data) return GAIA_ERR_NULL;
    float sum = 0.0f;
    float *d = v->data;
    uint32_t n = v->dim;
    for (uint32_t i = 0; i < n; i++) sum += d[i]*d[i];
    if (sum <= 0.0f) return GAIA_ERR_RANGE;
    /* Newton-Raphson rsqrt: 4 iterations */
    float inv = 1.0f;
    for (int k = 0; k < 4; k++) inv = inv * (1.5f - 0.5f * sum * inv * inv);
    for (uint32_t i = 0; i < n; i++) d[i] *= inv;
    return GAIA_OK;
}

GaiaStatus gaia_vector_project_hash(GaiaVector *v, uint64_t hash) {
    if (!v || !v->data) return GAIA_ERR_NULL;
    if (v->dim == 3) return gaia_project_3d(hash, v->data);
    return gaia_project_nd(hash, v->data, v->dim);
}

/* ════════════════════════════════════════════════════════════
 * GaiaMetric
 * ════════════════════════════════════════════════════════════ */

float gaia_metric_dot(const GaiaVector *a, const GaiaVector *b) {
    return gaia_vector_dot(a, b);
}

float gaia_metric_l1(const GaiaVector *a, const GaiaVector *b) {
    if (!a || !b || !a->data || !b->data || a->dim != b->dim) return 0.0f;
    float s = 0.0f;
    for (uint32_t i = 0; i < a->dim; i++) {
        float d = a->data[i] - b->data[i];
        s += (d < 0.0f) ? -d : d;
    }
    return s;
}

float gaia_metric_cosine(const GaiaVector *a, const GaiaVector *b) {
    if (!a || !b || !a->data || !b->data || a->dim != b->dim) return 0.0f;
    float dot = 0.0f, aa = 0.0f, bb = 0.0f;
    for (uint32_t i = 0; i < a->dim; i++) {
        float av = a->data[i], bv = b->data[i];
        dot += av*bv; aa += av*av; bb += bv*bv;
    }
    if (aa <= 0.0f || bb <= 0.0f) return 0.0f;
    float prod = aa * bb;
    float inv  = 1.0f;
    for (int k = 0; k < 4; k++) inv = inv * (1.5f - 0.5f * prod * inv * inv);
    return dot * inv;
}

/* ════════════════════════════════════════════════════════════
 * GaiaProjection
 * ════════════════════════════════════════════════════════════ */

static float _hash_to_unit(uint32_t x) {
    return ((float)(x & 0xFFFFu) / 65535.0f) * 2.0f - 1.0f;
}

GaiaStatus gaia_project_3d(uint64_t hash, float out[3]) {
    if (!out) return GAIA_ERR_NULL;
    out[0] = _hash_to_unit((uint32_t)(hash));
    out[1] = _hash_to_unit((uint32_t)(hash >> 21));
    out[2] = _hash_to_unit((uint32_t)(hash >> 42));
    return GAIA_OK;
}

GaiaStatus gaia_project_nd(uint64_t hash, float *out, uint32_t dim) {
    if (!out || dim == 0) return GAIA_ERR_NULL;
    for (uint32_t i = 0; i < dim; i++) {
        uint32_t shift = (i * 11u) % 53u;
        out[i] = _hash_to_unit((uint32_t)(hash >> shift));
    }
    return GAIA_OK;
}

/* ════════════════════════════════════════════════════════════
 * GaiaHash  — DJB2 / FNV1A / AETHER / CRC32c
 * ════════════════════════════════════════════════════════════ */

static uint64_t _djb2(const uint8_t *b, size_t n) {
    uint64_t h = 5381u;
    for (size_t i = 0; i < n; i++) h = ((h << 5) + h) + (uint64_t)b[i];
    return h;
}
static uint64_t _fnv1a(const uint8_t *b, size_t n) {
    uint64_t h = 1469598103934665603ull;
    for (size_t i = 0; i < n; i++) { h ^= (uint64_t)b[i]; h *= 1099511628211ull; }
    return h;
}
static uint64_t _aether(const uint8_t *b, size_t n) {
    uint64_t h = 0xA3B195354A39B70Dull;
    for (size_t i = 0; i < n; i++) {
        h ^= (h << 7) ^ (h >> 3) ^ (uint64_t)(b[i] * 131u);
        h *= 0x9E3779B97F4A7C15ull;
    }
    return h ^ (h >> 32);
}

/* CRC32c: x86-64 SSE4.2 hardware path, ARM64 intrinsic, else fallback */
#if defined(__x86_64__) || defined(__i386__)
#  include <cpuid.h>

static int _crc32c_ok = -1;  /* -1=unchecked */

static int _has_sse42(void) {
    if (_crc32c_ok >= 0) return _crc32c_ok;
    unsigned int a,b,c,d;
    if (__get_cpuid(1,&a,&b,&c,&d)) {
        _crc32c_ok = (c & (1u<<20)) ? 1 : 0;
    } else {
        _crc32c_ok = 0;
    }
    return _crc32c_ok;
}

static uint64_t _crc32c(const uint8_t *buf, size_t len) {
    if (_has_sse42()) {
        uint64_t crc = 0xFFFFFFFFFFFFFFFFull;
        size_t i = 0;
        for (; i + 8 <= len; i += 8)
            __asm__ volatile("crc32q %1, %0"
                : "+r"(crc) : "m"(*(const uint64_t*)(buf+i)));
        for (; i < len; i++)
            __asm__ volatile("crc32b %1, %0"
                : "+r"(crc) : "m"(buf[i]));
        return crc ^ 0xFFFFFFFFFFFFFFFFull;
    }
    return _djb2(buf, len);  /* fallback */
}

#elif defined(__aarch64__)
#  include <arm_acle.h>
static uint64_t _crc32c(const uint8_t *buf, size_t len) {
    uint32_t crc = 0xFFFFFFFF;
    size_t i = 0;
    for (; i + 4 <= len; i += 4) crc = __crc32cw(crc, *(const uint32_t*)(buf+i));
    for (; i < len; i++) crc = __crc32cb(crc, buf[i]);
    return (uint64_t)(crc ^ 0xFFFFFFFF);
}
#else
static uint64_t _crc32c(const uint8_t *buf, size_t len) { return _djb2(buf,len); }
#endif

uint64_t gaia_hash_bytes(GaiaHashKind kind, const uint8_t *buf, size_t len) {
    if (!buf || len == 0) return 0;
    switch (kind) {
        case GAIA_HASH_DJB2:   return _djb2(buf, len);
        case GAIA_HASH_FNV1A:  return _fnv1a(buf, len);
        case GAIA_HASH_AETHER: return _aether(buf, len);
        case GAIA_HASH_CRC32C: return _crc32c(buf, len);
        default: return 0;
    }
}

uint64_t gaia_hash_dual(const uint8_t *buf, size_t len) {
    return _crc32c(buf, len) ^ _aether(buf, len);
}

/* ════════════════════════════════════════════════════════════
 * GaiaAttention strategy registry
 * ════════════════════════════════════════════════════════════ */

static GaiaAttentionStrategy _attn_reg[GAIA_ATTN_MAX];
static uint32_t              _attn_n = 0;

/* built-in strategies */
static GaiaStatus _attn_cosine(const GaiaVector *q, const GaiaVector *v, float *s) {
    if (!q||!v||!s) return GAIA_ERR_NULL;
    *s = gaia_metric_cosine(q, v); return GAIA_OK;
}
static GaiaStatus _attn_dot(const GaiaVector *q, const GaiaVector *v, float *s) {
    if (!q||!v||!s) return GAIA_ERR_NULL;
    *s = gaia_metric_dot(q, v); return GAIA_OK;
}
static GaiaStatus _attn_l1(const GaiaVector *q, const GaiaVector *v, float *s) {
    if (!q||!v||!s) return GAIA_ERR_NULL;
    *s = -gaia_metric_l1(q, v); return GAIA_OK; /* negate: higher = closer */
}

/* rafaelia-weighted: cosine × φ-ethica weight from vec[2] */
static GaiaStatus _attn_rafaelia(const GaiaVector *q, const GaiaVector *v, float *s) {
    if (!q||!v||!s) return GAIA_ERR_NULL;
    float c = gaia_metric_cosine(q, v);
    /* v->data[2] encodes φ_ethica proxy (layer/8) */
    float phi = (v->data && v->dim >= 3) ? (v->data[2] * 0.5f + 0.5f) : 1.0f;
    *s = c * phi;
    return GAIA_OK;
}

void gaia_attention_reset(void) { _attn_n = 0; }

/* called at boot to register all 4 strategies */
void gaia_attention_init_defaults(void) {
    static const GaiaAttentionStrategy defs[4] = {
        {"cosine",    _attn_cosine},
        {"dot",       _attn_dot},
        {"l1",        _attn_l1},
        {"rafaelia",  _attn_rafaelia},
    };
    _attn_n = 0;
    for (int i=0;i<4;i++) gaia_attention_register(&defs[i]);
}

GaiaStatus gaia_attention_register(const GaiaAttentionStrategy *s) {
    if (!s||!s->name||!s->score) return GAIA_ERR_NULL;
    if (_attn_n >= GAIA_ATTN_MAX) return GAIA_ERR_RANGE;
    _attn_reg[_attn_n++] = *s;
    return GAIA_OK;
}

GaiaStatus gaia_attention_apply(const char *name,
                                const GaiaVector *q, const GaiaVector *v,
                                float *out)
{
    if (!name||!q||!v||!out) return GAIA_ERR_NULL;
    for (uint32_t i=0; i<_attn_n; i++) {
        const char *a=_attn_reg[i].name, *b=name;
        while(*a&&*b&&*a==*b){a++;b++;}
        if (!*a&&!*b) return _attn_reg[i].score(q, v, out);
    }
    /* default: cosine */
    return _attn_cosine(q, v, out);
}

/* ════════════════════════════════════════════════════════════
 * RafEngine registry
 * ════════════════════════════════════════════════════════════ */

static RafEngine  _raf_reg[RAF_ENGINE_MAX];
static uint32_t   _raf_n = 0;

static int _streq(const char *a, const char *b) {
    while(*a&&*b&&*a==*b){a++;b++;}
    return !*a && !*b;
}

void raf_engine_reset(void) { _raf_n = 0; }

GaiaStatus raf_engine_register(const RafEngine *e) {
    if (!e||!e->name||!e->run) return GAIA_ERR_NULL;
    if (_raf_n >= RAF_ENGINE_MAX) return GAIA_ERR_RANGE;
    _raf_reg[_raf_n++] = *e;
    return GAIA_OK;
}

GaiaStatus raf_engine_execute(const char *name, const void *in, void *out) {
    if (!name) return GAIA_ERR_NULL;
    for (uint32_t i=0;i<_raf_n;i++)
        if (_streq(_raf_reg[i].name, name)) return _raf_reg[i].run(in, out);
    return GAIA_ERR_RANGE;
}

GaiaStatus raf_engine_metrics(const char *name, void *out) {
    if (!name) return GAIA_ERR_NULL;
    for (uint32_t i=0;i<_raf_n;i++)
        if (_streq(_raf_reg[i].name, name)) {
            if (!_raf_reg[i].metrics) return GAIA_ERR_UNSUPPORTED;
            return _raf_reg[i].metrics(out);
        }
    return GAIA_ERR_RANGE;
}

/* ════════════════════════════════════════════════════════════
 * GaiaNexus (in-memory)
 * ════════════════════════════════════════════════════════════ */

GaiaStatus gaia_nexus_init(GaiaNexus *nx, GaiaVector *vecs, uint64_t *ids, uint32_t cap) {
    if (!nx||!vecs||!ids||!cap) return GAIA_ERR_NULL;
    nx->vectors = vecs; nx->ids = ids;
    nx->capacity = cap; nx->count = 0;
    return GAIA_OK;
}

GaiaStatus gaia_nexus_insert(GaiaNexus *nx, const GaiaVector *v, uint64_t id) {
    if (!nx||!v||!v->data) return GAIA_ERR_NULL;
    if (nx->count >= nx->capacity) return GAIA_ERR_RANGE;
    nx->vectors[nx->count] = *v;
    nx->ids[nx->count]     = id;
    nx->count++;
    return GAIA_OK;
}

GaiaStatus gaia_nexus_scan(GaiaNexus *nx, const GaiaVector *query,
                           uint64_t *out_ids, float *out_scores, uint32_t limit)
{
    if (!nx||!query||!out_ids||!out_scores||!limit) return GAIA_ERR_NULL;
    for (uint32_t i=0;i<limit;i++){ out_ids[i]=0; out_scores[i]=-1.0f; }
    for (uint32_t i=0;i<nx->count;i++) {
        float s = gaia_metric_cosine(query, &nx->vectors[i]);
        if (s <= out_scores[limit-1]) continue;
        for (uint32_t j=0;j<limit;j++) {
            if (s > out_scores[j]) {
                for (uint32_t k=limit-1;k>j;k--){
                    out_scores[k]=out_scores[k-1]; out_ids[k]=out_ids[k-1];
                }
                out_scores[j]=s; out_ids[j]=nx->ids[i]; break;
            }
        }
    }
    return GAIA_OK;
}

void gaia_nexus_close(GaiaNexus *nx) {
    if (!nx) return;
    nx->vectors=0; nx->ids=0; nx->capacity=nx->count=0;
}

/* exported for declarations */
void gaia_attention_init_defaults(void);
