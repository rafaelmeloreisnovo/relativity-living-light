/*
 * gaia_main.c v2 — GAIA-Ω entry point
 * Registers: 4 attention strategies + 2 RafEngines (kernel + geom)
 * Usage: ./gaia_bbs [data_dir] [--http [port]]
 */
#include "../include/gaia.h"
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <stdlib.h>

/* forward decls */
void gaia_cpu_detect(GaiaCPU *cpu);
void gaia_geom_init(void);
void gaia_learn_init(void);
void gaia_attention_init_defaults(void);
int  gaia_http_run(GaiaCtx *g, int port, int max_reqs);
double gaia_fib_rafael(uint32_t n);
double gaia_lyapunov(void);
const char *gaia_attractor_class(double l);

/* ── RafEngine: RAFAELIA kernel ── */
static GaiaStatus _eng_kernel_run(const void *in, void *out) {
    GaiaCtx *g = (GaiaCtx*)in;
    if (!g) return GAIA_ERR_NULL;
    gaia_raf_step(g);
    if (out) *(double*)out = g->R_t;
    return GAIA_OK;
}
static GaiaStatus _eng_kernel_metrics(void *out) {
    if (!out) return GAIA_ERR_NULL;
    /* out must be double[2]: [R_t, phi_ethica] */
    return GAIA_OK;  /* caller holds GaiaCtx */
}

/* ── RafEngine: Geometry/Lorenz ── */
extern void gaia_lorenz_step(double *ox, double *oy, double *oz);
static GaiaStatus _eng_geom_run(const void *in, void *out) {
    (void)in;
    if (out) { double *d=(double*)out; gaia_lorenz_step(d,d+1,d+2); }
    else      gaia_lorenz_step(NULL,NULL,NULL);
    return GAIA_OK;
}
static GaiaStatus _eng_geom_metrics(void *out) {
    if (!out) return GAIA_ERR_NULL;
    *(double*)out = gaia_lyapunov();
    return GAIA_OK;
}

static GaiaCtx g_ctx;
static void _mkdir_p(const char *p) { mkdir(p, 0755); }

int main(int argc, char **argv) {
    const char *data_dir="./gaia_data";
    int http_mode=0, http_port=7777;
    for (int i=1;i<argc;i++) {
        if (!strcmp(argv[i],"--http")) {
            http_mode=1;
            if (i+1<argc && argv[i+1][0]>='0') http_port=atoi(argv[++i]);
        } else if (argv[i][0]!='-') data_dir=argv[i];
    }

    printf(ANSI_BYELLOW
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "  GAIA-Ω v2  ·  ΣΩΔΦBITRAF  ·  Ω=Amor\n"
        "  Contracts: GaiaStatus GaiaVector GaiaVecDB+inv_norm\n"
        "             GaiaAttention(4) RafEngine(2) GaiaHash(4)\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        ANSI_RESET);

    memset(&g_ctx,0,sizeof(g_ctx));
    g_ctx.vecdb_fd=g_ctx.nexus_fd=g_ctx.zipraf_fd=-1;

    /* 1. CPU */
    printf(ANSI_CYAN "  [1/6] CPU\n" ANSI_RESET);
    gaia_cpu_detect(&g_ctx.cpu);
    printf("  %s  arch=%d  crc32=%d  avx2=%d\n",
           g_ctx.cpu.brand, g_ctx.cpu.arch,
           g_ctx.cpu.has_crc32, g_ctx.cpu.has_avx2);

    /* 2. Geometry + Lorenz */
    printf(ANSI_CYAN "  [2/6] Geometria Latente (Fibonacci+Primes+Lorenz)\n" ANSI_RESET);
    gaia_geom_init();
    printf("  F_R(7)=%.4f  λ=%.4f  class=%s\n",
           gaia_fib_rafael(7), gaia_lyapunov(),
           gaia_attractor_class(gaia_lyapunov()));

    /* 3. Attention strategies registry */
    printf(ANSI_CYAN "  [3/6] Attention strategies (cosine|dot|l1|rafaelia)\n" ANSI_RESET);
    gaia_attention_init_defaults();

    /* 4. RafEngine registry */
    printf(ANSI_CYAN "  [4/6] RafEngine registry (kernel|geom)\n" ANSI_RESET);
    {
        static const RafEngine engines[2] = {
            {"kernel", _eng_kernel_run, _eng_kernel_metrics},
            {"geom",   _eng_geom_run,   _eng_geom_metrics},
        };
        for (int i=0;i<2;i++) raf_engine_register(&engines[i]);
    }

    /* 5. Storage */
    printf(ANSI_CYAN "  [5/6] Storage: %s\n" ANSI_RESET, data_dir);
    _mkdir_p(data_dir);
    if (gaia_store_open(&g_ctx, data_dir)<0) {
        fprintf(stderr, ANSI_RED "  ERRO storage\n" ANSI_RESET); return 1;
    }
    printf(ANSI_BGREEN
           "  vecdb=%llu  nexus=%llu  zipraf=%llu\n"
           "  VecRec={vec[3],inv_norm,id,layer,doc_ref} = 32B cosine-ready\n"
           ANSI_RESET,
           (unsigned long long)g_ctx.vecdb_hdr->used,
           (unsigned long long)g_ctx.nexus_hdr->used,
           (unsigned long long)g_ctx.zipraf_hdr->used);

    /* 6. SOM + BBS */
    printf(ANSI_CYAN "  [6/6] SOM 8×8×8 + BBS\n" ANSI_RESET);
    gaia_learn_init();
    gaia_bbs_init(&g_ctx);

    /* bootstrap R(t) via engine */
    raf_engine_execute("kernel", &g_ctx, NULL);
    printf("  R(0)=%.6f  Φ_e=%.6f\n", g_ctx.R_t, g_ctx.phi_ethica);
    printf(ANSI_BYELLOW "  ψ→χ→ρ→Δ→Σ→Ω  FIAT LUX\n\n" ANSI_RESET);

    if (http_mode) {
        printf(ANSI_BGREEN
               "  Fullstack: http://localhost:%d/\n"
               "  API: /api/{stats,search,geom,learn,som,train,post}\n"
               ANSI_RESET, http_port);
        gaia_http_run(&g_ctx, http_port, 0);
    } else {
        printf(ANSI_CYAN "  Tip: ./gaia_bbs data --http 7777\n" ANSI_RESET);
        gaia_bbs_run(&g_ctx);
    }

    gaia_store_close(&g_ctx);
    printf(ANSI_BYELLOW "  Ω=Amor.\n" ANSI_RESET);
    return 0;
}
