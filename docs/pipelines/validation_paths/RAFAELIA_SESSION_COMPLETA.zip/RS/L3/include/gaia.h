/*
 * gaia.h — master header GAIA-Ω v2
 * ──────────────────────────────────────────────────────────────
 * Contracts (from gaia_core_v2 spec):
 *   GaiaStatus    — unified error enum
 *   GaiaVector    — float vec with dim/cap/flags
 *   GaiaHashKind  — DJB2 / FNV1A / AETHER / CRC32c
 *   GaiaVecDB     — mmap storage + inv_norms for cosine
 *   GaiaNexus     — in-memory vector index
 *   GaiaAttention — pluggable strategy registry
 *   RafEngine     — pluggable compute registry
 *   GaiaCtx       — session context (CPU+storage+BBS+raf)
 *
 * Low-level: no heap alloc on hot paths; static pools; CRC32c ASM.
 * Ω = Amor.
 */
#ifndef GAIA_H
#define GAIA_H

#include <stdint.h>
#include <stddef.h>
#include <string.h>

/* ── ANSI ────────────────────────────────────────────────── */
#define ANSI_RESET   "\033[0m"
#define ANSI_CYAN    "\033[36m"
#define ANSI_BGREEN  "\033[92m"
#define ANSI_BYELLOW "\033[93m"
#define ANSI_RED     "\033[31m"

/* ── GaiaStatus ──────────────────────────────────────────── */
typedef enum {
    GAIA_OK              =  0,
    GAIA_ERR_NULL        = -1,
    GAIA_ERR_RANGE       = -2,
    GAIA_ERR_NOMEM       = -3,
    GAIA_ERR_BAD_DIM     = -4,
    GAIA_ERR_UNSUPPORTED = -5,
    GAIA_ERR_IO          = -6
} GaiaStatus;

/* ── geometry constants (needed by gaia_learn) ────────── */
#define GAIA_FIB_CAP   64
#define GAIA_LATTICE_N 9
#define GAIA_PRIME_CAP 4096

/* ── GaiaVector ──────────────────────────────────────────── */
typedef struct {
    float    *data;
    uint32_t  dim;
    uint32_t  cap;
    uint32_t  flags;
} GaiaVector;

GaiaStatus gaia_vector_init(GaiaVector *v, float *buf, uint32_t dim);
GaiaStatus gaia_vector_zero(GaiaVector *v);
GaiaStatus gaia_vector_normalize(GaiaVector *v);
float      gaia_vector_dot(const GaiaVector *a, const GaiaVector *b);
GaiaStatus gaia_vector_project_hash(GaiaVector *v, uint64_t hash);

/* ── GaiaHashKind ─────────────────────────────────────────── */
typedef enum {
    GAIA_HASH_DJB2   = 0,
    GAIA_HASH_FNV1A  = 1,
    GAIA_HASH_AETHER = 2,
    GAIA_HASH_CRC32C = 3    /* SSE4.2 or fallback */
} GaiaHashKind;

uint64_t gaia_hash_bytes(GaiaHashKind kind, const uint8_t *buf, size_t len);

/* dual-hash for VecDB: CRC32c XOR AETHER */
uint64_t gaia_hash_dual(const uint8_t *buf, size_t len);

/* ── GaiaProjection ──────────────────────────────────────── */
GaiaStatus gaia_project_3d(uint64_t hash, float out[3]);
GaiaStatus gaia_project_nd(uint64_t hash, float *out, uint32_t dim);

/* ── GaiaMetric ───────────────────────────────────────────── */
float gaia_metric_dot   (const GaiaVector *a, const GaiaVector *b);
float gaia_metric_l1    (const GaiaVector *a, const GaiaVector *b);
float gaia_metric_cosine(const GaiaVector *a, const GaiaVector *b);

/* ── GaiaVecDB ────────────────────────────────────────────── */
/*
 * mmap-backed; records 24 bytes: vec[3]×float + 4 pad + uint64_t id
 * inv_norms stored separately (float[], same index)
 * cosine search = dot × inv_q × inv_norms[i]
 */
#define GAIA_VEC_DIM   3
#define GAIA_VECDB_CAP 4000000u
#define GAIA_NEXUS_CAP 1000000u
#define GAIA_ZIPRAF_CAP 500000u
#define GAIA_ZIPRAF_LAYERS 8

#pragma pack(push,1)
typedef struct {
    uint32_t magic;
    uint32_t version;
    uint64_t used;
    uint64_t cap;
    uint64_t reserved[4];
} GaiaStoreHdr;   /* 64 bytes */

typedef struct {
    float    vec[3];
    float    inv_norm;     /* 1/|vec| — replaces uint16_t quantized */
    uint64_t id;
    uint32_t layer_flags;
    uint32_t doc_ref;
} GaiaVecRec;     /* 32 bytes */

typedef struct {
    uint32_t magic;
    uint32_t version;
    uint64_t used;
    uint64_t cap;
    uint64_t reserved[4];
} GaiaNexusHdr;   /* 64 bytes */

typedef struct {
    float    vec[3];
    float    _pad;
    uint64_t hash;
    char     label[32];
    uint64_t timestamp;
} GaiaNexusCell;  /* 64 bytes */

typedef struct {
    uint32_t magic;
    uint32_t version;
    uint64_t used;
    uint64_t cap;
    uint64_t reserved[4];
} GaiaZipHdr;     /* 64 bytes */

typedef struct {
    uint64_t key_hash;
    uint64_t chain_prev;
    uint32_t layer;
    uint32_t flags;
    uint8_t  payload[16];
} GaiaZipEntry;   /* 32 bytes */
#pragma pack(pop)

/* ── GaiaNexus (in-memory scan) ──────────────────────────── */
typedef struct {
    GaiaVector *vectors;
    uint64_t   *ids;
    uint32_t    capacity;
    uint32_t    count;
} GaiaNexus;

GaiaStatus gaia_nexus_init(GaiaNexus *nx, GaiaVector *vecs, uint64_t *ids, uint32_t cap);
GaiaStatus gaia_nexus_insert(GaiaNexus *nx, const GaiaVector *v, uint64_t id);
GaiaStatus gaia_nexus_scan(GaiaNexus *nx, const GaiaVector *query,
                           uint64_t *out_ids, float *out_scores, uint32_t limit);
void       gaia_nexus_close(GaiaNexus *nx);

/* ── GaiaAttentionStrategy ───────────────────────────────── */
#define GAIA_ATTN_MAX 8

typedef struct {
    const char *name;
    GaiaStatus (*score)(const GaiaVector *q, const GaiaVector *v, float *out);
} GaiaAttentionStrategy;

GaiaStatus gaia_attention_register(const GaiaAttentionStrategy *s);
GaiaStatus gaia_attention_apply(const char *name,
                                const GaiaVector *q, const GaiaVector *v,
                                float *out_score);
void       gaia_attention_reset(void);

/* ── RafEngine ────────────────────────────────────────────── */
#define RAF_ENGINE_MAX 8

typedef struct {
    const char  *name;
    GaiaStatus (*run)(const void *input, void *output);
    GaiaStatus (*metrics)(void *out_metrics);
} RafEngine;

GaiaStatus raf_engine_register(const RafEngine *e);
GaiaStatus raf_engine_execute(const char *name, const void *in, void *out);
GaiaStatus raf_engine_metrics(const char *name, void *out_metrics);
void       raf_engine_reset(void);

/* ── CPU ──────────────────────────────────────────────────── */
typedef struct {
    int      arch;       /* 0=x86_64 1=arm64 2=other */
    int      has_sse4;
    int      has_avx2;
    int      has_crc32;
    int      has_aes;
    int      has_neon;
    uint32_t l1d_kb, l2_kb, l3_kb;
    uint32_t cores;
    char     brand[48];
} GaiaCPU;

void gaia_cpu_detect(GaiaCPU *cpu);

/* ── BBS types ────────────────────────────────────────────── */
#define GAIA_BBS_BOARDS  16
#define GAIA_BBS_MSGS    4096
#define GAIA_BBS_MSGLEN  512

typedef struct {
    uint32_t id;
    uint32_t board;
    char     author[32];
    char     subject[64];
    char     body[GAIA_BBS_MSGLEN];
    uint64_t hash;
    uint64_t timestamp;
    uint32_t vec_ref;
} BBSMsg;

typedef struct {
    uint32_t  id;
    char      name[32];
    char      desc[64];
    uint32_t  layer;      /* maps to RAFAELIA layer 0-7 */
    uint32_t  msg_count;
} BBSBoard;

/* ── HashChain ────────────────────────────────────────────── */
typedef struct {
    uint64_t hash;
    uint64_t prev;
    uint32_t etype;
    uint32_t seq;
} HashChain;

/* ── GaiaCtx ──────────────────────────────────────────────── */
typedef struct {
    GaiaCPU cpu;

    /* mmap storage */
    int          vecdb_fd, nexus_fd, zipraf_fd;
    GaiaStoreHdr *vecdb_hdr;
    GaiaVecRec   *vecdb_recs;
    GaiaNexusHdr *nexus_hdr;
    GaiaNexusCell *nexus_cells;
    GaiaZipHdr   *zipraf_hdr;
    GaiaZipEntry *zipraf_entries;

    /* BBS */
    BBSBoard  boards[GAIA_BBS_BOARDS];
    BBSMsg    msgs[GAIA_BBS_MSGS];
    uint32_t  msg_count;
    uint32_t  cur_board;

    /* RAFAELIA kernel state */
    double    R_t;
    double    phi_ethica;
    uint64_t  trained_total;
    uint64_t  trained_imgs;
    uint64_t  trained_json;

    /* HashChain event log */
    HashChain chain[256];
    uint32_t  chain_len;
} GaiaCtx;

/* ── Store API ────────────────────────────────────────────── */
int  gaia_store_open(GaiaCtx *g, const char *base_path);
void gaia_store_close(GaiaCtx *g);

/* VecDB insert: computes inv_norm, stores proper cosine-ready record */
GaiaStatus gaia_vecdb_insert_v(GaiaCtx *g, const float v[3],
                                uint32_t layer, uint32_t doc_ref);
/* cosine search using inv_norms */
int  gaia_vecdb_search(GaiaCtx *g, const float q[3],
                       int k, uint64_t *out_refs, float *out_scores);

/* ── Train API ────────────────────────────────────────────── */
void gaia_train_text(GaiaCtx *g, const char *buf, size_t len,
                     uint32_t layer, uint32_t doc_ref);
void gaia_train_image(GaiaCtx *g, const char *ppm_path);
void gaia_train_json_file(GaiaCtx *g, const char *path);
void gaia_raf_step(GaiaCtx *g);

/* ── BBS API ──────────────────────────────────────────────── */
void gaia_bbs_init(GaiaCtx *g);
void gaia_bbs_run(GaiaCtx *g);
void gaia_bbs_post(GaiaCtx *g, uint32_t board,
                   const char *author, const char *subj, const char *body);

/* ── Static pool (4MB, zero heap) ────────────────────────── */
#define GAIA_POOL_SIZE (4 * 1024 * 1024)
typedef struct {
    uint8_t  mem[GAIA_POOL_SIZE];
    uint32_t pos;
} GaiaPool;

static inline void *gaia_pool_alloc(GaiaPool *p, uint32_t sz) {
    sz = (sz + 7u) & ~7u;   /* 8-byte align */
    if (p->pos + sz > GAIA_POOL_SIZE) return 0;
    void *r = p->mem + p->pos;
    p->pos += sz;
    return r;
}
static inline void gaia_pool_reset(GaiaPool *p) { p->pos = 0; }

#endif /* GAIA_H */
