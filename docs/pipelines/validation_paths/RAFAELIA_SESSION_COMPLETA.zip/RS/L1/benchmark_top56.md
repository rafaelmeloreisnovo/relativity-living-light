# RAFAELOS / RafCoder Top-56 Benchmark Artifact

> CI-runner-relative benchmark report. Values depend on the GitHub Actions runner, compiler, flags and current repository state.

## Top 56 metrics

| # | Category | Metric | Value | Unit | Interpretation |
|---:|---|---|---:|---|---|
| 1 | Throughput | `best_ns_per_sector` | 594.881 | ns/sector | Lower is better for native runtime throughput. |
| 2 | Throughput | `best_sectors_per_second` | 1681007.421 | sectors/s | Higher is better for raw execution volume. |
| 3 | Throughput | `worst_ns_per_sector` | 603.28 | ns/sector | Worst measured case in the benchmark matrix. |
| 4 | Throughput | `median_ns_per_sector` | 599.707 | ns/sector | Median across the benchmark matrix. |
| 5 | Throughput | `mean_ns_per_sector` | 599.265 | ns/sector | Mean across the benchmark matrix. |
| 6 | Throughput | `throughput_spread_ratio` | 1.014119 | ratio | Closeness to 1.0 indicates stable scaling. |
| 7 | Stability | `timing_stability_score` | 99.208 | 0-100 | Derived from coefficient of variation across samples. |
| 8 | Stability | `sample_count` | 30 | samples | Total benchmark samples collected. |
| 9 | Stability | `matrix_cases` | 6 | cases | Number of iteration cases tested. |
| 10 | Determinism | `checksum_uniqueness_across_cases` | 6 | unique | Checksums should vary by iteration case. |
| 11 | Determinism | `deterministic_snapshot_assertions` | True | bool | True means repeated samples per case produced identical snapshots. |
| 12 | Determinism | `snapshot_cases_asserted` | 6 | cases | Number of benchmark cases with deterministic snapshot checks. |
| 13 | Determinism | `snapshot_hash64_last` | 0xc26db88744eb54fe | hex | Final state hash for the largest benchmark case. |
| 14 | Determinism | `snapshot_crc32_last` | 0x6780a8b6 | hex | Final CRC32 for the largest benchmark case. |
| 15 | Determinism | `output_words_are_8` | True | bool | Checks the compact output vector contract. |
| 16 | Binary | `binary_size_bytes` | 16432 | bytes | Total benchmark binary size. |
| 17 | Binary | `text_section_bytes` | 3989 | bytes | Executable text size from size(1), when available. |
| 18 | Binary | `data_section_bytes` | 600 | bytes | Data section size from size(1), when available. |
| 19 | Binary | `bss_section_bytes` | 8 | bytes | BSS section size from size(1), when available. |
| 20 | Binary | `symbol_count` | 39 | symbols | Symbol count from nm, when available. |
| 21 | Binary | `binary_sha256` | e473670485b752db029e39a30bb7f4816b0daae34defc7ab0a1b77b0a412f90a | sha256 | Binary identity for artifact reproducibility. |
| 22 | Portability | `os` | Linux | string | Runner operating system. |
| 23 | Portability | `machine` | x86_64 | string | Runner machine architecture. |
| 24 | Portability | `python_version` | 3.12.13 | string | Python used by artifact generator. |
| 25 | Portability | `compiler` | clang | string | C compiler selected by workflow. |
| 26 | Portability | `cflags` | -O2 -Wall -Wextra -Werror | flags | Optimization and warning flags. |
| 27 | Core | `core_payload_size` | 32 | bytes | Payload size from CORE_PAYLOAD_SIZE contract. |
| 28 | Core | `core_output_words` | 8 | u32 | Output vector words from CORE_OUTPUT_WORDS contract. |
| 29 | Core | `state_struct_observed_outputs` | 8 | u32 | Observed output words emitted by harness. |
| 30 | Core | `min_coherence_q16` | 30174 | q16 | Minimum coherence across benchmark cases. |
| 31 | Core | `max_coherence_q16` | 45402 | q16 | Maximum coherence across benchmark cases. |
| 32 | Core | `mean_coherence_q16` | 36997.667 | q16 | Mean coherence across benchmark cases. |
| 33 | Core | `min_entropy_q16` | 21732 | q16 | Minimum entropy across benchmark cases. |
| 34 | Core | `max_entropy_q16` | 30096 | q16 | Maximum entropy across benchmark cases. |
| 35 | Core | `mean_entropy_q16` | 23508.333 | q16 | Mean entropy across benchmark cases. |
| 36 | Core | `min_invariant_milli` | 323 | milli | Minimum invariant score across cases. |
| 37 | Core | `max_invariant_milli` | 397 | milli | Maximum invariant score across cases. |
| 38 | Core | `mean_invariant_milli` | 356 | milli | Mean invariant score across cases. |
| 39 | Scaling | `small_case_iterations` | 1 | iterations | Smallest iteration case. |
| 40 | Scaling | `large_case_iterations` | 2048 | iterations | Largest iteration case. |
| 41 | Scaling | `large_to_small_iteration_ratio` | 2048.0 | ratio | Benchmark matrix scale spread. |
| 42 | Scaling | `large_to_small_time_ratio` | 2049.168 | ratio | Observed elapsed-time growth. |
| 43 | Scaling | `large_to_small_ns_per_sector_ratio` | 1.000571 | ratio | Per-sector scaling stability. |
| 44 | CI | `artifact_json` | benchmark_top56.json | file | Machine-readable benchmark report. |
| 45 | CI | `artifact_csv` | benchmark_matrix.csv | file | Tabular benchmark matrix. |
| 46 | CI | `artifact_markdown` | benchmark_top56.md | file | Human-readable specialized analysis report. |
| 47 | CI | `artifact_snapshots` | benchmark_snapshots.json | file | Deterministic snapshot assertions and signatures. |
| 48 | CI | `build_stdout` | build_stdout.txt | file | Compiler stdout artifact. |
| 49 | CI | `build_stderr` | build_stderr.txt | file | Compiler stderr artifact. |
| 50 | Audit | `market_metric_count_target` | 56 | metrics | Top-56 benchmark/audit target. |
| 51 | Audit | `claims_are_runner_relative` | True | bool | Metrics are CI-runner measurements, not universal hardware claims. |
| 52 | Audit | `native_core_no_heap_claim` | source-level intended | text | Core path is designed without malloc/GC; static verification is future work. |
| 53 | Audit | `external_dependency_weight` | low | label | Benchmark uses Python stdlib plus system C compiler. |
| 54 | Audit | `reviewability` | json/csv/md/snapshots | formats | Artifacts support machine and human review. |
| 55 | Audit | `reproducibility_level` | CI reproducible | label | Re-runnable through GitHub Actions. |
| 56 | Audit | `specialized_analysis_scope` | performance,size,determinism,portability,core-state | domains | Scope covered by the generated artifacts. |

## Benchmark matrix

| iterations | repeats | samples | deterministic | mean ns | ns/sector | sectors/s | checksum |
|---:|---:|---:|---|---:|---:|---:|---|
| 1 | 2000 | 5 | True | 1205872.800 | 602.936 | 1658549.724 | `0x65701fe1488b6dcc` |
| 7 | 2000 | 5 | True | 8356425.000 | 596.888 | 1675357.584 | `0x972fef53e8d7d473` |
| 42 | 2000 | 5 | True | 50612227.000 | 602.527 | 1659678.006 | `0x21672a94fd86343d` |
| 128 | 2000 | 5 | True | 152340507.600 | 595.080 | 1680446.022 | `0x66615b69165f9601` |
| 512 | 2000 | 5 | True | 609158524.400 | 594.881 | 1681007.421 | `0x616687936e994ea7` |
| 2048 | 2000 | 5 | True | 2471036417.400 | 603.280 | 1657604.061 | `0x616cccb9bf70f11d` |

## Deterministic snapshots

| iterations | signature | hash64 | crc32 | output words |
|---:|---|---|---|---:|
| 1 | `8af14fda9e06cb7d3680744433b14568bec25e49c8c2fd6292e47e608be93880` | `0x48094a062c30500b` | `0x55240770` | 8 |
| 7 | `32c1fdad8879363993edcb124fb01021a262ab71917a0f3495f3644838fbdcb1` | `0x935007b0c01b9ef3` | `0xc31b8f1a` | 8 |
| 42 | `3526b64e02a3a4dfa9eb5cecf9d4a7bf349a9f6889431f9bb4fe03248d4b3ddd` | `0xfc5292d2abaf7399` | `0x8a85a32a` | 8 |
| 128 | `7702c246822d356ee0bed310fee360f6bf77a6efafa4afe17a286941cd23edfe` | `0x2920cf2a09d109f3` | `0xbcbe6d15` | 8 |
| 512 | `a8d24bf4d62d33aee2a0e97d363b0f7b552ef81caa547121b76c833529c83736` | `0x5b5dfeff9c777502` | `0xc2048fc5` | 8 |
| 2048 | `b63b248b64e9701251b68384e3754d8ba84cba230339d669715a4543be945775` | `0xc26db88744eb54fe` | `0x6780a8b6` | 8 |

## Specialized analysis notes

- This workflow creates artifacts for performance, binary size, determinism, state quality, portability and CI reproducibility.
- Repeated samples for each benchmark case are asserted against deterministic snapshot signatures.
- These are not universal hardware claims; they are runner-relative measurements intended for regression tracking.
- The next stronger benchmark layer should compare Python reference, portable C, x86_64 ASM and Android ARM64/ARM32 paths.
- Market-grade claims require fixed hardware, pinned compiler, repeated cold/warm runs and baseline competitors.
