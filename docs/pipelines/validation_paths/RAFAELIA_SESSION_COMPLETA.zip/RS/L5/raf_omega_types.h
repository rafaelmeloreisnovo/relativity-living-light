/*
 * raf_omega_types.h — tipos RAFAELIA Ω
 * Q16.16 fixed-point · zero float64 no hot path · ARM32/ARM64/x86_64
 * SPDX-License-Identifier: GPL-3.0-only
 * Conforma: ARM IHI 0042J · IEEE Std 1003.1-2017 · NIST SP 800-175B
 */
#pragma once
#ifndef RAF_OMEGA_TYPES_H
#define RAF_OMEGA_TYPES_H

#include <stdint.h>
#include <stddef.h>

/* ── portable raw write ─────────────────────────────────────────────── */
#include <unistd.h>   /* ssize_t write() — include first to avoid redecl */
#define _RAF_WRITE(fd,buf,n) ((void)write((fd),(buf),(size_t)(n)))

/* ── primitivos sem ambiguidade ─────────────────────────────────────────── */
typedef uint8_t   u8;   typedef int8_t   i8;
typedef uint16_t  u16;  typedef int16_t  i16;
typedef uint32_t  u32;  typedef int32_t  i32;
typedef uint64_t  u64;  typedef int64_t  i64;
typedef float     f32;
/* f64 PROIBIDO no hot path: 2× custo em softfp ARM32 — usar Q16.16 */

/* ── Q16.16 fixed-point ─────────────────────────────────────────────────── */
/* 1 unidade = 65536 · range ±32767.999 · resolução 0.0000152... */
#define Q16_ONE    65536u
#define Q16_HALF   32768u
#define Q16_QTR    16384u
#define Q16_SPIRAL 56755u   /* sqrt(3)/2 = 0.8660254 */
#define Q16_PHI    105965u  /* (1+sqrt(5))/2 = 1.6180339 */
#define Q16_PI     205887u  /* pi = 3.1415926 */
#define Q16_2PI    411774u  /* 2*pi */
#define Q16_INV6   10923u   /* 1/6  (Taylor sin) */
#define Q16_INV120 546u     /* 1/120 (Taylor sin) */
#define Q16_SQRT2  92682u   /* sqrt(2) */
#define Q16_E      178145u  /* e = 2.71828 */
#define Q16_LN2    45426u   /* ln(2) */
#define Q16_ALPHA  16384u   /* EMA alpha=0.25 */

/* ── status ─────────────────────────────────────────────────────────────── */
#define RAF_OK    0
#define RAF_ERR  -1
#define RAF_FULL -2
#define RAF_IO   -3
#define RAF_FMT  -4

/* ── atributos ──────────────────────────────────────────────────────────── */
#define ALIGN64  __attribute__((aligned(64)))
#define ALIGN16  __attribute__((aligned(16)))
#define ALIGN4   __attribute__((aligned(4)))
#define FORCEINL __attribute__((always_inline)) static inline
#define NOINL    __attribute__((noinline))
#define PACKED   __attribute__((packed))
#define PURE     __attribute__((pure))
#define CONST    __attribute__((const))
#define LIKELY(x)   __builtin_expect(!!(x),1)
#define UNLIKELY(x) __builtin_expect(!!(x),0)

/* ── constantes do sistema ──────────────────────────────────────────────── */
#define RAF_PERIOD    42u     /* ciclo RAFAELIA */
#define RAF_TORUS_DIM  7u     /* T^7 */
#define RAF_N_VCPU     8u     /* vCPUs */
#define RAF_N_STACKS 1000u    /* 10×10×10 */
#define RAF_N_EXTRA    8u     /* +8 */
#define RAF_N_TOTAL  1008u    /* BitRAF total */
#define RAF_BITS_PT   42u     /* bits por ponto BitRAF */
#define RAF_STRIDE     7u     /* stride coprime com 1000 */
#define RAF_CACHE_LN  64u     /* cache line bytes */
#define RAF_ARENA_SZ  (4u*1024u*1024u)  /* 4MB BSS */
#define RAF_VECDB_CAP 4000000u
#define RAF_SOM_DIM    8u
#define RAF_SOM_N    512u     /* 8^3 */
#define RAF_SEM_SDIM 256u     /* SemanticNode semantic dims */
#define RAF_SEM_PDIM  64u     /* prosody dims */
#define RAF_SEM_EDIM  32u     /* emotion dims */
#define RAF_SEM_CDIM 128u     /* context dims */
#define RAF_N_ATTR    42u     /* attractor basins */
#define RAF_FIB_CAP   64u     /* Fibonacci-Rafael cache */
#define RAF_CHAIN_CAP 65536u
#define RAF_NEXUS_CAP 100000u

/* ── Q16.16 arithmetic ──────────────────────────────────────────────────── */
/* ALL branchless — no if/else on hot path */

FORCEINL u32 qmul(u32 a, u32 b){
    return (u32)(((u64)a*b)>>16);
}
FORCEINL u32 qdiv(u32 a, u32 b){
    if(UNLIKELY(b==0)) return 0;
    return (u32)(((u64)a<<16)/b);
}
FORCEINL u32 qadd_sat(u32 a, u32 b){
    u32 r=a+b;
    /* saturate at 0xFFFFFFFF: if overflow, r < a */
    u32 ov=(u32)-(i32)(r<a);
    return r|ov;
}
FORCEINL u32 qsub_sat(u32 a, u32 b){
    u32 ov=(u32)-(i32)(a<b);
    return (a-b)&~ov;
}
/* EMA: 0.75*old + 0.25*in — no division, no float */
FORCEINL u32 qema(u32 old, u32 in){
    return (u32)(((u64)old*49152u+(u64)in*16384u)>>16);
}
FORCEINL u32 qema_alpha(u32 old, u32 in, u32 alpha_q16){
    u32 inv=Q16_ONE-alpha_q16;
    return (u32)(((u64)old*inv+(u64)in*alpha_q16)>>16);
}
/* branchless abs for signed Q16 */
FORCEINL u32 qabs(i32 v){
    i32 mask=v>>31;
    return (u32)((v^mask)-mask);
}
/* branchless min/max */
FORCEINL u32 qmin(u32 a, u32 b){
    u32 d=a-b; u32 m=(u32)((i32)d>>31);
    return b+(d&m);
}
FORCEINL u32 qmax(u32 a, u32 b){
    u32 d=b-a; u32 m=(u32)((i32)d>>31);
    return a+(d&m);
}
FORCEINL u32 qclamp(u32 v, u32 lo, u32 hi){
    return qmax(lo,qmin(hi,v));
}
/* branchless sign: returns Q16_ONE if v>=0, 0 if v<0 */
FORCEINL u32 qsign(i32 v){
    return (u32)(~((u32)(v>>31))&Q16_ONE);
}

/* ── sin Taylor Q16.16 — 5 termos, domínio público ──────────────────────── */
/* Erro < 0.0003 no intervalo [0, 2π] */
FORCEINL u32 qsin(u32 x){
    /* reduz ao domínio [0, 2π] — loop simples (baixo overhead) */
    while(UNLIKELY(x>=Q16_2PI)) x-=Q16_2PI;
    /* mapeia [π, 2π] → negativo com flag branchless */
    u32 neg=(x>=Q16_PI);
    x-=neg*Q16_PI;
    u64 x2=(u64)x*x>>16;
    u64 x3=(u64)x2*x>>16;
    u64 x5=(u64)x3*x2>>16;
    u64 t1=(u64)x3*Q16_INV6>>16;
    u64 t2=(u64)x5*Q16_INV120>>16;
    i64 r=(i64)x-(i64)t1+(i64)t2;
    r=(r<0)?0:(r>65535)?65535:r;
    /* branchless negate: 65535-r if neg==1, else r */
    return (u32)(neg*(65535u-(u32)r)+(1u-neg)*(u32)r);
}
FORCEINL u32 qcos(u32 x){
    u32 shifted=(x+Q16_HALF)%(Q16_2PI);
    return qsin(shifted);
}

/* ── Newton-Raphson rsqrt Q16.16 — 4 iterações ───────────────────────────*/
/* Sem sqrtf — puro integer + multiply */
FORCEINL u32 qrsqrt(u32 x){
    if(UNLIKELY(x==0)) return 0;
    /* estimativa inicial: divide por 2 e usa shift */
    u32 est=Q16_ONE;
    u32 half_x=x>>1;
    /* 4 iterações: est = est*(3/2 - (x/2)*est^2) em Q16 */
    for(int _=0;_<4;_++){
        u32 e2=qmul(est,est);
        u32 xe2=qmul(half_x,e2);
        u32 t=(3u*Q16_HALF)-xe2;
        est=qmul(est,t);
    }
    return est;
}
FORCEINL u32 qsqrt(u32 x){
    return qmul(x,qrsqrt(x));
}

/* ── Montgomery multiplication mod p ────────────────────────────────────── */
/* Para operações de campo: a*b*R^-1 mod p, R=2^32 */
FORCEINL u32 montgomery_mul(u32 a, u32 b, u32 p, u32 p_inv){
    u64 t=(u64)a*b;
    u32 m=(u32)t*p_inv;
    u32 u=(u32)((t+(u64)m*p)>>32);
    return u>=p?u-p:u;
}

/* ── bit ops branchless ─────────────────────────────────────────────────── */
FORCEINL u32 popcount32(u32 x){
    x=x-((x>>1)&0x55555555u);
    x=(x&0x33333333u)+((x>>2)&0x33333333u);
    x=(x+(x>>4))&0x0F0F0F0Fu;
    return (x*0x01010101u)>>24;
}
FORCEINL u32 clz32(u32 x){
    /* branchless CLZ using de Bruijn sequence */
    x|=x>>1; x|=x>>2; x|=x>>4; x|=x>>8; x|=x>>16;
    static const u8 debruijn[32]={
        0,31,9,30,3,8,13,29,2,5,7,21,12,24,28,19,
        1,10,4,14,6,22,25,16,11,23,26,17,27,18,15,20};
    return debruijn[(u32)(x*0x07C4ACDDu)>>27];
}
FORCEINL u32 bitrev32(u32 x){
    x=((x>>1)&0x55555555u)|((x&0x55555555u)<<1);
    x=((x>>2)&0x33333333u)|((x&0x33333333u)<<2);
    x=((x>>4)&0x0F0F0F0Fu)|((x&0x0F0F0F0Fu)<<4);
    x=((x>>8)&0x00FF00FFu)|((x&0x00FF00FFu)<<8);
    return (x>>16)|(x<<16);
}
/* bit interleave: 16 bits from a, 16 from b → 32 bit morton code */
FORCEINL u32 bit_interleave(u16 a, u16 b){
    u32 x=a, y=b;
    x=(x|(x<<8))&0x00FF00FFu;
    x=(x|(x<<4))&0x0F0F0F0Fu;
    x=(x|(x<<2))&0x33333333u;
    x=(x|(x<<1))&0x55555555u;
    y=(y|(y<<8))&0x00FF00FFu;
    y=(y|(y<<4))&0x0F0F0F0Fu;
    y=(y|(y<<2))&0x33333333u;
    y=(y|(y<<1))&0x55555555u;
    return x|(y<<1);
}

/* ── CRC32C Castagnoli RFC 3720 §B.4 ────────────────────────────────────── */
/* Poly 0x82F63B78 (reversed 0x1EDC6F41) — domínio público, NIST SP 800-175B */
static u32 _crc_tab[256];
static int _crc_ready=0;
FORCEINL void crc32c_init(void){
    for(u32 i=0;i<256u;i++){
        u32 v=i;
        for(int j=0;j<8;j++) v=(v&1u)?(v>>1)^0x82F63B78u:(v>>1);
        _crc_tab[i]=v;
    }
    _crc_ready=1;
}
FORCEINL u32 crc32c(const void *buf, u32 n){
    if(UNLIKELY(!_crc_ready)) crc32c_init();
    const u8 *p=(const u8*)buf; u32 c=~0u;
    while(n--) c=(c>>8)^_crc_tab[(c^*p++)&0xFFu];
    return ~c;
}
/* Hardware CRC32C where available */
#if defined(__aarch64__) || defined(ARCH_ARM64)
static inline u32 crc32c_hw(const u8 *p, u32 n){
    u32 c=0xFFFFFFFFu;
    while(n>=4){ u32 w; __builtin_memcpy(&w,p,4);
        __asm__ volatile("crc32cw %w0,%w0,%w1":"+r"(c):"r"(w)); p+=4; n-=4; }
    while(n--){ __asm__ volatile("crc32cb %w0,%w0,%w1":"+r"(c):"r"((u32)*p++)); }
    return c^0xFFFFFFFFu;
}
#elif defined(__x86_64__) || defined(ARCH_X86_64)
static inline u32 crc32c_hw(const u8 *p, u32 n){
    u64 c=0xFFFFFFFFull;
    while(n>=8){ u64 q; __builtin_memcpy(&q,p,8);
        __asm__ volatile("crc32q %1,%0":"+r"(c):"r"(q)); p+=8; n-=8; }
    while(n--){ __asm__ volatile("crc32b %1,%0":"+r"(c):"m"(*p++)); }
    return (u32)(c^0xFFFFFFFFull);
}
#else
#define crc32c_hw crc32c
#endif

/* ── AETHER hash — 64-bit ────────────────────────────────────────────────── */
FORCEINL u64 aether_hash(const u8 *p, u32 n){
    u64 h=0xA3B195354A39B70Dull;
    while(n--){ h^=(h<<7)^(h>>3)^(u64)(*p*131u); h*=0x9E3779B97F4A7C15ull; p++; }
    return h^(h>>32);
}
/* dual: CRC32c ⊕ AETHER */
FORCEINL u64 dual_hash(const u8 *p, u32 n){
    return (u64)crc32c_hw(p,n)^aether_hash(p,n);
}
/* snapshot hash64: state hash for determinism benchmark */
FORCEINL u64 snapshot_hash64(const void *buf, u32 n){
    const u8 *p=(const u8*)buf;
    u64 h=0xCBF29CE484222325ull; u64 fnv=1099511628211ull;
    while(n--){ h^=(u64)*p; h*=fnv; p++; }
    return h^(h>>33);
}

/* ── write primitives — zero printf, zero stdlib ──────────────────────────*/
/* raw write — declared before use to avoid implicit decl warning */
static void ws(const char *s){
    if(!s) return;
    size_t n=0; while(s[n]) n++;
    _RAF_WRITE(1,s,n);
}
static void wn(void){ _RAF_WRITE(1,"\n",1); }
static void wc(char c){ _RAF_WRITE(1,&c,1); }
static const char _HEX[]="0123456789ABCDEF";
static void write_hex8(u8 v){
    char b[2]; b[0]=_HEX[v>>4]; b[1]=_HEX[v&0xF]; _RAF_WRITE(1,b,2);
}
static void write_hex32(u32 v){
    char b[8];
    for(int i=7;i>=0;i--){ b[i]=_HEX[v&0xF]; v>>=4; }
    _RAF_WRITE(1,b,8);
}
static void write_hex64(u64 v){
    write_hex32((u32)(v>>32)); write_hex32((u32)v);
}
static void write_dec(u64 v){
    if(v==0){ wc('0'); return; }
    char b[20]; int i=0;
    while(v){ b[i++]=(char)('0'+v%10u); v/=10u; }
    while(i-->0) wc(b[i]);
}
/* write Q16.16 as decimal with 4 decimal places */
static void write_q16(u32 q){
    write_dec(q>>16); wc('.');
    u32 frac=(q&0xFFFFu)*10000u>>16;
    char b[4];
    b[3]=(char)('0'+frac%10); frac/=10;
    b[2]=(char)('0'+frac%10); frac/=10;
    b[1]=(char)('0'+frac%10); frac/=10;
    b[0]=(char)('0'+frac%10);
    _RAF_WRITE(1,b,4);
}

#endif /* RAF_OMEGA_TYPES_H */
