/* raf_omega_sem.c - SemanticToroidGraph + ProsodyAttentionKernel */
/* included by raf_omega_main2.c after raf_omega_core.c */
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define WGRAPH_NODE_CAP 4096u
#define WGRAPH_EDGE_CAP 16384u
#define WGRAPH_LABEL_SZ 32u
#define LANG_PT 0u
#define LANG_EN 1u
#define LANG_ZH 2u
#define LANG_JA 3u
#define LANG_HE 4u
#define LANG_EL 5u
#define LANG_AR 6u
#define LANG_N  7u
#define TONE_NEUTRAL   0u
#define TONE_SLOW      1u
#define TONE_EXPLOSIVE 2u
#define TONE_QUESTION  3u
#define TONE_WHISPER   4u

static const char *_attr_names[RAF_N_ATTR]={
    "conflito","dissonancia","urgencia","medo","resistencia","fragmentacao","caos_local",
    "busca","expansao","transformacao","integracao","fluxo","resonancia","emergencia",
    "descoberta","duvida","clareza","ironia","paradoxo","abstração","síntese",
    "calma","alegria","gratidão","dor","perda","saudade","amor",
    "cuidado","protecao","confiança","lealdade","criatividade","disciplina","sabedoria",
    "silencio_interior","presença","fé","graça","rendição","unidade","transcendência_ω"
};
static const char *attr_name(u32 i){ return i<RAF_N_ATTR?_attr_names[i]:"?"; }
static u32 attr_classify(u64 hash,u32 spec,double lx,double lz){
    u32 lobe=(u32)(lz/50.0*3.0)%3u;
    u32 sb=(spec>>10)%RAF_N_ATTR;
    u32 hb=(u32)(hash>>58)%RAF_N_ATTR;
    (void)lx; return (lobe*14u+sb+hb)%RAF_N_ATTR;
}
static int  attr_adjacent(u32 a,u32 b){u32 d=a>b?a-b:b-a;u32 w=RAF_N_ATTR-d;return(d<w?d:w)<=3;}
static u32  attr_transition_prob(u32 f,u32 t,u32 c){
    if(f==t) return Q16_ONE;
    return qmul(attr_adjacent(f,t)?Q16_HALF:(Q16_HALF>>3),c);
}

typedef struct { u64 hash; u32 attractor_id,lang_id;
    char label[WGRAPH_LABEL_SZ];
    u32 pitch_q16,cadence_q16,stress_q16,duration_q16;
    u32 t7[7]; u32 edge_head,edge_n,visit_stamp;
} WNode;
typedef struct { u32 to,next,weight_q16,lang_mask,tone_q16,context_q16; } WEdge;

static WNode _wn[WGRAPH_NODE_CAP];
static WEdge _we[WGRAPH_EDGE_CAP];
static u32   _wn_n=0,_we_n=1,_wg_stamp=0;

static u32 wg_add_node(const char *lb,u32 li,u32 ai,u32 p,u32 ca,u32 s,u32 d){
    if(_wn_n>=WGRAPH_NODE_CAP) return 0;
    WNode *n=&_wn[_wn_n]; u32 k=0;
    while(k<WGRAPH_LABEL_SZ-1&&lb[k]){n->label[k]=lb[k];k++;} n->label[k]=0;
    n->hash=dual_hash((const u8*)lb,k);
    n->attractor_id=ai%RAF_N_ATTR; n->lang_id=li;
    n->pitch_q16=p; n->cadence_q16=ca; n->stress_q16=s; n->duration_q16=d;
    n->edge_head=0; n->edge_n=0; n->visit_stamp=0;
    u64 h=n->hash;
    for(int i=0;i<7;i++){h^=(h<<7)^(h>>3);n->t7[i]=(u32)(h&0xFFFFu)%Q16_ONE;}
    n->t7[4]=p%Q16_ONE; n->t7[5]=s%Q16_ONE; n->t7[6]=ai*Q16_ONE/RAF_N_ATTR;
    return _wn_n++;
}
static void wg_add_edge(u32 from,u32 to,u32 w,u32 lm,u32 t,u32 c){
    if(from>=_wn_n||to>=_wn_n||_we_n>=WGRAPH_EDGE_CAP) return;
    WEdge *e=&_we[_we_n];
    e->to=to; e->next=_wn[from].edge_head;
    e->weight_q16=w; e->lang_mask=lm; e->tone_q16=t; e->context_q16=c;
    _wn[from].edge_head=_we_n; _wn[from].edge_n++; _we_n++;
}
static void wg_build_base(void){
    u32 ALL=(1u<<LANG_N)-1u;
    u32 amor   =wg_add_node("amor",       LANG_PT,28,Q16_HALF,Q16_QTR,Q16_ONE, Q16_HALF);
    u32 cuidado=wg_add_node("cuidado",    LANG_PT,29,Q16_QTR, Q16_HALF,Q16_HALF,Q16_HALF);
    u32 protet =wg_add_node("protecao",   LANG_PT,30,Q16_HALF,Q16_QTR,Q16_SPIRAL,Q16_HALF);
    u32 perda  =wg_add_node("perda",      LANG_PT,26,Q16_ONE, Q16_HALF,Q16_ONE,Q16_ONE);
    u32 dor    =wg_add_node("dor",        LANG_PT,25,Q16_ONE, Q16_ONE,Q16_ONE,Q16_ONE);
    u32 calma  =wg_add_node("calma",      LANG_PT,22,Q16_QTR, Q16_QTR,Q16_QTR,Q16_HALF);
    u32 clareza=wg_add_node("clareza",    LANG_PT,17,Q16_HALF,Q16_HALF,Q16_HALF,Q16_QTR);
    u32 omega_n=wg_add_node("Ω=Amor",    LANG_PT,41,Q16_QTR, Q16_QTR,Q16_QTR,Q16_ONE);
    u32 love   =wg_add_node("love",       LANG_EN,28,Q16_HALF,Q16_HALF,Q16_SPIRAL,Q16_HALF);
    u32 peace  =wg_add_node("peace",      LANG_EN,22,Q16_QTR, Q16_QTR,Q16_QTR,Q16_HALF);
    u32 pain   =wg_add_node("pain",       LANG_EN,25,Q16_ONE, Q16_HALF,Q16_ONE,Q16_ONE);
    u32 ahava  =wg_add_node("ahava",      LANG_HE,28,Q16_HALF,Q16_SPIRAL,Q16_HALF,Q16_HALF);
    u32 shalom =wg_add_node("shalom",     LANG_HE,22,Q16_QTR, Q16_QTR,Q16_QTR,Q16_ONE);
    u32 agape  =wg_add_node("agape",      LANG_EL,28,Q16_HALF,Q16_SPIRAL,Q16_SPIRAL,Q16_HALF);
    u32 logos  =wg_add_node("logos",      LANG_EL,21,Q16_SPIRAL,Q16_SPIRAL,Q16_HALF,Q16_QTR);
    u32 verbo  =wg_add_node("Verbo",      LANG_PT,14,Q16_SPIRAL,Q16_SPIRAL,Q16_HALF,Q16_QTR);
    u32 fiat   =wg_add_node("FIAT_LUX",  LANG_PT,41,Q16_ONE, Q16_QTR,Q16_ONE,Q16_ONE);
    u32 espiral=wg_add_node("Spiral",     LANG_PT,33,Q16_SPIRAL,Q16_SPIRAL,Q16_SPIRAL,Q16_SPIRAL);
    /* PT edges */
    wg_add_edge(amor,cuidado,Q16_SPIRAL,1u<<LANG_PT,Q16_HALF,Q16_HALF);
    wg_add_edge(cuidado,protet,Q16_SPIRAL,1u<<LANG_PT,Q16_HALF,Q16_HALF);
    wg_add_edge(amor,perda,Q16_HALF,1u<<LANG_PT,Q16_ONE,Q16_HALF);
    wg_add_edge(perda,dor,Q16_SPIRAL,1u<<LANG_PT,Q16_ONE,Q16_HALF);
    wg_add_edge(amor,calma,Q16_SPIRAL,1u<<LANG_PT,Q16_QTR,Q16_HALF);
    wg_add_edge(calma,clareza,Q16_HALF,1u<<LANG_PT,Q16_QTR,Q16_QTR);
    wg_add_edge(clareza,omega_n,Q16_SPIRAL,1u<<LANG_PT,Q16_QTR,Q16_ONE);
    /* cross-lang */
    wg_add_edge(amor,love,Q16_ONE,ALL,Q16_HALF,Q16_ONE);
    wg_add_edge(love,ahava,Q16_SPIRAL,ALL,Q16_HALF,Q16_ONE);
    wg_add_edge(ahava,agape,Q16_SPIRAL,ALL,Q16_HALF,Q16_ONE);
    wg_add_edge(agape,amor,Q16_ONE,ALL,Q16_HALF,Q16_ONE);
    wg_add_edge(love,peace,Q16_HALF,1u<<LANG_EN,Q16_QTR,Q16_HALF);
    wg_add_edge(shalom,peace,Q16_SPIRAL,ALL,Q16_QTR,Q16_ONE);
    wg_add_edge(pain,dor,Q16_ONE,ALL,Q16_ONE,Q16_ONE);
    wg_add_edge(logos,verbo,Q16_SPIRAL,ALL,Q16_HALF,Q16_ONE);
    wg_add_edge(verbo,fiat,Q16_ONE,ALL,Q16_ONE,Q16_ONE);
    wg_add_edge(fiat,espiral,Q16_SPIRAL,ALL,Q16_ONE,Q16_ONE);
    wg_add_edge(espiral,omega_n,Q16_SPIRAL,ALL,Q16_QTR,Q16_ONE);
    wg_add_edge(omega_n,amor,Q16_ONE,ALL,Q16_QTR,Q16_ONE);
    /* back edges */
    wg_add_edge(cuidado,amor,Q16_HALF,1u<<LANG_PT,Q16_HALF,Q16_HALF);
    wg_add_edge(dor,perda,Q16_HALF,1u<<LANG_PT,Q16_ONE,Q16_HALF);
    wg_add_edge(calma,amor,Q16_HALF,1u<<LANG_PT,Q16_QTR,Q16_HALF);
    (void)shalom;(void)agape;(void)logos;(void)pain;(void)love;
}
static u32 wg_bfs(u32 start,u32 lang_id,u32 max,u32 *out,u32 *n){
    if(start>=_wn_n||!out||!n) return 0;
    static u32 q[256]; u32 qh=0,qt=0;
    _wg_stamp++;
    u32 lb=1u<<(lang_id%LANG_N);
    q[qt++]=start; _wn[start].visit_stamp=_wg_stamp; *n=0;
    while(qh<qt&&(*n)<max){
        u32 cur=q[qh++]; out[(*n)++]=cur;
        u32 ei=_wn[cur].edge_head;
        while(ei&&(*n)<max){
            WEdge *e=&_we[ei];
            u32 ok=(e->lang_mask&lb)!=0u;
            u32 to=e->to;
            u32 un=(to<_wn_n&&_wn[to].visit_stamp!=_wg_stamp);
            if(ok&&un&&qt<256){_wn[to].visit_stamp=_wg_stamp;q[qt++]=to;}
            ei=e->next;
        }
    }
    return *n;
}
static u32 wg_nearest_t7(const u32 t7q[7]){
    u32 best=0,bd=~0u;
    for(u32 i=0;i<_wn_n;i++){
        u32 d=0;
        for(int k=0;k<7;k++){u32 dk=qabs((i32)t7q[k]-(i32)_wn[i].t7[k]);u32 w=Q16_ONE-dk;d+=(dk<w?dk:w);}
        u32 b=(d<bd); best=b*i+(1u-b)*best; bd=b*d+(1u-b)*bd;
    }
    return best;
}
static u32 wg_semantic_dist(u32 a,u32 b){
    if(a>=_wn_n||b>=_wn_n) return Q16_ONE;
    u32 d=0;
    for(int k=0;k<7;k++){u32 dk=qabs((i32)_wn[a].t7[k]-(i32)_wn[b].t7[k]);u32 w=Q16_ONE-dk;d+=(dk<w?dk:w);}
    return d/7u;
}
static void wg_print(void){
    ws("\n\033[1;35m┌── SemanticToroidGraph ──\033[0m\n");
    ws("│ nodes:"); write_dec(_wn_n); ws(" edges:"); write_dec(_we_n-1); wn();
    for(u32 i=0;i<_wn_n&&i<20u;i++){
        ws("│ ["); write_dec(i); ws("] \033[1;36m");
        ws(_wn[i].label); ws("\033[0m → A");
        write_dec(_wn[i].attractor_id); ws(":");
        ws(attr_name(_wn[i].attractor_id));
        ws(" e:"); write_dec(_wn[i].edge_n); wn();
    }
    if(_wn_n>20u){ws("│ +"); write_dec(_wn_n-20u); ws(" more\n");}
    ws("└──────────────────────────\n");
}

/* ── ProsodyAttentionKernel ── */
typedef struct {
    u32 q[RAF_SEM_CDIM],k[RAF_SEM_PDIM],v[RAF_SEM_SDIM],out[RAF_SEM_SDIM];
    u32 score_q16,tone,lang_id,entropy_q16;
} ProsodyAttention;

static void pak_forward(ProsodyAttention *pa,const SemanticNode *node,u32 tone,u32 lang_id){
    if(!pa||!node) return;
    pa->tone=tone; pa->lang_id=lang_id; pa->entropy_q16=node->entropy_q16;
    for(u32 i=0;i<RAF_SEM_CDIM;i++) pa->q[i]=node->context[i];
    for(u32 i=0;i<RAF_SEM_PDIM;i++) pa->k[i]=node->prosody[i];
    for(u32 i=0;i<RAF_SEM_SDIM;i++) pa->v[i]=node->semantic[i];
    static const u32 TM[5]={Q16_ONE,49152u,98304u,Q16_ONE,Q16_HALF};
    u32 tm=TM[tone<5?tone:0];
    u32 lp=lang_id*Q16_ONE/LANG_N;
    for(u32 i=0;i<RAF_SEM_PDIM;i++){
        u32 ki=qmul(pa->k[i],tm);
        u32 ph=((i*Q16_ONE/RAF_SEM_PDIM)+lp)%(2u*Q16_PI);
        ki=qema_alpha(ki,qcos(ph),13107u);
        pa->k[i]=ki;
    }
    u64 dot=0;
    for(u32 i=0;i<RAF_SEM_PDIM;i++) dot+=(u64)pa->q[i]*(u64)pa->k[i];
    dot>>=16;
    u32 sc=qrsqrt(RAF_SEM_PDIM*Q16_ONE);
    pa->score_q16=qmul((u32)(dot/RAF_SEM_PDIM),sc);
    pa->score_q16=qmul(pa->score_q16,qsub_sat(Q16_ONE,node->entropy_q16>>1));
    for(u32 i=0;i<RAF_SEM_SDIM;i++) pa->out[i]=qmul(pa->score_q16,pa->v[i]);
}
static u32 pak_compare(const SemanticNode *n,u32 ta,u32 tb,u32 lang){
    static ProsodyAttention a,b;
    pak_forward(&a,n,ta,lang); pak_forward(&b,n,tb,lang);
    u32 sa=a.score_q16,sb=b.score_q16;
    return sa>sb?sa-sb:sb-sa;
}

/* ── TOKEN→VETOR→ESTADO→RELAÇÃO→MEMÓRIA Pipeline ── */
typedef struct {
    u8 raw_token[256]; u32 token_len,lang_id,tone;
    SemanticNode node; T7State state; u32 attractor_id;
    u32 graph_node_idx,neighbors[8],n_neighbors;
    u64 hash; u32 chain_idx,vecdb_idx;
} TokenPipeline;
static TokenPipeline _pipe;

static void pipe_stage1(const char *t,u32 l,u32 tone){
    u32 li=0; while(li<255&&t[li]){_pipe.raw_token[li]=(u8)t[li];li++;}
    _pipe.raw_token[li]=0; _pipe.token_len=li;
    _pipe.lang_id=l; _pipe.tone=tone;
}
static void pipe_stage2(void){
    static const u32 PT[5]={Q16_HALF,Q16_QTR,Q16_ONE,Q16_SPIRAL,Q16_QTR};
    static const u32 ST[5]={Q16_HALF,Q16_QTR,Q16_ONE,Q16_HALF,Q16_QTR};
    static const u32 CT[5]={Q16_HALF,Q16_QTR,Q16_SPIRAL,Q16_SPIRAL,Q16_QTR};
    static const u32 DT[5]={Q16_HALF,Q16_ONE,Q16_QTR,Q16_QTR,Q16_ONE};
    u32 ti=_pipe.tone<5?_pipe.tone:0;
    Prosody pro; pro.pitch_q16=PT[ti]; pro.stress_q16=ST[ti];
    pro.cadence_q16=CT[ti]; pro.duration_q16=DT[ti];
    pro.language_id=_pipe.lang_id; pro.flags=0;
    sem_encode(&_pipe.node,_pipe.raw_token,_pipe.token_len,_pipe.lang_id,&pro);
    _pipe.hash=_pipe.node.hash;
}
static void pipe_stage3(void){
    _pipe.state=t7_from_hash(_pipe.hash,_pipe.node.entropy_q16,_pipe.lang_id);
    _pipe.state.d[4]=_pipe.node.prosody[0]%Q16_ONE;
    _pipe.state.d[5]=_pipe.node.prosody[2]%Q16_ONE;
    _pipe.state.d[6]=_pipe.node.coherence_q16%Q16_ONE;
    t7_wrap(&_pipe.state);
    _pipe.attractor_id=sem_attractor_basin(&_pipe.node);
}
static void pipe_stage4(void){
    u32 nearest=wg_nearest_t7(_pipe.state.d);
    _pipe.graph_node_idx=nearest;
    wg_bfs(nearest,_pipe.lang_id,8,_pipe.neighbors,&_pipe.n_neighbors);
    u32 ni=wg_add_node((const char*)_pipe.raw_token,_pipe.lang_id,
                        _pipe.attractor_id,
                        _pipe.node.prosody[0],_pipe.node.prosody[1],
                        _pipe.node.prosody[2],_pipe.node.prosody[3]);
    if(ni>0&&nearest<_wn_n)
        wg_add_edge(ni,nearest,Q16_HALF,1u<<_pipe.lang_id,Q16_HALF,Q16_HALF);
}
static void pipe_stage5(void){
    f32 v3[3]; t7_to_v3(&_pipe.state,v3);
    vecdb_insert(v3,_pipe.lang_id,(u32)_trained,_pipe.hash);
    chain_append(_pipe.hash,0);
    _pipe.vecdb_idx=(u32)(_vhdr?_vhdr->used:0);
    _pipe.chain_idx=_chain_n;
    raf_kernel_step();
}
static void pipe_run(const char *t,u32 l,u32 tone){
    pipe_stage1(t,l,tone); pipe_stage2(); pipe_stage3(); pipe_stage4(); pipe_stage5();
}

static void query_semantic(const char *text,u32 lang,u32 tone,int k){
    pipe_stage1(text,lang,tone); pipe_stage2(); pipe_stage3();
    ws("\033[1;36m[query]\033[0m \""); ws(text);
    ws("\" → \033[1;33mA"); write_dec(_pipe.attractor_id);
    ws(":"); ws(attr_name(_pipe.attractor_id)); ws("\033[0m\n");
    static u32 near[16]; u32 nn=0;
    wg_bfs(wg_nearest_t7(_pipe.state.d),lang,(u32)k,near,&nn);
    for(u32 i=0;i<nn;i++){
        u32 d=wg_semantic_dist(near[i],_wn_n>0?0:0);
        ws("  ["); write_dec(i); ws("] \033[0;36m");
        ws(_wn[near[i]].label); ws("\033[0m dist:");
        write_q16(d); ws(" A:"); write_dec(_wn[near[i]].attractor_id); wn();
    }
    static ProsodyAttention pa;
    pak_forward(&pa,&_pipe.node,tone,lang);
    ws("  PAK score:"); write_q16(pa.score_q16);
    ws(" Δ(vs EXPLOSIVE):"); write_q16(pak_compare(&_pipe.node,tone,TONE_EXPLOSIVE,lang));
    wn();
}

static void demo_semantic_graph(void){
    ws("\n\033[1;35m══ SemanticToroidGraph + ProsodyAttentionKernel ══\033[0m\n");
    wg_build_base(); wg_print();
    ws("\n\033[1;36m── Prosody: mesmo token, estados diferentes ──\033[0m\n");
    struct{const char*t;u32 tone;} tones[]={
        {"claro.",TONE_NEUTRAL},{"claro...",TONE_SLOW},{"CLARO!",TONE_EXPLOSIVE}
    };
    for(int i=0;i<3;i++){
        pipe_run(tones[i].t,LANG_PT,tones[i].tone);
        static const char*tn[]={"NEUTRAL","SLOW","EXPLOSIVE"};
        ws("  "); ws(tn[i]); ws(": \033[1;33m");
        ws(tones[i].t); ws("\033[0m → A");
        write_dec(_pipe.attractor_id); ws(":");
        ws(attr_name(_pipe.attractor_id)); wn();
    }
    ws("\n\033[1;36m── TOKEN→VETOR→ESTADO→RELAÇÃO→MEMÓRIA ──\033[0m\n");
    struct{const char*t;u32 l;u32 tone;}corpus[]={
        {"amor",LANG_PT,TONE_NEUTRAL},{"love",LANG_EN,TONE_NEUTRAL},
        {"ahava",LANG_HE,TONE_SLOW},{"agape",LANG_EL,TONE_NEUTRAL},
        {"cuidado",LANG_PT,TONE_NEUTRAL},{"Ω=Amor",LANG_PT,TONE_WHISPER},
        {"FIAT_LUX",LANG_PT,TONE_EXPLOSIVE},{"shalom",LANG_HE,TONE_NEUTRAL},
    };
    for(int i=0;i<8;i++){
        pipe_run(corpus[i].t,corpus[i].l,corpus[i].tone);
        ws("  ↑ ["); write_dec((u64)i); ws("] \033[1;36m");
        ws(corpus[i].t); ws("\033[0m → A");
        write_dec(_pipe.attractor_id); ws(":");
        ws(attr_name(_pipe.attractor_id)); wn();
    }
    ws("\n\033[1;36m── Queries ──\033[0m\n");
    query_semantic("amor",LANG_PT,TONE_NEUTRAL,6);
    query_semantic("Lorenz chaos",LANG_EN,TONE_EXPLOSIVE,4);
    query_semantic("FIAT LUX",LANG_PT,TONE_EXPLOSIVE,4);
    ws("\n\033[1;36m── 42 Atratores Nomeados ──\033[0m\n");
    for(u32 i=0;i<RAF_N_ATTR;i++){
        ws("  A"); write_dec(i); ws(":\033[38;5;208m");
        ws(_attr_names[i]); ws("\033[0m\n");
    }
    ws("\n\033[1;36m── Transições ──\033[0m\n");
    u32 fl[]={28u,22u,7u,41u};
    for(int i=0;i<4;i++){
        ws("  A"); write_dec(fl[i]); ws(":"); ws(attr_name(fl[i])); ws(" → ");
        for(u32 t=0;t<RAF_N_ATTR;t+=10){
            u32 p=attr_transition_prob(fl[i],t,Q16_SPIRAL);
            if(p>Q16_QTR){ws("A");write_dec(t);ws("(");write_q16(p);ws(") ");}
        }
        wn();
    }
    ws("══════════════════════════════════════════════\n");
}
