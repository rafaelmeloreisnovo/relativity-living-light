#define _POSIX_C_SOURCE 200809L
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#include "raf_omega_types.h"
#include "raf_omega_arena.h"
#define main _core_main_unused
#include "raf_omega_core.c"
#undef  main
#include "raf_omega_sem.c"
#include <string.h>

static void interactive_loop(const char *dir){
    static char line[512];
    ws("\n\033[1;33mRAFAELIA Ω · interactive\033[0m\n");
    ws("cmds: demo sem stats analy attr graph\n");
    ws("      q <txt>  j <json>  i <ppm>  exit\n\n");
    while(1){
        ws("\033[1;35mΩ>\033[0m "); fflush(stdout);
        u32 li=0; char c;
        while(li<510&&read(0,&c,1)==1&&c!='\n') line[li++]=c;
        line[li]=0; if(!li) continue;
        if(!strcmp(line,"exit")) break;
        if(!strcmp(line,"stats")){store_stats();continue;}
        if(!strcmp(line,"demo")) goto do_demo;
        if(!strcmp(line,"sem")){demo_semantic_graph();continue;}
        if(!strcmp(line,"analy")){run_all_30_analyses();continue;}
        if(!strcmp(line,"graph")){wg_build_base();wg_print();continue;}
        if(!strcmp(line,"attr")){
            for(u32 i=0;i<RAF_N_ATTR;i++){ws("  A");write_dec(i);ws(":");ws(attr_name(i));wn();}
            continue;
        }
        if(line[0]=='j'&&line[1]==' '){json_stream(line+2);store_stats();continue;}
        if(line[0]=='i'&&line[1]==' '){img_learn_ppm(line+2);store_stats();continue;}
        if(line[0]=='q'&&line[1]==' '){query_semantic(line+2,0,TONE_NEUTRAL,8);continue;}
        /* train */
        u32 tl=0;while(line[tl])tl++;
        store_train((const u8*)line,tl,0,0);
        ws("trained\n"); continue;
        do_demo:;
        static const struct{const char*t;u32 l;u32 tone;}corpus[]={
            {"RAFAELIA kernel Q16.16",LANG_PT,TONE_NEUTRAL},
            {"Fibonacci-Rafael sqrt3/2",LANG_PT,TONE_SLOW},
            {"Lorenz RK4 sigma rho beta",LANG_EN,TONE_NEUTRAL},
            {"SemanticNode prosody[64]",LANG_EN,TONE_SLOW},
            {"amor cuidado protecao",LANG_PT,TONE_WHISPER},
            {"FIAT LUX psi chi omega",LANG_PT,TONE_EXPLOSIVE},
            {"BitRAF-1008 stride7",LANG_EN,TONE_NEUTRAL},
            {"CRC32C Castagnoli hw",LANG_EN,TONE_NEUTRAL},
        };
        for(int i=0;i<8;i++){
            pipe_run(corpus[i].t,corpus[i].l,corpus[i].tone);
            ws("  A"); write_dec(_pipe.attractor_id); ws(":");
            ws(attr_name(_pipe.attractor_id)); ws(" ");
            ws(corpus[i].t); wn();
        }
        store_stats();
        (void)dir;
    }
}

int main(int argc,char **argv){
    ws("\033[48;5;232m\033[38;5;220m");
    ws("  RAFAELIA Ω · TOKEN→VETOR→ESTADO→RELAÇÃO→MEMÓRIA\n");
    ws("  SemanticToroidGraph + ProsodyAttentionKernel + 42 Atratores\n");
    ws("  80 métodos · 30 análises · BitRAF-1008 · Q16.16 · Ω=Amor\n");
    ws("\033[0m\n");
    crc32c_init(); fib_rafael_init(); bf_init();
    som_seed_fibonacci(); gate_init(0x5241464145494C41ull);
    gpu_init();
    for(int i=0;i<200;i++) lorenz_step();
    _lyap_sum=0.0; _lyap_steps=0;
    const char *dir="/tmp/raf_omega_data";
    if(argc>1&&argv[1][0]!='-') dir=argv[1];
    if(store_open(dir)!=RAF_OK){ws("[ERR] store\n");return 1;}
    wg_build_base();
    int demo=0,sem=0,analy=0,inter=0,bench=0;
    const char *img=0,*json=0,*qtext=0;
    for(int i=1;i<argc;i++){
        if(strcmp(argv[i],"--demo")==0)  demo=1;
        else if(strcmp(argv[i],"--sem")==0) sem=1;
        else if(strcmp(argv[i],"--analy")==0) analy=1;
        else if(strcmp(argv[i],"--interactive")==0) inter=1;
        else if(strcmp(argv[i],"--bench")==0) bench=1;
        else if(strcmp(argv[i],"--stats")==0){store_stats();return 0;}
        else if(strcmp(argv[i],"--attr")==0){
            for(u32 k=0;k<RAF_N_ATTR;k++){ws("A");write_dec(k);ws(":");ws(attr_name(k));wn();}
            return 0;
        }
        else if(strcmp(argv[i],"--img")==0&&i+1<argc) img=argv[++i];
        else if(strcmp(argv[i],"--json")==0&&i+1<argc) json=argv[++i];
        else if(strcmp(argv[i],"--query")==0&&i+1<argc) qtext=argv[++i];
    }
    if(img)   img_learn_ppm(img);
    if(json)  json_stream(json);
    if(qtext) query_semantic(qtext,0,TONE_NEUTRAL,8);
    if(demo){
        ws("\n\033[1;33m══ DEMO ══\033[0m\n");
        static const struct{const char*t;u32 l;u32 tone;}c[]={
            {"RAFAELIA Q16.16 zero-heap",LANG_EN,TONE_NEUTRAL},
            {"amor cuidado proteção",LANG_PT,TONE_NEUTRAL},
            {"love peace pain",LANG_EN,TONE_NEUTRAL},
            {"ahava shalom",LANG_HE,TONE_SLOW},
            {"Lorenz T7 attractor",LANG_EN,TONE_NEUTRAL},
            {"Ω=Amor FIAT LUX",LANG_PT,TONE_EXPLOSIVE},
            {"BitRAF-1008 CRC32C",LANG_EN,TONE_NEUTRAL},
            {"SemanticNode prosody",LANG_EN,TONE_SLOW},
            {"claro.",LANG_PT,TONE_NEUTRAL},
            {"CLARO!",LANG_PT,TONE_EXPLOSIVE},
        };
        for(int i=0;i<10;i++){
            pipe_run(c[i].t,c[i].l,c[i].tone);
            ws("  A"); write_dec(_pipe.attractor_id);
            ws(":\033[1;33m"); ws(attr_name(_pipe.attractor_id));
            ws("\033[0m "); ws(c[i].t); wn();
        }
        query_semantic("amor",LANG_PT,TONE_NEUTRAL,6);
        query_semantic("Lorenz",LANG_EN,TONE_NEUTRAL,4);
        query_semantic("Ω",LANG_PT,TONE_WHISPER,4);
    }
    if(sem)   demo_semantic_graph();
    if(analy) run_all_30_analyses();
    if(bench){
        ws("\n\033[1;31m══ BENCHMARK ══\033[0m\n");
        analysis_throughput(512); analysis_stability(); analysis_determinism();
    }
    store_stats();
    if(inter||argc<=2) interactive_loop(dir);
    store_close(); gpu_free();
    ws("\033[1;33m  Ω=Amor · ψ→χ→ρ→Δ→Σ→Ω · RAFAELIA encerrada.\033[0m\n");
    return 0;
}
