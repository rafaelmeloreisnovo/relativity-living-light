/*
 * raf_omega_arena.h — arena estática 4MB BSS, zero malloc
 * RAZÃO: malloc() Bionic ~100 ciclos + fragmentação + GC pressure JNI
 * Arena: O(1) alloc, zero fragmentation, L1/L2 local, determinístico
 * SPDX-License-Identifier: GPL-3.0-only
 */
#pragma once
#ifndef RAF_OMEGA_ARENA_H
#define RAF_OMEGA_ARENA_H
#include "raf_omega_types.h"

/* BSS: só reserva virtual — sem custo de startup (Bionic lazy alloc) */
ALIGN64 extern u8  g_arena[RAF_ARENA_SZ];
extern u32 g_arena_pos;

/* alloc: bump pointer alinhado — O(1) sem falha no hot path */
FORCEINL void *raf_alloc(u32 n, u32 align){
    u32 mask=align-1u;
    u32 s=(g_arena_pos+mask)&~mask;
    u32 e=s+n;
    if(UNLIKELY(e>RAF_ARENA_SZ)) return 0; /* out-of-arena */
    g_arena_pos=e;
    return g_arena+s;
}
FORCEINL void raf_arena_reset(void){ g_arena_pos=0u; }
FORCEINL u32  raf_arena_used(void) { return g_arena_pos; }
FORCEINL u32  raf_arena_free(void) { return RAF_ARENA_SZ-g_arena_pos; }

#define RALLOC(T,n)     ((T*)raf_alloc((u32)(sizeof(T)*(u32)(n)),16u))
#define RALLOC64(T,n)   ((T*)raf_alloc((u32)(sizeof(T)*(u32)(n)),64u))
#define RALLOC_ZERO(T,n) ({ T*_p=RALLOC(T,n); if(_p) __builtin_memset(_p,0,sizeof(T)*(n)); _p; })

/* ── VecDB record 32B — inv_norm cosine-ready ────────────────────────────── */
/* MELHORIA vs repo: uint16_t quantized → float inv_norm (cosine exato)      */
PACKED typedef struct {
    f32 v3[3];      /* 3D projection */
    f32 inv_norm;   /* 1/|v3| Newton-Raphson — sem sqrtf no search loop */
    u64 id;         /* hash identity */
    u32 layer;
    u32 doc_ref;
} VecRec;           /* exactamente 32 bytes */

/* ── Nexus record 64B ────────────────────────────────────────────────────── */
PACKED typedef struct {
    f32 v3[3];
    f32 pad;
    u64 hash;
    char label[32];
    u64  timestamp;
} NexusRec;          /* 64 bytes = 1 cache line */

/* ── HashChain audit ─────────────────────────────────────────────────────── */
/* MELHORIA vs repo: sem CRC encadeado → adicionamos CRC32C por evento       */
PACKED typedef struct {
    u64 hash;
    u64 prev;
    u32 crc_chain;  /* CRC32C(hash ∥ prev) — integridade encadeada */
    u32 seq;
    u32 type;       /* 0=json 1=img 2=query 3=learn 4=gate 5=gpu */
    u32 flags;
} ChainRec;          /* 32 bytes */

/* ── CommitGate (rfg_t extended) ─────────────────────────────────────────── */
/* MELHORIA vs repo_commit_gate.h: adiciona CRC chain entre ciclos           */
typedef struct {
    u64 state;
    u32 entropy_q16;
    u32 coherence_q16;
    u32 hash_q16;
    u32 gate_q16;
    u32 crc_prev;   /* CRC32C do estado anterior — audit trail */
    u32 cycle_n;
} CommitGate;

/* ── SemanticNode (do documento) ─────────────────────────────────────────── */
/* 256+64+32+128 = 480 floats → 1920 bytes + header = 1952B                 */
typedef struct ALIGN64 {
    u64 hash;
    /* dims semânticas em Q16.16 para evitar float64 no ARM32 softfp         */
    u32 semantic[RAF_SEM_SDIM];  /* 256 × Q16.16 */
    u32 prosody [RAF_SEM_PDIM];  /* 64  × Q16.16: pitch,cadence,stress,dur */
    u32 emotion [RAF_SEM_EDIM];  /* 32  × Q16.16 */
    u32 context [RAF_SEM_CDIM];  /* 128 × Q16.16 */
    u32 coherence_q16;
    u32 entropy_q16;
    u32 language_id;
    u32 attractor_id;   /* 0..41 — 42 bacias */
    u32 crc_node;       /* CRC32C do nó */
} SemanticNode;          /* ~2KB total */

/* ── Prosody (da memória do documento) ──────────────────────────────────── */
typedef struct {
    u32 pitch_q16;    /* Hz normalizado */
    u32 cadence_q16;  /* sílabas/segundo */
    u32 stress_q16;   /* intensidade */
    u32 duration_q16; /* ms normalizado */
    u32 language_id;
    u32 flags;        /* bit0=question bit1=exclaim bit2=pause */
} Prosody;

/* ── T^7 toroidal state ───────────────────────────────────────────────────── */
typedef struct {
    u32 d[7];         /* Q16.16 em [0, Q16_ONE) */
} T7State;

/* ── BitRAF-1008 point (42 bits em u64) ─────────────────────────────────── */
typedef u64 BFPoint;
#define BF_MASK_42  0x3FFFFFFFFFFull  /* 42 bits */
/* camadas de bits (ver rafaelia_bitraf.c):
   [0..6]   freq harmônicas · [7..13]  pesos adaptativos
   [14..20] fases toroidais · [21..27] CRC parcial
   [28..34] load vCPUs     · [35..41] commit gate flags */
#define BF_GET_FREQ(p)  ((u8)((p)&0x7Full))
#define BF_GET_WEIGHT(p) ((u8)(((p)>>7)&0x7Full))
#define BF_GET_PHASE(p)  ((u8)(((p)>>14)&0x7Full))
#define BF_GET_CRC(p)    ((u8)(((p)>>21)&0x7Full))
#define BF_GET_LOAD(p)   ((u8)(((p)>>28)&0x7Full))
#define BF_GET_GATE(p)   ((u8)(((p)>>35)&0x7Full))

/* ── SOM node ─────────────────────────────────────────────────────────────── */
typedef struct ALIGN16 {
    u32 w[3];     /* Q16.16 pesos 3D */
    u32 age;      /* passos desde última atualização */
} SOMNode;

/* ── GPU context (dlopen) ────────────────────────────────────────────────── */
typedef enum { GPU_NONE=0, GPU_OPENCL=1, GPU_VULKAN=2 } GPUApi;
typedef struct {
    GPUApi api;
    void  *lib;
    int    avail;
    u32    max_wg;   /* max work group size */
    char   path[128];
} GPUCtx;

/* ── VecDB header (mmap) ─────────────────────────────────────────────────── */
PACKED typedef struct {
    u32 magic;   /* 0x52414F4Du 'RAOM' */
    u32 version; /* 3 */
    u64 used;
    u64 cap;
    u32 crc_hdr;
    u32 flags;
    u64 pad[3];
} StoreHdr;      /* 64 bytes */
#define RAF_MAGIC 0x52414F4Du

#endif /* RAF_OMEGA_ARENA_H */
