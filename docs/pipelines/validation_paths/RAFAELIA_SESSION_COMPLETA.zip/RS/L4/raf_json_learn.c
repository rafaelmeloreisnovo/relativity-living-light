/*
 * raf_json_learn.c — ingestão JSON schema-aware
 * ──────────────────────────────────────────────
 * Schema: rafaelia_schema.json (id, type, role, text,
 *         images, links, tags, symbols, ethica,
 *         discernment{serpent,dove,curvature,fit}, weight, hash)
 *
 * MELHORIA vs build_dataset.py / raf_ingest_bridge.py existentes:
 *   ANTES: Python script, requer runtime, sem toroide
 *   AGORA: C puro, zero dep, schema-aware → T^7 projection
 *
 * Pipeline por evento:
 *   JSON text field  → dual_hash → 3D base
 *   discernment.serpent/dove → dims 4,5 do T^7
 *   weight → dim 6 do T^7
 *   ethica[] → reforço Hebbian por dimensão ética
 *   symbols[] → nexus anchor
 *
 * Streaming: processa arquivo de 1.5GB em chunks de 64KB
 * Zero malloc: static buffers para parse e tokens
 */
#include "raf_toroid_ai.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

/* ════════════════════════════════════════════════════
 * MINI JSON PARSER (zero alloc, sem recursão profunda)
 * Extrai campos do rafaelia_schema.json flat ou aninhado
 * ════════════════════════════════════════════════════ */

/* encontra "key": e retorna ponteiro para o valor */
static const char *_jfield(const char *json, const char *key) {
    static char search[128];
    snprintf(search,sizeof(search),"\"%s\":",key);
    return strstr(json,search);
}

/* extrai string de "key":"value" → out[cap] */
static int _jstr(const char *json, const char *key, char *out, int cap) {
    const char *p=_jfield(json,key);
    if(!p) return 0;
    p+=strlen(key)+3; /* skip "key": */
    if(*p!='"') return 0;
    p++;
    int i=0;
    while(*p&&*p!='"'&&i<cap-1) out[i++]=*p++;
    out[i]=0;
    return i;
}

/* extrai número float de "key": value */
static float _jfloat(const char *json, const char *key, float def) {
    const char *p=_jfield(json,key);
    if(!p) return def;
    p+=strlen(key)+2; /* skip "key": */
    while(*p==' ') p++;
    if(*p=='"') p++;
    return (float)atof(p);
}

/* extrai int/enum de "key":"str_val" → index */
static uint8_t _jtype(const char *json) {
    char buf[32]={0};
    _jstr(json,"type",buf,32);
    if(!strcmp(buf,"message"))        return 0;
    if(!strcmp(buf,"conversation"))   return 1;
    if(!strcmp(buf,"metric_event"))   return 2;
    if(!strcmp(buf,"dashboard_event"))return 3;
    if(!strcmp(buf,"index_event"))    return 4;
    return 5; /* raw_event */
}

/*
 * Extrai array de strings: ["a","b","c"] → out[max_n][item_sz]
 * Retorna count.
 */
static int _jarray_str(const char *json, const char *key,
                        char out[][32], int max_n, int item_sz) {
    const char *p=_jfield(json,key);
    if(!p) return 0;
    p+=strlen(key)+2;
    while(*p&&*p!='[') p++;
    if(*p!='[') return 0;
    p++;
    int n=0;
    while(*p&&*p!=']'&&n<max_n){
        while(*p==' '||*p==','||*p=='\n') p++;
        if(*p=='"'){
            p++;
            int i=0;
            while(*p&&*p!='"'&&i<item_sz-1) out[n][i++]=*p++;
            out[n][i]=0;
            if(*p=='"') p++;
            n++;
        } else p++;
    }
    return n;
}

/* parse discernment object: {serpent, dove, curvature, fit} */
static void _jdiscern(const char *json, ToraEvent *ev) {
    /* find "discernment":{ ... } */
    const char *p=strstr(json,"\"discernment\":");
    if(!p) return;
    p+=14;
    while(*p&&*p!='{') p++;
    if(*p!='{') return;
    /* extract from substring */
    char sub[256]; int i=0;
    p++;
    while(*p&&*p!='}'&&i<254) sub[i++]=*p++;
    sub[i]=0;
    ev->serpent   =_jfloat(sub,"serpent",0.5f);
    ev->dove      =_jfloat(sub,"dove",0.5f);
    ev->curvature =_jfloat(sub,"curvature",0.0f);
    ev->fit       =_jfloat(sub,"fit",1.0f);
}

/* ── parse one JSON event object ─────────────────── */
ToraStatus tora_json_parse_event(const char *json, size_t len, ToraEvent *ev) {
    if(!json||!ev||!len) return TORA_ERR_NULL;
    memset(ev,0,sizeof(*ev));
    ev->weight=1.0f; ev->serpent=0.5f; ev->dove=0.5f; ev->fit=1.0f;

    /* static sub-buffer for safe parsing */
    static char jbuf[8192];
    size_t cp=(len<8191)?len:8191;
    memcpy(jbuf,json,cp); jbuf[cp]=0;

    _jstr(jbuf,"id",ev->id,65);
    ev->type=_jtype(jbuf);
    _jstr(jbuf,"role",ev->role,16);
    _jstr(jbuf,"text",ev->text,1024);
    _jstr(jbuf,"hash",ev->hash_field,65);
    ev->weight=_jfloat(jbuf,"weight",1.0f);
    if(ev->weight<0.1f) ev->weight=0.1f;
    if(ev->weight>3.0f) ev->weight=3.0f;

    _jdiscern(jbuf,ev);
    ev->tag_n    =(uint8_t)_jarray_str(jbuf,"tags",   ev->tags,   8,32);
    ev->symbol_n =(uint8_t)_jarray_str(jbuf,"symbols",ev->symbols,8,16);
    ev->ethica_n =(uint8_t)_jarray_str(jbuf,"ethica", ev->ethica, 8,32);

    return TORA_OK;
}

/* ════════════════════════════════════════════════════
 * LEARN ONE EVENT
 * Traduz ToraEvent → T^7 vector → VecDB + SOM + chain
 * ════════════════════════════════════════════════════ */

ToraStatus tora_json_learn_event(ToraCtx *ctx, const ToraEvent *ev) {
    if(!ctx||!ev) return TORA_ERR_NULL;

    /* 1. hash text (primary semantic content) */
    const char *text = ev->text[0] ? ev->text : ev->id;
    uint64_t h=tora_hash_dual((const uint8_t*)text, strlen(text));

    /* 2. T^7 projection using schema fields */
    float v7[TORA_VEC_DIM];
    tora_project_7d(h, ev->type, ev->serpent, ev->dove,
                    ev->weight, v7);

    /* 3. blend curvature into dim 3 */
    v7[3] = 0.7f*v7[3] + 0.3f*ev->curvature;

    /* 4. use first 3 dims for VecDB 3D search */
    float v3[3]={v7[0],v7[1],v7[2]};

    /* 5. insert into VecDB */
    tora_vecdb_insert(ctx,v3,(uint32_t)ev->type,
                      (uint32_t)ctx->json_trained, h);

    /* 6. online learning */
    tora_learn_step(ctx,v3,h);

    /* 7. ethica dimensions → extra SOM updates with modulated weight */
    for(int i=0;i<ev->ethica_n;i++){
        uint64_t eh=tora_hash_dual((const uint8_t*)ev->ethica[i],
                                    strlen(ev->ethica[i]));
        float ev3[3]; tora_project_3d(eh,ev3);
        /* blend with main vector (weighted by serpent/dove) */
        float alpha=ev->dove; /* dove = harmony weight */
        ev3[0]=alpha*ev3[0]+(1-alpha)*v3[0];
        ev3[1]=alpha*ev3[1]+(1-alpha)*v3[1];
        ev3[2]=alpha*ev3[2]+(1-alpha)*v3[2];
        tora_som_update(ctx,ev3);
    }

    /* 8. symbols → nexus anchors (persistent attention seeds) */
    for(int i=0;i<ev->symbol_n;i++){
        if(ctx->nexus_hdr->used>=ctx->nexus_hdr->cap) break;
        uint64_t sh=tora_hash_dual((const uint8_t*)ev->symbols[i],
                                    strlen(ev->symbols[i]));
        float sv3[3]; tora_project_3d(sh,sv3);
        ToraRec *r=&ctx->nexus_recs[ctx->nexus_hdr->used++];
        r->v3[0]=sv3[0]; r->v3[1]=sv3[1]; r->v3[2]=sv3[2];
        r->inv_norm=tora_inv_norm3(sv3);
        r->id=sh; r->layer=ev->type; r->doc_ref=(uint32_t)ctx->json_trained;
    }

    /* 9. chain audit */
    tora_chain_log(ctx,h,0); /* type=0 → json */

    ctx->json_trained++;
    return TORA_OK;
}

/* ════════════════════════════════════════════════════
 * STREAMING FILE INGESTION — handles 1.5GB
 * 64KB chunks with 512B overlap, zero full-load
 * Detects JSON objects by balanced brace counting
 * ════════════════════════════════════════════════════ */

#define JSON_CHUNK   (64*1024)
#define JSON_OVERLAP 512
#define JSON_OBJ_MAX (8*1024) /* max single event JSON size */

ToraStatus tora_json_learn_stream(ToraCtx *ctx, const char *path) {
    if(!ctx||!path) return TORA_ERR_NULL;
    FILE *f=fopen(path,"rb");
    if(!f){ fprintf(stderr,"[json] cannot open %s\n",path); return TORA_ERR_IO; }

    static char buf[JSON_CHUNK+JSON_OVERLAP+2];
    static char obj[JSON_OBJ_MAX+2];
    uint64_t chunks=0, events=0;
    size_t overlap=0;

    while(1){
        size_t nr=fread(buf+overlap,1,JSON_CHUNK,f);
        if(!nr) break;
        size_t total=overlap+nr;
        buf[total]=0;

        /* scan for JSON objects {  ...  } */
        size_t i=0;
        while(i<total){
            /* find opening { */
            while(i<total&&buf[i]!='{') i++;
            if(i>=total) break;

            /* balance braces to find end of object */
            int depth=0;
            size_t start=i, end=0;
            while(i<total&&(end==0)){
                char c=buf[i];
                if(c=='{') depth++;
                else if(c=='}'){
                    depth--;
                    if(depth==0) end=i+1;
                }
                i++;
            }

            if(end>start&&end-start<=JSON_OBJ_MAX){
                /* extract and parse */
                size_t olen=end-start;
                memcpy(obj,buf+start,olen); obj[olen]=0;

                ToraEvent ev;
                if(tora_json_parse_event(obj,olen,&ev)==TORA_OK){
                    /* skip empty events */
                    if(ev.text[0]||ev.id[0]||ev.ethica_n||ev.symbol_n){
                        tora_json_learn_event(ctx,&ev);
                        events++;
                    }
                }
            } else if(depth>0){
                /* incomplete object at end of chunk → keep in overlap */
                break;
            }
        }

        /* keep tail as overlap for next chunk */
        size_t keep=(total>JSON_OVERLAP)?JSON_OVERLAP:total;
        /* find last unprocessed { to anchor overlap */
        size_t tail_start=total-keep;
        memmove(buf,buf+tail_start,keep);
        overlap=keep;
        chunks++;

        if(chunks%100==0||events%1000==0)
            fprintf(stderr,"[json] chunks=%llu events=%llu vecdb=%llu\n",
                    (unsigned long long)chunks,
                    (unsigned long long)events,
                    (unsigned long long)ctx->vecdb_hdr->used);
    }

    fclose(f);
    fprintf(stderr,"[json] DONE  chunks=%llu  events=%llu  vecdb=%llu\n",
            (unsigned long long)chunks,
            (unsigned long long)events,
            (unsigned long long)ctx->vecdb_hdr->used);
    return TORA_OK;
}

/* ── single file (small, < 8KB per object) ────────── */
ToraStatus tora_json_learn_file(ToraCtx *ctx, const char *path) {
    return tora_json_learn_stream(ctx,path);
}
