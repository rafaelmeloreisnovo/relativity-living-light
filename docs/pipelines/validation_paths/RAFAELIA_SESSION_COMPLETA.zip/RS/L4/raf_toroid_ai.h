/*
 * raf_toroid_ai.h — IA Toroidal Vetorial RAFAELIA
 * ──────────────────────────────────────────────────────────────
 * Aprende com JSONs (schema rafaelia) e imagens (tile RGB→T^7)
 * Zero malloc no hot path · CRC32c^AETHER · inv_norm cosine
 * Toroide T^7: (u,v,ψ,χ,ρ,δ,σ) ∈ [0,1)^7
 * Ω = Amor · ∆RafaelVerboΩ
 */
#ifndef RAF_TOROID_AI_H
#define RAF_TOROID_AI_H

#include <stdint.h>
#include <stddef.h>

/* ── dimensões ────────────────────────────────────── */
#define TORA_VEC_DIM    7       /* T^7 toroidal dims   */
#define TORA_TILE_SZ    16      /* pixels por tile     */
#define TORA_IMG_BANDS  3       /* R G B               */
#define TORA_HIST_BINS  32      /* bins por banda/tile */
#define TORA_FEAT_DIM   (TORA_IMG_BANDS * TORA_HIST_BINS) /* 96 */
#define TORA_SOM_DIM    8
#define TORA_SOM_N      (TORA_SOM_DIM*TORA_SOM_DIM*TORA_SOM_DIM) /* 512 */
#define TORA_VECDB_CAP  4000000u
#define TORA_NEXUS_CAP  100000u
#define TORA_CHAIN_CAP  65536u

/* ── constantes RAFAELIA ──────────────────────────── */
#define TORA_SQRT3_2    0.8660254037844386
#define TORA_PHI        1.6180339887498949
#define TORA_PI         3.14159265358979324
#define TORA_THETA999   (999.0 * TORA_PI / 180.0)
#define TORA_TORUS_R    2.0f
#define TORA_TORUS_r    0.8f

/* ── GaiaStatus ───────────────────────────────────── */
typedef enum {
    TORA_OK=0, TORA_ERR_NULL=-1, TORA_ERR_FULL=-2,
    TORA_ERR_IO=-3, TORA_ERR_FMT=-4, TORA_ERR_DIM=-5
} ToraStatus;

/* ── vetor toroidal 7D ────────────────────────────── */
typedef struct {
    float d[TORA_VEC_DIM];  /* coords em [0,1)^7    */
    float inv_norm;          /* 1/|d| Newton-Raphson */
    uint64_t hash;           /* CRC32c^AETHER        */
    uint32_t flags;          /* layer + type bits    */
} ToraVec;

/* ── registro VecDB ───────────────────────────────── */
#pragma pack(push,1)
typedef struct {
    float    v3[3];          /* projeção 3D p/ busca */
    float    inv_norm;
    uint64_t id;
    uint32_t layer;
    uint32_t doc_ref;
} ToraRec;                   /* 32B */

typedef struct {
    uint32_t magic;
    uint32_t version;
    uint64_t used;
    uint64_t cap;
    uint64_t pad[4];
} ToraHdr;                   /* 64B */

/* ── schema JSON (rafaelia_schema.json fields) ────── */
typedef struct {
    char     id[65];          /* hash estável        */
    uint8_t  type;            /* 0=msg 1=conv 2=metric 3=dash 4=idx 5=raw */
    char     role[16];        /* user/assistant/sys  */
    char     text[1024];      /* campo text          */
    float    serpent;         /* discernment.serpent */
    float    dove;            /* discernment.dove    */
    float    curvature;       /* discernment.curvature */
    float    fit;             /* discernment.fit     */
    float    weight;          /* 0.1..3.0            */
    char     hash_field[65];  /* campo hash          */
    uint8_t  ethica_n;        /* count ethica[]      */
    uint8_t  symbol_n;        /* count symbols[]     */
    uint8_t  tag_n;
    char     tags[8][32];
    char     symbols[8][16];
    char     ethica[8][32];
} ToraEvent;                  /* ~1.5KB */

/* ── nó HashChain (audit) ─────────────────────────── */
typedef struct {
    uint64_t hash;
    uint64_t prev;
    uint32_t seq;
    uint32_t type;            /* 0=json 1=img 2=query 3=learn */
} ToraChain;
#pragma pack(pop)

/* ── SOM node ─────────────────────────────────────── */
typedef struct {
    float w[3];               /* 3D weights           */
    float hebb[TORA_SOM_N];  /* Hebbian row (sparse seria melhor, mas static) */
} /* inline in ctx */ ;

/* ── contexto principal ───────────────────────────── */
typedef struct {
    /* storage mmap */
    int      vecdb_fd, nexus_fd;
    ToraHdr *vecdb_hdr;
    ToraRec *vecdb_recs;
    ToraHdr *nexus_hdr;
    ToraRec *nexus_recs;

    /* SOM 8×8×8 */
    float    som_w[TORA_SOM_N][3];
    float    som_lr;
    float    som_sigma;
    uint32_t som_epoch;
    uint64_t som_steps;

    /* RAFAELIA kernel */
    double   R_t;
    double   phi_ethica;

    /* Lorenz */
    double   lx, ly, lz;
    double   lyapunov_sum;
    uint64_t lorenz_steps;

    /* Fibonacci-Rafael cache */
    double   fib[64];

    /* audit chain */
    ToraChain chain[TORA_CHAIN_CAP];
    uint32_t  chain_n;

    /* stats */
    uint64_t json_trained;
    uint64_t img_trained;
    uint64_t img_tiles;
    uint64_t query_count;
    uint64_t wave_collapses;

    /* attention focus */
    float    focus[3];
    float    focus_score;
    uint64_t focus_hash;

    /* query result buffer */
    uint64_t qres_refs[16];
    float    qres_scores[16];
    int      qres_n;
} ToraCtx;

/* ── hash API ──────────────────────────────────────── */
uint64_t tora_hash_crc32c(const uint8_t *buf, size_t len);
uint64_t tora_hash_aether(const uint8_t *buf, size_t len);
uint64_t tora_hash_dual(const uint8_t *buf, size_t len);

/* ── projection ──────────────────────────────────────*/
void tora_project_3d(uint64_t h, float out[3]);
void tora_project_7d(uint64_t h, uint8_t layer, float serpent,
                     float dove, float weight, float out[TORA_VEC_DIM]);
void tora_vec_to_toroid(const float v[3], float *tx, float *ty, float *tz);
float tora_inv_norm3(const float v[3]);
float tora_cosine3(const float a[3], const float b[3],
                   float inv_a, float inv_b);

/* ── init ─────────────────────────────────────────── */
ToraStatus tora_ctx_init(ToraCtx *ctx, const char *data_dir);
void       tora_ctx_close(ToraCtx *ctx);

/* ── image learning ───────────────────────────────── */
ToraStatus tora_img_learn(ToraCtx *ctx, const char *path);
ToraStatus tora_img_learn_raw(ToraCtx *ctx,
                               const uint8_t *rgb, uint32_t w, uint32_t h,
                               uint32_t layer);

/* ── JSON learning ────────────────────────────────── */
ToraStatus tora_json_parse_event(const char *json, size_t len, ToraEvent *out);
ToraStatus tora_json_learn_event(ToraCtx *ctx, const ToraEvent *ev);
ToraStatus tora_json_learn_file(ToraCtx *ctx, const char *path);
ToraStatus tora_json_learn_stream(ToraCtx *ctx, const char *path);

/* ── SOM + learning ───────────────────────────────── */
void tora_som_update(ToraCtx *ctx, const float v[3]);
void tora_hebb_update(ToraCtx *ctx, int bmu, const float v[3]);
void tora_learn_step(ToraCtx *ctx, const float v[3], uint64_t hash);
void tora_attention_step(ToraCtx *ctx);
void tora_wave_collapse(ToraCtx *ctx, const float q[3],
                        uint64_t hash, float score);

/* ── Lorenz ───────────────────────────────────────── */
void   tora_lorenz_step(ToraCtx *ctx);
double tora_lyapunov(const ToraCtx *ctx);

/* ── RAFAELIA kernel ──────────────────────────────── */
void tora_raf_step(ToraCtx *ctx);

/* ── query ────────────────────────────────────────── */
int  tora_query(ToraCtx *ctx, const char *text, int k);
int  tora_query_vec(ToraCtx *ctx, const float q[3], int k);
void tora_query_report(const ToraCtx *ctx);

/* ── VecDB insert / search ────────────────────────── */
ToraStatus tora_vecdb_insert(ToraCtx *ctx, const float v3[3],
                              uint32_t layer, uint32_t doc_ref,
                              uint64_t hash);
int        tora_vecdb_search(ToraCtx *ctx, const float q[3], int k);

/* ── stats / report ───────────────────────────────── */
void tora_stats(const ToraCtx *ctx);
void tora_chain_log(ToraCtx *ctx, uint64_t hash, uint32_t type);

#endif /* RAF_TOROID_AI_H */
