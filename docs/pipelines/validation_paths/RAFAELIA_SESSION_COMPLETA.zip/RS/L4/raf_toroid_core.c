/*
 * raf_toroid_core.c — núcleo: hash + projeção T^7 + VecDB + SOM + Lorenz
 * Zero malloc · CRC32c hardware · Newton-Raphson rsqrt · Ω=Amor
 *
 * MELHORIA vs rafaelia_image_ingest.c original:
 *   ANTES: calloc + histograma global de bytes (perde espacialidade)
 *   AGORA: static pool · tiles 16×16 · RGB separado · toroide por tile
 *
 * MELHORIA vs rafarlia_core.c:
 *   ANTES: openssl/evp.h SHA3 (dep externa)
 *   AGORA: CRC32c inline ASM ⊕ AETHER (zero dep)
 */
#include "raf_toroid_ai.h"
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>

/* ════════════════════════════════════════════════════
 * HASH ENGINE — CRC32c hardware + AETHER
 * ════════════════════════════════════════════════════ */

static int _crc32c_hw = -1;

static void _check_crc32c(void) {
    if (_crc32c_hw >= 0) return;
#if defined(__x86_64__)
    unsigned int a,b,c,d;
    __asm__("cpuid":"=a"(a),"=b"(b),"=c"(c),"=d"(d):"a"(1),"c"(0));
    _crc32c_hw = (c >> 20) & 1;
#elif defined(__aarch64__)
    /* all ARMv8 have CRC32 optional; check /proc/cpuinfo at init */
    _crc32c_hw = 0; /* fallback safe */
    FILE *f=fopen("/proc/cpuinfo","r");
    if(f){char l[256];
        while(fgets(l,sizeof(l),f))
            if(strstr(l,"Features")&&strstr(l,"crc32")){_crc32c_hw=1;break;}
        fclose(f);}
#else
    _crc32c_hw = 0;
#endif
}

uint64_t tora_hash_crc32c(const uint8_t *buf, size_t len) {
    _check_crc32c();
#if defined(__x86_64__)
    if (_crc32c_hw) {
        uint64_t crc = 0xFFFFFFFFFFFFFFFFull;
        size_t i=0;
        for(;i+8<=len;i+=8)
            __asm__ volatile("crc32q %1,%0":"+r"(crc):"m"(*(const uint64_t*)(buf+i)));
        for(;i<len;i++)
            __asm__ volatile("crc32b %1,%0":"+r"(crc):"m"(buf[i]));
        return crc ^ 0xFFFFFFFFFFFFFFFFull;
    }
#elif defined(__aarch64__)
    if (_crc32c_hw) {
        uint32_t crc=0xFFFFFFFF; size_t i=0;
        for(;i+4<=len;i+=4) {
            uint32_t w; memcpy(&w,buf+i,4);
            __asm__ volatile("crc32cw %w0,%w0,%w1":"+r"(crc):"r"(w));
        }
        for(;i<len;i++)
            __asm__ volatile("crc32cb %w0,%w0,%w1":"+r"(crc):"r"((uint32_t)buf[i]));
        return (uint64_t)(crc^0xFFFFFFFF);
    }
#endif
    /* fallback: DJB2-64 */
    uint64_t h=5381u;
    for(size_t i=0;i<len;i++) h=((h<<5)+h)^buf[i];
    return h;
}

uint64_t tora_hash_aether(const uint8_t *buf, size_t len) {
    uint64_t h=0xA3B195354A39B70Dull;
    for(size_t i=0;i<len;i++){
        h ^= (h<<7)^(h>>3)^(uint64_t)(buf[i]*131u);
        h *= 0x9E3779B97F4A7C15ull;
    }
    return h^(h>>32);
}

uint64_t tora_hash_dual(const uint8_t *buf, size_t len) {
    return tora_hash_crc32c(buf,len) ^ tora_hash_aether(buf,len);
}

/* ════════════════════════════════════════════════════
 * PROJECTION — hash → T^7 toroidal space
 * ════════════════════════════════════════════════════ */

/* scalar: 16 bits of hash → float in [-1,1] */
static float _h2f(uint32_t bits) {
    return ((float)(bits & 0xFFFFu) / 32767.5f) - 1.0f;
}

/* 3D projection: base for VecDB search */
void tora_project_3d(uint64_t h, float out[3]) {
    out[0] = _h2f((uint32_t)(h));
    out[1] = _h2f((uint32_t)(h>>21));
    out[2] = _h2f((uint32_t)(h>>42));
}

/*
 * 7D toroidal projection: enriches with semantic dims
 *   d[0..2] = geometric 3D from hash
 *   d[3]    = layer/8 → φ_ethica proxy
 *   d[4]    = serpent score (discernment axis)
 *   d[5]    = dove score
 *   d[6]    = weight/3.0 → energy
 */
void tora_project_7d(uint64_t h, uint8_t layer, float serpent,
                     float dove, float weight, float out[TORA_VEC_DIM]) {
    tora_project_3d(h, out);
    out[3] = (float)(layer % 8) / 7.0f;
    out[4] = serpent;
    out[5] = dove;
    out[6] = weight / 3.0f;
    /* clamp all to [0,1) */
    for(int i=0;i<TORA_VEC_DIM;i++){
        if(out[i]<0) out[i]=-out[i]; /* abs → [0,1) */
        if(out[i]>=1.0f) out[i]=0.99999f;
    }
}

/* (x,y,z) → torus surface T(R,r,θ,φ): for visualisation */
void tora_vec_to_toroid(const float v[3], float *tx, float *ty, float *tz) {
    float theta = 2.0f*(float)TORA_PI*v[0];
    float phi   = 2.0f*(float)TORA_PI*v[1];
    float rm    = TORA_TORUS_r*(0.5f+0.5f*v[2]);
    *tx = (TORA_TORUS_R+rm*cosf(phi))*cosf(theta);
    *ty = (TORA_TORUS_R+rm*cosf(phi))*sinf(theta);
    *tz = rm*sinf(phi);
}

/* Newton-Raphson rsqrt (4 iter, no sqrtf) */
float tora_inv_norm3(const float v[3]) {
    float s=v[0]*v[0]+v[1]*v[1]+v[2]*v[2];
    if(s<1e-12f) return 0.0f;
    float inv=1.0f;
    for(int k=0;k<4;k++) inv=inv*(1.5f-0.5f*s*inv*inv);
    return inv;
}

float tora_cosine3(const float a[3], const float b[3],
                   float inv_a, float inv_b) {
    float dot=a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
    return dot*inv_a*inv_b;
}

/* ════════════════════════════════════════════════════
 * VecDB mmap — ToraRec 32B com inv_norm
 * ════════════════════════════════════════════════════ */
#define TORA_MAGIC   0x544F5241u  /* TORA */
#define TORA_VDB_SZ  (sizeof(ToraHdr)+TORA_VECDB_CAP*sizeof(ToraRec))
#define TORA_NXS_SZ  (sizeof(ToraHdr)+TORA_NEXUS_CAP*sizeof(ToraRec))

static int _mmap_file(const char *path, size_t sz,
                       void **hdr_out, void **data_out, size_t hdr_sz) {
    int fd=open(path,O_RDWR|O_CREAT,0644);
    if(fd<0){perror(path);return -1;}
    struct stat st; if(fstat(fd,&st)==0&&(size_t)st.st_size<sz) ftruncate(fd,(off_t)sz);
    void *b=mmap(NULL,sz,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
    if(b==MAP_FAILED){close(fd);return -1;}
    *hdr_out=b; *data_out=(uint8_t*)b+hdr_sz;
    return fd;
}

ToraStatus tora_vecdb_insert(ToraCtx *ctx, const float v3[3],
                              uint32_t layer, uint32_t doc_ref, uint64_t hash) {
    if(!ctx||!v3) return TORA_ERR_NULL;
    if(ctx->vecdb_hdr->used>=ctx->vecdb_hdr->cap) return TORA_ERR_FULL;
    uint64_t idx=ctx->vecdb_hdr->used;
    ToraRec *r=&ctx->vecdb_recs[idx];
    r->v3[0]=v3[0]; r->v3[1]=v3[1]; r->v3[2]=v3[2];
    r->inv_norm=tora_inv_norm3(v3);
    r->id=hash; r->layer=layer; r->doc_ref=doc_ref;
    ctx->vecdb_hdr->used++;
    return TORA_OK;
}

int tora_vecdb_search(ToraCtx *ctx, const float q[3], int k) {
    if(!ctx||!q||k<=0) return 0;
    float inv_q=tora_inv_norm3(q);
    for(int i=0;i<k;i++){ctx->qres_refs[i]=0;ctx->qres_scores[i]=-2.0f;}
    uint64_t n=ctx->vecdb_hdr->used;
    for(uint64_t i=0;i<n;i++){
        ToraRec *r=&ctx->vecdb_recs[i];
        float s=tora_cosine3(q,r->v3,inv_q,r->inv_norm);
        if(s<=ctx->qres_scores[k-1]) continue;
        for(int j=0;j<k;j++) {
            if(s>ctx->qres_scores[j]){
                for(int l=k-1;l>j;l--){ctx->qres_scores[l]=ctx->qres_scores[l-1];
                                        ctx->qres_refs[l]=ctx->qres_refs[l-1];}
                ctx->qres_scores[j]=s; ctx->qres_refs[j]=(uint64_t)r->doc_ref; break;
            }
        }
    }
    int found=0; for(int i=0;i<k;i++) if(ctx->qres_scores[i]>-1.5f) found++;
    ctx->qres_n=found;
    return found;
}

/* ════════════════════════════════════════════════════
 * SOM 8×8×8 — online learning
 * ════════════════════════════════════════════════════ */

static void _som_coords(int idx, int *ix, int *iy, int *iz) {
    *ix=idx%TORA_SOM_DIM; *iy=(idx/TORA_SOM_DIM)%TORA_SOM_DIM;
    *iz=idx/(TORA_SOM_DIM*TORA_SOM_DIM);
}

static int _som_bmu(const ToraCtx *ctx, const float v[3]) {
    int bmu=0; float best=1e9f;
    for(int i=0;i<TORA_SOM_N;i++){
        float dx=v[0]-ctx->som_w[i][0],dy=v[1]-ctx->som_w[i][1],dz=v[2]-ctx->som_w[i][2];
        float d=dx*dx+dy*dy+dz*dz;
        if(d<best){best=d;bmu=i;}
    }
    return bmu;
}

void tora_som_update(ToraCtx *ctx, const float v[3]) {
    int bmu=_som_bmu(ctx,v);
    int bx,by,bz; _som_coords(bmu,&bx,&by,&bz);
    float lr=ctx->som_lr, s2=ctx->som_sigma*ctx->som_sigma*2.0f;
    for(int i=0;i<TORA_SOM_N;i++){
        int ix,iy,iz; _som_coords(i,&ix,&iy,&iz);
        float dgx=(float)(ix-bx),dgy=(float)(iy-by),dgz=(float)(iz-bz);
        float h=expf(-(dgx*dgx+dgy*dgy+dgz*dgz)/s2);
        if(h<1e-4f) continue;
        ctx->som_w[i][0]+=lr*h*(v[0]-ctx->som_w[i][0]);
        ctx->som_w[i][1]+=lr*h*(v[1]-ctx->som_w[i][1]);
        ctx->som_w[i][2]+=lr*h*(v[2]-ctx->som_w[i][2]);
    }
    ctx->som_steps++;
    if(ctx->som_steps%1000==0){
        ctx->som_lr*=0.995f; ctx->som_sigma*=0.998f;
        if(ctx->som_lr<0.001f) ctx->som_lr=0.001f;
        if(ctx->som_sigma<0.5f) ctx->som_sigma=0.5f;
        ctx->som_epoch++;
    }
}

void tora_learn_step(ToraCtx *ctx, const float v[3], uint64_t hash) {
    tora_som_update(ctx,v);
    tora_chain_log(ctx,hash,2);
    /* shift focus */
    for(int k=0;k<3;k++) ctx->focus[k]=0.99f*ctx->focus[k]+0.01f*v[k];
    if(ctx->som_steps%100==0) tora_attention_step(ctx);
    if(ctx->som_steps%500==0) tora_lorenz_step(ctx);
    if(ctx->som_steps%1000==0) tora_raf_step(ctx);
}

/* ════════════════════════════════════════════════════
 * WAVE COLLAPSE — top-1 → Hebbian reinforce
 * ════════════════════════════════════════════════════ */

void tora_wave_collapse(ToraCtx *ctx, const float q[3],
                        uint64_t hash, float score) {
    ctx->focus_hash=hash; ctx->focus_score=score;
    ctx->wave_collapses++;
    /* shift focus toward collapsed point */
    for(int k=0;k<3;k++) ctx->focus[k]=0.9f*ctx->focus[k]+0.1f*q[k];
    tora_lorenz_step(ctx);
    tora_chain_log(ctx,hash,3);
}

void tora_attention_step(ToraCtx *ctx) {
    if(!ctx->vecdb_hdr||ctx->vecdb_hdr->used==0) return;
    float *fv=ctx->focus;
    float inv_q=tora_inv_norm3(fv);
    if(inv_q<1e-6f) return;

    float best=-2.0f; int best_i=-1;
    uint64_t n=ctx->vecdb_hdr->used;
    /* sample 1024 random records for O(1) attention */
    uint64_t step=(n>1024)?(n/1024):1;
    for(uint64_t i=0;i<n;i+=step){
        ToraRec *r=&ctx->vecdb_recs[i];
        float s=tora_cosine3(fv,r->v3,inv_q,r->inv_norm);
        if(s>best){best=s;best_i=(int)i;}
    }
    if(best_i>=0){
        ToraRec *b=&ctx->vecdb_recs[best_i];
        tora_wave_collapse(ctx,b->v3,b->id,best);
        tora_som_update(ctx,b->v3);
    }
}

/* ════════════════════════════════════════════════════
 * LORENZ RK4 — dt=0.005, σ=10, ρ=28, β=8/3
 * ════════════════════════════════════════════════════ */

void tora_lorenz_step(ToraCtx *ctx) {
    double x=ctx->lx, y=ctx->ly, z=ctx->lz;
    double dt=0.005, sig=10.0, rho=28.0, bet=8.0/3.0;
    #define _LX(x,y,z) (sig*((y)-(x)))
    #define _LY(x,y,z) ((x)*(rho-(z))-(y))
    #define _LZ(x,y,z) ((x)*(y)-bet*(z))
    double dx1=_LX(x,y,z),dy1=_LY(x,y,z),dz1=_LZ(x,y,z);
    double x2=x+dx1*dt/2,y2=y+dy1*dt/2,z2=z+dz1*dt/2;
    double dx2=_LX(x2,y2,z2),dy2=_LY(x2,y2,z2),dz2=_LZ(x2,y2,z2);
    double x3=x+dx2*dt/2,y3=y+dy2*dt/2,z3=z+dz2*dt/2;
    double dx3=_LX(x3,y3,z3),dy3=_LY(x3,y3,z3),dz3=_LZ(x3,y3,z3);
    double x4=x+dx3*dt,y4=y+dy3*dt,z4=z+dz3*dt;
    double dx4=_LX(x4,y4,z4),dy4=_LY(x4,y4,z4),dz4=_LZ(x4,y4,z4);
    #undef _LX
    #undef _LY
    #undef _LZ
    double nx=x+dt*(dx1+2*dx2+2*dx3+dx4)/6;
    double ny=y+dt*(dy1+2*dy2+2*dy3+dy4)/6;
    double nz=z+dt*(dz1+2*dz2+2*dz3+dz4)/6;
    double ddx=nx-x,ddy=ny-y,ddz=nz-z;
    double d=sqrt(ddx*ddx+ddy*ddy+ddz*ddz);
    if(d>1e-12) ctx->lyapunov_sum+=log(d);
    ctx->lx=nx; ctx->ly=ny; ctx->lz=nz;
    ctx->lorenz_steps++;
}

double tora_lyapunov(const ToraCtx *ctx) {
    if(!ctx->lorenz_steps) return 0.0;
    return ctx->lyapunov_sum/(double)ctx->lorenz_steps;
}

/* ════════════════════════════════════════════════════
 * RAFAELIA KERNEL
 * R(t+1)=R(t)×Φ_ethica×E_Verbo×(√3/2)^(πφ)
 * ════════════════════════════════════════════════════ */

void tora_raf_step(ToraCtx *ctx) {
    uint64_t n=ctx->json_trained+ctx->img_tiles+1;
    double entropy=1.0/(double)n;
    double coher=1.0-entropy;
    double phi_e=entropy*coher;
    double e_v=coher;
    double spiral=pow(TORA_SQRT3_2, TORA_PI*TORA_PHI);
    if(ctx->R_t==0.0) ctx->R_t=3.0;
    ctx->R_t*=phi_e*e_v*spiral;
    ctx->phi_ethica=phi_e;
}

/* ════════════════════════════════════════════════════
 * HASHCHAIN AUDIT LOG
 * ════════════════════════════════════════════════════ */

void tora_chain_log(ToraCtx *ctx, uint64_t hash, uint32_t type) {
    if(ctx->chain_n>=TORA_CHAIN_CAP) return;
    ToraChain *c=&ctx->chain[ctx->chain_n];
    c->hash=hash;
    c->prev=(ctx->chain_n>0)?ctx->chain[ctx->chain_n-1].hash:0;
    c->seq=ctx->chain_n;
    c->type=type;
    ctx->chain_n++;
}

/* ════════════════════════════════════════════════════
 * INIT / CLOSE
 * ════════════════════════════════════════════════════ */

static void _fib_init(ToraCtx *ctx) {
    ctx->fib[0]=1.0;
    ctx->fib[1]=ctx->fib[0]*TORA_SQRT3_2+TORA_PI*sin(TORA_THETA999);
    for(int i=2;i<64;i++)
        ctx->fib[i]=ctx->fib[i-1]*TORA_SQRT3_2+TORA_PI*sin(i*TORA_THETA999);
}

static void _som_seed(ToraCtx *ctx) {
    /* Fibonacci-Rafael seeded SOM weights */
    for(int i=0;i<TORA_SOM_N;i++){
        int ix=i%TORA_SOM_DIM,iy=(i/TORA_SOM_DIM)%TORA_SOM_DIM,
            iz=i/(TORA_SOM_DIM*TORA_SOM_DIM);
        double fi=ctx->fib[i%64];
        float fm=(float)(fi*0.05);
        ctx->som_w[i][0]=(float)ix/(TORA_SOM_DIM-1)+fm*cosf((float)i);
        ctx->som_w[i][1]=(float)iy/(TORA_SOM_DIM-1)+fm*sinf((float)i);
        ctx->som_w[i][2]=(float)iz/(TORA_SOM_DIM-1);
        /* clamp [0,1] */
        for(int k=0;k<3;k++){
            if(ctx->som_w[i][k]<0)ctx->som_w[i][k]=0;
            if(ctx->som_w[i][k]>1)ctx->som_w[i][k]=1;
        }
    }
}

ToraStatus tora_ctx_init(ToraCtx *ctx, const char *data_dir) {
    if(!ctx||!data_dir) return TORA_ERR_NULL;
    memset(ctx,0,sizeof(*ctx));
    ctx->vecdb_fd=ctx->nexus_fd=-1;
    ctx->som_lr=0.05f; ctx->som_sigma=3.0f;
    ctx->R_t=3.0; ctx->phi_ethica=1.0;

    _fib_init(ctx);
    _som_seed(ctx);
    _check_crc32c();

    /* Lorenz seed */
    ctx->lx=0.1; ctx->ly=0.0; ctx->lz=0.0;
    for(int i=0;i<200;i++) tora_lorenz_step(ctx);
    ctx->lyapunov_sum=0; ctx->lorenz_steps=0;

    /* open storage */
    char path[512];
    void *h,*d;

    snprintf(path,sizeof(path),"%s/tora.vecdb",data_dir);
    ctx->vecdb_fd=_mmap_file(path,TORA_VDB_SZ,&h,&d,sizeof(ToraHdr));
    if(ctx->vecdb_fd<0) return TORA_ERR_IO;
    ctx->vecdb_hdr=(ToraHdr*)h; ctx->vecdb_recs=(ToraRec*)d;
    if(ctx->vecdb_hdr->magic!=TORA_MAGIC){
        memset(ctx->vecdb_hdr,0,sizeof(ToraHdr));
        ctx->vecdb_hdr->magic=TORA_MAGIC; ctx->vecdb_hdr->version=2;
        ctx->vecdb_hdr->cap=TORA_VECDB_CAP;
    }

    snprintf(path,sizeof(path),"%s/tora.nexus",data_dir);
    ctx->nexus_fd=_mmap_file(path,TORA_NXS_SZ,&h,&d,sizeof(ToraHdr));
    if(ctx->nexus_fd<0) return TORA_ERR_IO;
    ctx->nexus_hdr=(ToraHdr*)h; ctx->nexus_recs=(ToraRec*)d;
    if(ctx->nexus_hdr->magic!=TORA_MAGIC){
        memset(ctx->nexus_hdr,0,sizeof(ToraHdr));
        ctx->nexus_hdr->magic=TORA_MAGIC; ctx->nexus_hdr->version=2;
        ctx->nexus_hdr->cap=TORA_NEXUS_CAP;
    }

    fprintf(stderr,"[tora] init OK  vecdb=%llu  nexus=%llu  λ=%.4f\n",
            (unsigned long long)ctx->vecdb_hdr->used,
            (unsigned long long)ctx->nexus_hdr->used,
            tora_lyapunov(ctx));
    return TORA_OK;
}

void tora_ctx_close(ToraCtx *ctx) {
    if(!ctx) return;
    if(ctx->vecdb_fd>=0){
        msync(ctx->vecdb_hdr,TORA_VDB_SZ,MS_SYNC);
        munmap(ctx->vecdb_hdr,TORA_VDB_SZ);
        close(ctx->vecdb_fd); ctx->vecdb_fd=-1;
    }
    if(ctx->nexus_fd>=0){
        msync(ctx->nexus_hdr,TORA_NXS_SZ,MS_SYNC);
        munmap(ctx->nexus_hdr,TORA_NXS_SZ);
        close(ctx->nexus_fd); ctx->nexus_fd=-1;
    }
}

/* ════════════════════════════════════════════════════
 * QUERY + REPORT
 * ════════════════════════════════════════════════════ */

int tora_query(ToraCtx *ctx, const char *text, int k) {
    if(!ctx||!text) return 0;
    uint64_t h=tora_hash_dual((const uint8_t*)text,strlen(text));
    float q[3]; tora_project_3d(h,q);
    int n=tora_vecdb_search(ctx,q,k);
    if(n>0) tora_wave_collapse(ctx,q,ctx->qres_refs[0],ctx->qres_scores[0]);
    ctx->query_count++;
    return n;
}

int tora_query_vec(ToraCtx *ctx, const float q[3], int k) {
    if(!ctx||!q) return 0;
    int n=tora_vecdb_search(ctx,q,k);
    if(n>0) tora_wave_collapse(ctx,q,ctx->qres_refs[0],ctx->qres_scores[0]);
    ctx->query_count++;
    return n;
}

void tora_query_report(const ToraCtx *ctx) {
    printf("[tora query] n=%d\n", ctx->qres_n);
    for(int i=0;i<ctx->qres_n;i++)
        printf("  [%d] ref=%llu score=%.4f\n", i,
               (unsigned long long)ctx->qres_refs[i],
               (double)ctx->qres_scores[i]);
}

void tora_stats(const ToraCtx *ctx) {
    double lya=tora_lyapunov(ctx);
    printf("\n┌──────────────── TORA STATS ────────────────┐\n");
    printf("│ VecDB: %-8llu / %-8llu               │\n",
           (unsigned long long)ctx->vecdb_hdr->used,
           (unsigned long long)ctx->vecdb_hdr->cap);
    printf("│ JSON trained : %-8llu                   │\n",
           (unsigned long long)ctx->json_trained);
    printf("│ IMG trained  : %-8llu  tiles:%-8llu │\n",
           (unsigned long long)ctx->img_trained,
           (unsigned long long)ctx->img_tiles);
    printf("│ Queries      : %-8llu  collapses:%-6llu│\n",
           (unsigned long long)ctx->query_count,
           (unsigned long long)ctx->wave_collapses);
    printf("│ SOM steps    : %-8llu  epoch:%-6u    │\n",
           (unsigned long long)ctx->som_steps, ctx->som_epoch);
    printf("│ R(t)         : %-12.8f                │\n", ctx->R_t);
    printf("│ Φ_ethica     : %-12.8f                │\n", ctx->phi_ethica);
    printf("│ λ Lyapunov   : %-12.6f                │\n", lya);
    printf("│ Chain events : %-8u                    │\n", ctx->chain_n);
    printf("│ Focus score  : %-8.4f                    │\n",
           (double)ctx->focus_score);
    printf("└────────────────────────────────────────────┘\n");
}
