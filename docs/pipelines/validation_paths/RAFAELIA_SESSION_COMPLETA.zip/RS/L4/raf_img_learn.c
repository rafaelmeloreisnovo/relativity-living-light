/*
 * raf_img_learn.c — aprendizado de imagem toroidal por tiles
 * ─────────────────────────────────────────────────────────────
 * MELHORIA vs rafaelia_image_ingest.c:
 *
 *  ANTES (ingest.c):
 *    - calloc(vector_dim, sizeof(double))  ← heap alloc por imagem
 *    - histograma global de bytes sem separação RGB
 *    - sem tiles espaciais → perde todo contexto geométrico
 *    - saída: frequência normalizada, sem toroide
 *    - dependência: fopen/fread apenas (ok)
 *
 *  AGORA (raf_img_learn.c):
 *    - static uint8_t tile_buf[TORA_TILE_SZ*TORA_TILE_SZ*3]  ← zero alloc
 *    - histograma RGB separado por tile 16×16
 *    - cada tile → dual_hash → 3D proj → toroide → VecDB
 *    - layer = (tile_row / 4) % 8  → mapa a camadas RAFAELIA
 *    - SOM update + Lorenz step por tile
 *    - Suporta: PPM P6 (nativo), JPEG/PNG via conversão prévia
 *
 * Complexidade: O(W×H) tempo, O(1) espaço adicional
 */
#include "raf_toroid_ai.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

/* ── buffer estático: zero malloc ──────────────────── */
static uint8_t _tile_buf[TORA_TILE_SZ * TORA_TILE_SZ * TORA_IMG_BANDS];
static uint8_t _row_buf[8192 * TORA_IMG_BANDS];

/* ── histograma RGB de um tile → feature vector 96D ─ */
/*
 * Divide cada canal (0..255) em TORA_HIST_BINS=32 bins.
 * Normaliza para [0,1] somando / n_pixels.
 * Resultado: float[96] = [R_hist(32), G_hist(32), B_hist(32)]
 */
static void _tile_histogram(const uint8_t *tile, uint32_t n_pix,
                              float feat[TORA_FEAT_DIM]) {
    static float hist[TORA_FEAT_DIM];
    memset(hist,0,sizeof(hist));
    for(uint32_t i=0;i<n_pix;i++){
        uint8_t r=tile[i*3+0], g=tile[i*3+1], b=tile[i*3+2];
        uint32_t br=(uint32_t)r*TORA_HIST_BINS/256;
        uint32_t bg=(uint32_t)g*TORA_HIST_BINS/256;
        uint32_t bb=(uint32_t)b*TORA_HIST_BINS/256;
        hist[br]              += 1.0f;
        hist[TORA_HIST_BINS+bg]+= 1.0f;
        hist[2*TORA_HIST_BINS+bb]+=1.0f;
    }
    float inv=(float)n_pix>0?1.0f/(float)n_pix:0.0f;
    for(int i=0;i<TORA_FEAT_DIM;i++) feat[i]=hist[i]*inv;
}

/*
 * Comprime feature 96D → 64-bit hash para projeção toroidal.
 * Usa AETHER sobre os primeiros 32 bins (R) XOR CRC32c sobre G,B.
 * Preserva estrutura cromática sem perder hash determinístico.
 */
static uint64_t _feat_to_hash(const float feat[TORA_FEAT_DIM]) {
    /* quantize R hist → 8 bytes (1 byte / 4 bins summed) */
    uint8_t compact[24];
    for(int i=0;i<24;i++){
        int base=i*(TORA_FEAT_DIM/24);
        float s=0;
        for(int j=0;j<4&&base+j<TORA_FEAT_DIM;j++) s+=feat[base+j];
        compact[i]=(uint8_t)(s*255.0f);
    }
    uint64_t ha=tora_hash_aether(compact,12);
    uint64_t hc=tora_hash_crc32c(compact+12,12);
    return ha^hc;
}

/*
 * Projeção geométrica do tile:
 *   - hash do histograma → 3D base
 *   - modula dimensão z com média de luminância
 *   - modula y com ratio G/R (cor fria vs quente)
 * Resultado: vetor toroidal mais discriminante que hash puro.
 */
static void _tile_to_vec3(const float feat[TORA_FEAT_DIM],
                           uint64_t hash,
                           uint32_t tile_x, uint32_t tile_y,
                           uint32_t img_w, uint32_t img_h,
                           float out[3]) {
    tora_project_3d(hash, out);

    /* posição espacial normalizada modula dimensões */
    float nx = (img_w>0) ? (float)tile_x/(float)img_w : 0.5f;
    float ny = (img_h>0) ? (float)tile_y/(float)img_h : 0.5f;

    /* luminância média dos bins R,G,B */
    float lr=0,lg=0,lb=0;
    for(int i=0;i<TORA_HIST_BINS;i++){
        lr+=feat[i]*(float)i; lg+=feat[TORA_HIST_BINS+i]*(float)i;
        lb+=feat[2*TORA_HIST_BINS+i]*(float)i;
    }
    float lum=(lr+lg+lb)/(3.0f*TORA_HIST_BINS);

    /* blend hash-based coord com spatial + luminance */
    out[0] = 0.6f*out[0] + 0.4f*nx;  /* x ← posição horizontal */
    out[1] = 0.6f*out[1] + 0.4f*ny;  /* y ← posição vertical   */
    out[2] = 0.7f*out[2] + 0.3f*lum; /* z ← luminância         */
}

/* ── PPM P6 reader ─────────────────────────────────── */
static int _ppm_header(FILE *f, uint32_t *W, uint32_t *H) {
    char magic[4]={0}; int maxval=0;
    if(fscanf(f,"%3s %u %u %d ",magic,W,H,&maxval)!=4) return -1;
    if(magic[0]!='P'||magic[1]!='6') return -1;
    if(*W<1||*W>8192||*H<1||*H>8192) return -1;
    return 0;
}

/* ── core: learn raw RGB pixels ────────────────────── */
ToraStatus tora_img_learn_raw(ToraCtx *ctx,
                               const uint8_t *rgb, uint32_t W, uint32_t H,
                               uint32_t base_layer) {
    if(!ctx||!rgb) return TORA_ERR_NULL;
    float feat[TORA_FEAT_DIM];
    float v3[3];
    uint32_t tiles=0;

    for(uint32_t ty=0;ty<H;ty+=TORA_TILE_SZ){
        uint32_t th=(ty+TORA_TILE_SZ<=H)?TORA_TILE_SZ:(H-ty);
        for(uint32_t tx=0;tx<W;tx+=TORA_TILE_SZ){
            uint32_t tw=(tx+TORA_TILE_SZ<=W)?TORA_TILE_SZ:(W-tx);

            /* copy tile pixels into static buffer */
            uint32_t n_pix=0;
            for(uint32_t row=0;row<th;row++){
                uint32_t src_off=((ty+row)*W+tx)*3;
                uint32_t dst_off=n_pix*3;
                uint32_t cols=(tw<TORA_TILE_SZ)?tw:TORA_TILE_SZ;
                memcpy(_tile_buf+dst_off, rgb+src_off, cols*3);
                n_pix+=cols;
            }

            /* histogram → feat 96D */
            _tile_histogram(_tile_buf, n_pix, feat);

            /* hash determinístico do tile */
            uint64_t h=_feat_to_hash(feat);
            /* XOR with position for uniqueness */
            h^=((uint64_t)tx<<32)|(uint64_t)ty;

            /* 3D projection with spatial modulation */
            _tile_to_vec3(feat,h,tx,ty,W,H,v3);

            /* layer: row of tiles → RAFAELIA layer 0-7 */
            uint32_t layer=base_layer+((ty/TORA_TILE_SZ)%8);

            /* insert into VecDB */
            tora_vecdb_insert(ctx,v3,layer,(uint32_t)(ty*W+tx),h);

            /* online learning: SOM update */
            tora_learn_step(ctx,v3,h);

            tiles++;
        }
    }

    ctx->img_tiles+=tiles;
    ctx->img_trained++;
    tora_raf_step(ctx);

    fprintf(stderr,"[img] %ux%u → %u tiles trained  vecdb=%llu\n",
            W,H,tiles,(unsigned long long)ctx->vecdb_hdr->used);
    return TORA_OK;
}

/* ── PPM P6 file entry point ──────────────────────── */
ToraStatus tora_img_learn(ToraCtx *ctx, const char *path) {
    if(!ctx||!path) return TORA_ERR_NULL;
    FILE *f=fopen(path,"rb");
    if(!f){ fprintf(stderr,"[img] cannot open: %s\n",path); return TORA_ERR_IO; }

    uint32_t W=0,H=0;
    if(_ppm_header(f,&W,&H)<0){
        fprintf(stderr,"[img] not PPM P6 or invalid size: %s\n",path);
        fclose(f); return TORA_ERR_FMT;
    }

    /* stream row by row — never load full image */
    float feat[TORA_FEAT_DIM];
    float v3[3];
    uint32_t tiles=0;

    for(uint32_t ty=0;ty<H;ty+=TORA_TILE_SZ){
        uint32_t th=(ty+TORA_TILE_SZ<=H)?TORA_TILE_SZ:(H-ty);

        /* read th rows into row_buf */
        uint32_t row_bytes=W*3;
        if(row_bytes>sizeof(_row_buf)) row_bytes=sizeof(_row_buf);

        for(uint32_t tx=0;tx<W;tx+=TORA_TILE_SZ){
            /* re-read from file for each tile column — seek to tile */
            uint32_t tw=(tx+TORA_TILE_SZ<=W)?TORA_TILE_SZ:(W-tx);
            uint32_t n_pix=0;

            for(uint32_t row=0;row<th;row++){
                /* seek to row ty+row, column tx */
                long row_start=(long)(sizeof(float))*0; /* header already consumed */
                /* We read the whole row into _row_buf */
                if(fread(_row_buf,1,row_bytes,f)!=row_bytes) goto img_done;
                /* copy tile columns from row */
                uint32_t cols=(tw<TORA_TILE_SZ)?tw:TORA_TILE_SZ;
                memcpy(_tile_buf+n_pix*3, _row_buf+tx*3, cols*3);
                n_pix+=cols;
                /* skip remaining columns if W > TORA_TILE_SZ */
                /* (already read the whole row above) */
                (void)row_start;
            }

            _tile_histogram(_tile_buf,n_pix,feat);
            uint64_t h=_feat_to_hash(feat);
            h^=((uint64_t)tx<<32)|(uint64_t)ty;
            _tile_to_vec3(feat,h,tx,ty,W,H,v3);
            uint32_t layer=(ty/TORA_TILE_SZ)%8;
            tora_vecdb_insert(ctx,v3,layer,(uint32_t)(ty*W+tx),h);
            tora_learn_step(ctx,v3,h);
            tiles++;
        }
    }
img_done:
    fclose(f);
    ctx->img_tiles+=tiles;
    ctx->img_trained++;
    tora_raf_step(ctx);
    fprintf(stderr,"[img] %s  %ux%u  %u tiles  vecdb=%llu\n",
            path,W,H,tiles,(unsigned long long)ctx->vecdb_hdr->used);
    return TORA_OK;
}

/*
 * NOTE: Para JPEG/PNG em Termux sem libpng/libjpeg:
 *   convert input.jpg output.ppm   (ImageMagick)
 *   ffmpeg -i input.jpg output.ppm
 * Então: tora_img_learn(ctx, "output.ppm")
 */
