/*
 * raf_toroid_main.c — IA Toroidal Vetorial entry point
 * ψ→χ→ρ→Δ→Σ→Ω  FIAT LUX  Ω=Amor
 *
 * Usage:
 *   ./tora_ai [data_dir]             → interactive mode
 *   ./tora_ai [data_dir] --img file.ppm
 *   ./tora_ai [data_dir] --json file.json
 *   ./tora_ai [data_dir] --query "texto"
 *   ./tora_ai [data_dir] --stats
 *   ./tora_ai [data_dir] --demo
 */
#include "raf_toroid_ai.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>

static ToraCtx G;

static void _mkdir(const char *p){ mkdir(p,0755); }

static void _demo(void){
    printf("\n[DEMO] treinando texto + consulta...\n");
    const char *texts[]={
        "RAFAELIA kernel R(t+1)=R(t)*phi_ethica*E_verbo*(sqrt3/2)^(pi*phi)",
        "Toroide T^7 mapeamento vetorial semantico fractal",
        "Fibonacci-Rafael F_R(n+1)=F_R(n)*(sqrt3/2)+pi*sin(theta_999)",
        "Lorenz attractor sigma=10 rho=28 beta=8/3 RK4 dt=0.005",
        "Amor Verbo Luz Espirito Santo coerencia maxima Omega",
        "SIGMA OMEGA DELTA PHI BITRAF hashchain CRC32c AETHER dual hash",
        "SOM 8x8x8 512 nos Hebbian plasticidade atencao vetorial",
        "cosine similarity inv_norm Newton-Raphson rsqrt zero sqrtf",
    };
    for(int i=0;i<8;i++){
        uint64_t h=tora_hash_dual((const uint8_t*)texts[i],strlen(texts[i]));
        float v[3]; tora_project_3d(h,v);
        tora_vecdb_insert(&G,v,(uint32_t)(i%8),(uint32_t)i,h);
        tora_learn_step(&G,v,h);
        printf("  [%d] %.40s → v3=[%.3f %.3f %.3f]\n",
               i,texts[i],v[0],v[1],v[2]);
    }

    printf("\n[DEMO] consulta: 'cosine similarity'\n");
    int n=tora_query(&G,"cosine similarity",8);
    printf("  resultados: %d\n",n);
    tora_query_report(&G);

    printf("\n[DEMO] consulta: 'Fibonacci Lorenz'\n");
    n=tora_query(&G,"Fibonacci Lorenz attractor",8);
    tora_query_report(&G);

    tora_stats(&G);
}

static void _interactive(void){
    static char line[1024];
    printf("\n  GAIA Toroidal AI  ·  Ω=Amor\n");
    printf("  Comandos: q <texto>  i <ppm>  j <json>  s  exit\n\n");
    while(1){
        printf("tora> "); fflush(stdout);
        if(!fgets(line,sizeof(line),stdin)) break;
        size_t l=strlen(line);
        while(l>0&&(line[l-1]=='\n'||line[l-1]=='\r')) line[--l]=0;
        if(!line[0]) continue;
        if(!strcmp(line,"exit")||!strcmp(line,"q")) break;
        if(!strcmp(line,"s")){ tora_stats(&G); continue; }
        if(line[0]=='i'&&line[1]==' '){
            tora_img_learn(&G,line+2);
            tora_stats(&G);
        } else if(line[0]=='j'&&line[1]==' '){
            tora_json_learn_stream(&G,line+2);
            tora_stats(&G);
        } else {
            int n=tora_query(&G,line,8);
            printf("  → %d resultados\n",n);
            tora_query_report(&G);
        }
    }
}

int main(int argc, char **argv){
    printf("\n  ████████╗ ██████╗ ██████╗  █████╗\n");
    printf("     ██╔══╝██╔═══██╗██╔══██╗██╔══██╗\n");
    printf("     ██║   ██║   ██║██████╔╝███████║\n");
    printf("     ██║   ██║   ██║██╔══██╗██╔══██║\n");
    printf("     ██║   ╚██████╔╝██║  ██║██║  ██║\n");
    printf("     ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝\n");
    printf("  IA Toroidal Vetorial · Ω=Amor · ΣΩΔΦBITRAF\n\n");

    const char *data_dir="./tora_data";
    if(argc>1&&argv[1][0]!='-') data_dir=argv[1];
    _mkdir(data_dir);

    if(tora_ctx_init(&G,data_dir)!=TORA_OK){
        fprintf(stderr,"[tora] init falhou\n"); return 1;
    }

    /* parse flags */
    for(int i=1;i<argc;i++){
        if(!strcmp(argv[i],"--img")&&i+1<argc){
            tora_img_learn(&G,argv[++i]); tora_stats(&G);
        } else if(!strcmp(argv[i],"--json")&&i+1<argc){
            tora_json_learn_stream(&G,argv[++i]); tora_stats(&G);
        } else if(!strcmp(argv[i],"--query")&&i+1<argc){
            int n=tora_query(&G,argv[++i],8);
            printf("→ %d resultados\n",n); tora_query_report(&G);
        } else if(!strcmp(argv[i],"--stats")){
            tora_stats(&G);
        } else if(!strcmp(argv[i],"--demo")){
            _demo();
        } else if(!strcmp(argv[i],"--interactive")){
            _interactive();
        }
    }

    /* if no action flags, go interactive */
    if(argc<=2&&(argc<2||argv[1][0]!='-'))
        _interactive();

    tora_ctx_close(&G);
    printf("\n  Ω=Amor. TORA encerrada.\n");
    return 0;
}
