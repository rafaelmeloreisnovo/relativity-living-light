/*
 * gaia_geom.h — public API for geometry + attractor engine
 */
#ifndef GAIA_GEOM_H
#define GAIA_GEOM_H

#include "gaia_bbs.h"

#define GAIA_FIB_CAP   64
#define GAIA_LATTICE_N 9
#define GAIA_PRIME_CAP 4096

void        gaia_geom_init(void);
double      gaia_fib_rafael(uint32_t n);
int         gaia_is_prime(uint32_t n);
uint32_t    gaia_nth_prime(uint32_t idx);
void        gaia_vec_to_toroid(const float v[3], float *tx, float *ty, float *tz);
int         gaia_lattice_snap(const float v[3]);
void        gaia_lattice_hebb(const float v[3], float lr);
void        gaia_lorenz_step(double *ox, double *oy, double *oz);
double      gaia_lyapunov(void);
const char *gaia_attractor_class(double lambda);
void        gaia_wave_collapse(GaiaCtx *g, const float q[3],
                               uint64_t collapsed_hash, float score);
float       gaia_infinity_rate(void);
int         gaia_geom_json(char *buf, int cap);

#endif
