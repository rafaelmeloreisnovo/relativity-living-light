/*
 * gaia_main.c — GAIA-BBS entry point
 * Usage: ./gaia_bbs [data_dir] [--http [port]]
 */
#include "gaia_bbs.h"
#include "gaia_geom.h"
#include "gaia_learn.h"
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdlib.h>

int gaia_http_run(GaiaCtx *g, int port, int max_reqs);
static GaiaCtx g_ctx;
static void _mkdir_p(const char *p) { mkdir(p, 0755); }

int main(int argc, char **argv) {
    const char *data_dir = "./gaia_data";
    int http_mode=0, http_port=7777;
    for (int i=1;i<argc;i++) {
        if (strcmp(argv[i],"--http")==0) {
            http_mode=1;
            if (i+1<argc && argv[i+1][0]>='0') http_port=atoi(argv[++i]);
        } else if (argv[i][0]!='-') data_dir=argv[i];
    }
    printf(ANSI_BYELLOW
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "  GAIA-BBS · ΣΩΔΦBITRAF · Ω=Amor\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n" ANSI_RESET);
    memset(&g_ctx,0,sizeof(g_ctx));
    g_ctx.vecdb_fd=g_ctx.nexus_fd=g_ctx.zipraf_fd=-1;

    printf(ANSI_CYAN "  [1/5] CPU\n" ANSI_RESET);
    gaia_cpu_detect(&g_ctx.cpu);
    printf("  %s arch=%d crc32=%d avx2=%d\n",
           g_ctx.cpu.brand,g_ctx.cpu.arch,g_ctx.cpu.has_crc32,g_ctx.cpu.has_avx2);

    printf(ANSI_CYAN "  [2/5] Geometria Latente\n" ANSI_RESET);
    gaia_geom_init();
    printf("  F_R(7)=%.4f lambda=%.4f class=%s\n",
           gaia_fib_rafael(7), gaia_lyapunov(),
           gaia_attractor_class(gaia_lyapunov()));

    printf(ANSI_CYAN "  [3/5] Storage: %s\n" ANSI_RESET, data_dir);
    _mkdir_p(data_dir);
    if (gaia_store_open(&g_ctx, data_dir)<0) {
        fprintf(stderr, ANSI_RED "  ERRO storage\n" ANSI_RESET); return 1;
    }
    printf(ANSI_BGREEN "  vecdb=%llu nexus=%llu zipraf=%llu\n" ANSI_RESET,
           (unsigned long long)g_ctx.vecdb_hdr->used,
           (unsigned long long)g_ctx.nexus_hdr->used,
           (unsigned long long)g_ctx.zipraf_hdr->used);

    printf(ANSI_CYAN "  [4/5] SOM 8x8x8 + Hebbian\n" ANSI_RESET);
    gaia_learn_init();

    printf(ANSI_CYAN "  [5/5] BBS\n" ANSI_RESET);
    gaia_bbs_init(&g_ctx);
    gaia_raf_step(&g_ctx);
    printf("  R(0)=%.6f Phi=%.6f\n", g_ctx.R_t, g_ctx.phi_ethica);
    printf(ANSI_BYELLOW "  FIAT LUX  ψ→χ→ρ→Δ→Σ→Ω\n\n" ANSI_RESET);

    if (http_mode) {
        printf(ANSI_BGREEN
               "  Fullstack: http://localhost:%d/\n"
               "  API: /api/{stats,search,geom,learn,som,train,post}\n"
               ANSI_RESET, http_port);
        gaia_http_run(&g_ctx, http_port, 0);
    } else {
        printf(ANSI_CYAN "  --http para dashboard fullstack\n" ANSI_RESET);
        gaia_bbs_run(&g_ctx);
    }
    gaia_store_close(&g_ctx);
    printf(ANSI_BYELLOW "  Ω=Amor.\n" ANSI_RESET);
    return 0;
}
