/*
 * gaia_http.c — bare-metal HTTP/1.0 server
 * ─────────────────────────────────────────
 * Raw POSIX sockets only — no libcurl, no external HTTP libs.
 * Single-threaded, single connection at a time (BBS model).
 * Serves:
 *   GET /              → embedded dashboard HTML (SPA)
 *   GET /api/stats     → JSON: vecdb+nexus+zipraf+raf+learn+geom
 *   GET /api/search?q= → JSON: top-8 semantic results
 *   GET /api/geom      → JSON: Lorenz/Lyapunov/lattice
 *   GET /api/learn     → JSON: SOM/Hebbian/stability
 *   GET /api/som       → JSON: 512 SOM node weights
 *   POST /api/train    → body: plain text → train + return stats
 *   POST /api/post     → body: JSON {board,author,subject,body}
 */
#include "gaia_bbs.h"
#include "gaia_geom.h"
#include "gaia_learn.h"
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define HTTP_PORT    7777
#define HTTP_BUFSIZE (1 << 16)   /* 64KB request/response buf */
#define HTTP_RESP    (1 << 18)   /* 256KB response             */

/* ── static buffers (no heap) ───────────────────────── */
static char _req[HTTP_BUFSIZE];
static char _resp[HTTP_RESP];
static char _json[HTTP_RESP - 4096];

/* ── small string helpers ───────────────────────────── */
static int _startswith(const char *s, const char *pfx) {
    while (*pfx) if (*s++ != *pfx++) return 0;
    return 1;
}
static const char *_query_param(const char *url, const char *key) {
    /* finds ?key=value or &key=value */
    static char val[512];
    const char *p = url;
    size_t kl = strlen(key);
    while (*p) {
        if ((*p=='?'||*p=='&') && strncmp(p+1,key,kl)==0 && p[1+kl]=='=') {
            p = p + 2 + kl;
            size_t i=0;
            while (*p && *p!='&' && *p!=' ' && i<510) {
                /* URL decode %XX */
                if (*p=='%' && p[1] && p[2]) {
                    char h[3]={p[1],p[2],0};
                    val[i++]=(char)strtol(h,NULL,16);
                    p+=3;
                } else if (*p=='+') {
                    val[i++]=' '; p++;
                } else {
                    val[i++]=*p++;
                }
            }
            val[i]=0;
            return val;
        }
        p++;
    }
    return "";
}

/* ── HTTP response builders ─────────────────────────── */
static int _http_ok_json(char *out, int cap, const char *body, int blen) {
    return snprintf(out, (size_t)cap,
        "HTTP/1.0 200 OK\r\n"
        "Content-Type: application/json\r\n"
        "Access-Control-Allow-Origin: *\r\n"
        "Content-Length: %d\r\n"
        "Connection: close\r\n"
        "\r\n"
        "%.*s", blen, blen, body);
}
static int _http_ok_html(char *out, int cap, const char *body, int blen) {
    return snprintf(out, (size_t)cap,
        "HTTP/1.0 200 OK\r\n"
        "Content-Type: text/html; charset=utf-8\r\n"
        "Content-Length: %d\r\n"
        "Connection: close\r\n"
        "\r\n"
        "%.*s", blen, blen, body);
}
static int _http_404(char *out, int cap) {
    return snprintf(out, (size_t)cap,
        "HTTP/1.0 404 Not Found\r\n"
        "Content-Type: text/plain\r\n"
        "Connection: close\r\n\r\n404");
}

/* ── /api/stats ─────────────────────────────────────── */
static int _route_stats(GaiaCtx *g, char *out, int cap) {
    int jl = snprintf(_json, sizeof(_json),
        "{"
        "\"vecdb\":%llu,\"vecdb_cap\":%llu,"
        "\"nexus\":%llu,\"nexus_cap\":%llu,"
        "\"zipraf\":%llu,\"zipraf_cap\":%llu,"
        "\"msgs\":%u,\"boards\":%d,"
        "\"R_t\":%.8f,\"phi_ethica\":%.8f,"
        "\"trained_imgs\":%llu,\"trained_json\":%llu,"
        "\"trained_total\":%llu"
        "}",
        (unsigned long long)g->vecdb_hdr->used,
        (unsigned long long)g->vecdb_hdr->cap,
        (unsigned long long)g->nexus_hdr->used,
        (unsigned long long)g->nexus_hdr->cap,
        (unsigned long long)g->zipraf_hdr->used,
        (unsigned long long)g->zipraf_hdr->cap,
        g->msg_count, GAIA_BBS_BOARDS,
        g->R_t, g->phi_ethica,
        (unsigned long long)g->trained_imgs,
        (unsigned long long)g->trained_json,
        (unsigned long long)g->trained_total);
    return _http_ok_json(out, cap, _json, jl);
}

/* ── /api/search?q=... ──────────────────────────────── */
static int _route_search(GaiaCtx *g, const char *url,
                           char *out, int cap)
{
    const char *q = _query_param(url, "q");
    if (!*q) {
        const char *e="{\"error\":\"missing q\"}";
        return _http_ok_json(out, cap, e, (int)strlen(e));
    }
    size_t ql = strlen(q);
    uint64_t qh = gaia_hash_crc32_asm((const uint8_t*)q, ql);
    omega_float qv[3];
    gaia_hash_to_vec(qh, qv);

    uint64_t refs[8]; omega_float scores[8];
    int n = gaia_vecdb_search(g, qv, 8, refs, scores);

    int jl=0;
    jl += snprintf(_json+jl, sizeof(_json)-jl,
                   "{\"query\":\"%s\",\"n\":%d,\"results\":[", q, n);
    for (int i=0;i<n;i++) {
        if (i) _json[jl++]=',';
        uint32_t rid=(uint32_t)refs[i];
        if (rid < g->msg_count) {
            BBSMsg *m=&g->msgs[rid];
            jl+=snprintf(_json+jl,sizeof(_json)-jl,
                "{\"id\":%u,\"score\":%.4f,\"author\":\"%s\","
                "\"subject\":\"%s\",\"board\":%u}",
                m->id,(double)scores[i],m->author,m->subject,m->board);
        } else {
            jl+=snprintf(_json+jl,sizeof(_json)-jl,
                "{\"ref\":%llu,\"score\":%.4f}",
                (unsigned long long)refs[i],(double)scores[i]);
        }
    }
    jl+=snprintf(_json+jl,sizeof(_json)-jl,"]}");

    /* also do wave collapse on top result */
    if (n > 0) gaia_wave_collapse(g, qv, refs[0], scores[0]);

    return _http_ok_json(out, cap, _json, jl);
}

/* ── /api/train (POST) ──────────────────────────────── */
static int _route_train(GaiaCtx *g, const char *body, int blen,
                          char *out, int cap)
{
    if (blen > 0) {
        uint32_t layer = (uint32_t)(g->trained_total % GAIA_ZIPRAF_LAYERS);
        gaia_train_text(g, body, (size_t)blen, layer, 0);

        /* learn step */
        uint64_t h = gaia_hash_crc32_asm((const uint8_t*)body, (size_t)blen);
        float v[3]; gaia_hash_to_vec(h, v);
        gaia_learn_step(g, v);
    }
    return _route_stats(g, out, cap);
}

/* ── /api/post (POST JSON) ──────────────────────────── */
static int _route_post(GaiaCtx *g, const char *body,
                         char *out, int cap)
{
    /* naive JSON field extraction — no external parser */
    char author[32]={0}, subject[64]={0}, mbody[512]={0};
    uint32_t board=0;

    /* helper: extract string value after "key":" */
    #define _JSTR(key, dst, dsz) do { \
        const char *_p=strstr(body,"\"" key "\":\""); \
        if(_p){_p+=strlen("\"" key "\":\""); size_t _i=0; \
        while(*_p&&*_p!='"'&&_i<(dsz)-1) dst[_i++]=*_p++; dst[_i]=0;} \
    } while(0)
    #define _JINT(key, dst) do { \
        const char *_p=strstr(body,"\"" key "\":"); \
        if(_p){_p+=strlen("\"" key "\":"); dst=(uint32_t)atoi(_p);} \
    } while(0)

    _JSTR("author",  author,  32);
    _JSTR("subject", subject, 64);
    _JSTR("body",    mbody,  512);
    _JINT("board",   board);

    if (!author[0]) strcpy(author, "anon");
    if (!subject[0]) strcpy(subject, "untitled");

    gaia_bbs_post(g, board < GAIA_BBS_BOARDS ? board : 0,
                  author, subject, mbody);

    return _route_stats(g, out, cap);
}

/* ── request dispatcher ─────────────────────────────── */
static int _dispatch(GaiaCtx *g, int cfd) {
    /* read request */
    ssize_t nr = recv(cfd, _req, sizeof(_req)-1, 0);
    if (nr <= 0) return -1;
    _req[nr] = 0;

    /* parse method + url */
    char method[8]={0}, url[512]={0};
    sscanf(_req, "%7s %511s", method, url);

    /* find body (after \r\n\r\n) */
    const char *body = strstr(_req, "\r\n\r\n");
    int blen = 0;
    if (body) { body += 4; blen = (int)(nr - (body - _req)); }
    if (blen < 0) blen = 0;

    int rlen = 0;

    if (_startswith(url, "/api/stats")) {
        rlen = _route_stats(g, _resp, sizeof(_resp));
    }
    else if (_startswith(url, "/api/search")) {
        rlen = _route_search(g, url, _resp, sizeof(_resp));
    }
    else if (_startswith(url, "/api/geom")) {
        int jl = gaia_geom_json(_json, sizeof(_json));
        rlen = _http_ok_json(_resp, sizeof(_resp), _json, jl);
    }
    else if (_startswith(url, "/api/learn")) {
        int jl = gaia_learn_json(_json, sizeof(_json));
        rlen = _http_ok_json(_resp, sizeof(_resp), _json, jl);
    }
    else if (_startswith(url, "/api/som")) {
        int jl = gaia_som_json(_json, sizeof(_json));
        rlen = _http_ok_json(_resp, sizeof(_resp), _json, jl);
    }
    else if (_startswith(url, "/api/train") && method[0]=='P') {
        rlen = _route_train(g, body, blen, _resp, sizeof(_resp));
    }
    else if (_startswith(url, "/api/post") && method[0]=='P') {
        rlen = _route_post(g, body ? body : "", _resp, sizeof(_resp));
    }
    else if (_startswith(url, "/") && (url[1]==0||url[1]=='?')) {
        /* serve embedded SPA (written by gaia_http_html.h) */
        extern const char GAIA_HTML[];
        extern const int  GAIA_HTML_LEN;
        rlen = _http_ok_html(_resp, sizeof(_resp),
                             GAIA_HTML, GAIA_HTML_LEN);
    }
    else {
        rlen = _http_404(_resp, sizeof(_resp));
    }

    if (rlen > 0) send(cfd, _resp, (size_t)rlen, 0);
    return 0;
}

/* ── server loop ─────────────────────────────────────── */
int gaia_http_run(GaiaCtx *g, int port, int max_reqs) {
    int sfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sfd < 0) { perror("socket"); return -1; }

    int opt=1;
    setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in addr;
    memset(&addr,0,sizeof(addr));
    addr.sin_family      = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port        = htons((uint16_t)port);

    if (bind(sfd,(struct sockaddr*)&addr,sizeof(addr))<0) {
        perror("bind"); close(sfd); return -2;
    }
    listen(sfd, 4);

    fprintf(stderr,
            ANSI_BGREEN "  GAIA-HTTP listening on :%d  (max %d reqs)\n"
            ANSI_RESET, port, max_reqs);

    int handled = 0;
    while (max_reqs == 0 || handled < max_reqs) {
        struct sockaddr_in cli; socklen_t clilen=sizeof(cli);
        int cfd = accept(sfd,(struct sockaddr*)&cli,&clilen);
        if (cfd < 0) continue;
        _dispatch(g, cfd);
        close(cfd);
        handled++;
    }
    close(sfd);
    return 0;
}
