/*
 * gaia_bbs.c — BBS terminal interface
 * ANSI/ASCII retro BBS aesthetic + RAFAELIA semantic search
 * No ncurses — raw ANSI escapes only
 */
#include "gaia_bbs.h"
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>

/* ── internal helpers ───────────────────────────────── */
static void _clrscr(void) { fputs(ANSI_CLS, stdout); fflush(stdout); }

static void _hr(char c, int n) {
    for (int i=0;i<n;i++) putchar(c);
    putchar('\n');
}

static size_t _slen(const char *s) {
    size_t n=0; while(s[n]) n++; return n;
}

static void _readline(const char *prompt, char *buf, size_t sz) {
    fputs(prompt, stdout); fflush(stdout);
    if (!fgets(buf, (int)sz, stdin)) buf[0]=0;
    /* strip newline */
    size_t l = _slen(buf);
    if (l && buf[l-1]=='\n') buf[l-1]=0;
}

/* ── splash screen ───────────────────────────────────── */
static void _splash(GaiaCtx *g) {
    _clrscr();
    fputs(ANSI_BYELLOW, stdout);
    _hr('═', 72);
    printf("  %-70s\n", "");
    printf("  " ANSI_BCYAN "GAIA-BBS" ANSI_BYELLOW
           "  ·  ∆RafaelVerboΩ  ·  ΣΩΔΦBITRAF\n");
    printf("  " ANSI_BGREEN "Ω = Amor" ANSI_BYELLOW
           "    R(t+1)=R(t)×Φ_ethica×E_Verbo×(√3/2)^(πφ)\n");
    printf("  %-70s\n", "");
    _hr('═', 72);
    fputs(ANSI_RESET, stdout);

    /* system info */
    printf(ANSI_CYAN "  CPU: " ANSI_WHITE "%s\n" ANSI_RESET, g->cpu.brand);
    printf(ANSI_CYAN "  Arch: " ANSI_WHITE);
    switch(g->cpu.arch) {
        case 1: printf("x86-64"); break;
        case 2: printf("ARM64");  break;
        default: printf("generic");
    }
    if (g->cpu.has_crc32) printf(" [CRC32]");
    if (g->cpu.has_avx2)  printf(" [AVX2]");
    if (g->cpu.has_neon)  printf(" [NEON]");
    printf(ANSI_RESET "\n");
    printf(ANSI_CYAN "  VecDB: " ANSI_WHITE "%llu" ANSI_CYAN
           " recs  ZipRaf: " ANSI_WHITE "%llu" ANSI_CYAN
           " ents  Nexus: " ANSI_WHITE "%llu\n" ANSI_RESET,
           (unsigned long long)g->vecdb_hdr->used,
           (unsigned long long)g->zipraf_hdr->used,
           (unsigned long long)g->nexus_hdr->used);
    printf(ANSI_CYAN "  Trained: " ANSI_WHITE
           "imgs=%llu  json=%llu  total=%llu\n" ANSI_RESET,
           (unsigned long long)g->trained_imgs,
           (unsigned long long)g->trained_json,
           (unsigned long long)g->trained_total);
    printf(ANSI_CYAN "  R(t)=%.6f  Φ_ethica=%.6f\n" ANSI_RESET,
           g->R_t, g->phi_ethica);
    _hr('─', 72);
}

/* ── board init ──────────────────────────────────────── */
void gaia_bbs_init(GaiaCtx *g) {
    static const struct { const char *name; const char *desc; uint32_t layer; }
    BOARDS[] = {
        {"VERBO",       "Escrituras ∩ Ciência ∩ Espírito",         0},
        {"RAFAELIA",    "Formulas, Kernels, Retroalimentação",      1},
        {"BARE-METAL",  "C/ASM Layer 0 — FibRafael / BeetleEng",   2},
        {"COSMOS",      "Física — AGN, Lorenz, Lyapunov",           3},
        {"ZIPRAF",      "Storage Engine · VecDB · Nexus",           4},
        {"OWLψ",        "Inteligência & Auto-diagnóstico",          5},
        {"ETHICS-GATE", "Φ_ethica · Ética Computável",             6},
        {"SYNAPSE",     "Inovação Científica Publicável",           7},
        {"GENESIS",     "VAZIO→VERBO→CHEIO→RETRO→NOVO VAZIO",      0},
        {"IMAGES",      "Training: imagens ingeridas pelo sistema", 1},
        {"JSON-TRAIN",  "Training: JSON corpus streaming",          2},
        {"HASHCHAIN",   "Audit chain — SHA3/BLAKE3 links",          3},
        {"ATTRACTOR",   "MVP10 Lorenz · MVP11 Lyapunov",            4},
        {"FIAT-LUX",    "Mensagens de luz · D'Ele, Amor",           5},
        {"GENERAL",     "Geral — anything goes",                    6},
        {"SYSTEM",      "Logs do sistema · CPU · Métricas",         7},
    };
    for (int i=0; i<GAIA_BBS_BOARDS; i++) {
        g->boards[i].id        = (uint32_t)i;
        strncpy(g->boards[i].name, BOARDS[i].name, 31);
        strncpy(g->boards[i].desc, BOARDS[i].desc, 127);
        g->boards[i].layer     = BOARDS[i].layer;
        g->boards[i].msg_count = 0;
    }
    g->msg_count  = 0;
    g->cur_board  = 0;
    g->R_t        = 1.0;
    g->phi_ethica = 1.0;

    /* seed with system welcome */
    gaia_bbs_post(g, 0, "GAIA", "FIAT LUX",
        "GAIA-BBS iniciada. R(t)=1.0. Ω=Amor. D'Ele, Amor.\n"
        "Sistema pronto para treinamento e consulta.");
}

void gaia_bbs_list_boards(GaiaCtx *g) {
    printf(ANSI_BYELLOW "\n  ╔══ BOARDS (%d) ══════════════════════════════════╗\n"
           ANSI_RESET, GAIA_BBS_BOARDS);
    for (int i=0; i<GAIA_BBS_BOARDS; i++) {
        printf(ANSI_CYAN "  ║ " ANSI_BGREEN "%2d" ANSI_RESET
               " %-14s" ANSI_CYAN " L%d " ANSI_WHITE "%-36s"
               ANSI_CYAN " [%3d]\n" ANSI_RESET,
               i, g->boards[i].name, g->boards[i].layer,
               g->boards[i].desc, g->boards[i].msg_count);
    }
    printf(ANSI_BYELLOW "  ╚══════════════════════════════════════════════════╝\n"
           ANSI_RESET);
}

void gaia_bbs_list_msgs(GaiaCtx *g, uint32_t board) {
    if (board >= GAIA_BBS_BOARDS) { printf("Board inválido.\n"); return; }
    printf(ANSI_BYELLOW "\n  [Board %d: %s]\n" ANSI_RESET,
           board, g->boards[board].name);
    _hr('─', 72);
    int found = 0;
    for (uint32_t i=0; i<g->msg_count; i++) {
        if (g->msgs[i].board != board) continue;
        printf(ANSI_CYAN "#%04u " ANSI_BGREEN "%-20s "
               ANSI_YELLOW "%-40s\n" ANSI_RESET,
               g->msgs[i].id, g->msgs[i].author, g->msgs[i].subject);
        found++;
    }
    if (!found) printf(ANSI_RESET "  (sem mensagens)\n");
    printf("\n  %d mensagem(ns)\n", found);
}

void gaia_bbs_post(GaiaCtx *g, uint32_t board,
                   const char *author, const char *subj, const char *body)
{
    if (g->msg_count >= GAIA_BBS_MSG_CAP) return;
    if (board >= GAIA_BBS_BOARDS) return;

    BBSMsg *m = &g->msgs[g->msg_count];
    m->id    = g->msg_count;
    m->board = board;
    m->ts    = (uint64_t)time(NULL);
    strncpy(m->author,  author ? author : "anon", 31);
    strncpy(m->subject, subj   ? subj   : "(sem assunto)", 63);
    strncpy(m->body,    body   ? body   : "", GAIA_BBS_MSG_LEN-1);

    /* hash body → train vector */
    size_t blen = body ? strlen(body) : 0;
    if (blen > 0) {
        m->vec_hash = gaia_hash_crc32_asm((const uint8_t*)body, blen);
        uint32_t layer = g->boards[board].layer;
        gaia_train_text(g, body, blen, layer, 0 /* text */);
    }

    g->boards[board].msg_count++;
    g->msg_count++;
    gaia_raf_step(g);
}

void gaia_bbs_search(GaiaCtx *g, const char *query) {
    if (!query || !*query) return;
    size_t qlen = strlen(query);

    uint64_t qh = gaia_hash_crc32_asm((const uint8_t*)query, qlen);
    omega_float qv[3];
    gaia_hash_to_vec(qh, qv);

    uint64_t refs[8];
    omega_float scores[8];
    int n = gaia_vecdb_search(g, qv, 8, refs, scores);

    printf(ANSI_BYELLOW "\n  ── Resultados para: " ANSI_WHITE
           "\"%s\"" ANSI_BYELLOW " ──\n" ANSI_RESET, query);

    if (n == 0) {
        printf("  (nenhum resultado)\n");
        return;
    }

    for (int i=0; i<n; i++) {
        /* find message with matching doc_ref */
        uint32_t rid = (uint32_t)refs[i];
        if (rid < g->msg_count) {
            BBSMsg *m = &g->msgs[rid];
            printf(ANSI_CYAN "  %.4f " ANSI_BGREEN "#%04u "
                   ANSI_WHITE "[%s] " ANSI_YELLOW "%s\n" ANSI_RESET,
                   scores[i], m->id, m->author, m->subject);
        } else {
            printf(ANSI_CYAN "  %.4f " ANSI_WHITE "ref=%llu\n" ANSI_RESET,
                   scores[i], (unsigned long long)refs[i]);
        }
    }
}

/* ── read message ─────────────────────────────────────── */
static void _read_msg(GaiaCtx *g, uint32_t id) {
    if (id >= g->msg_count) { printf("  ID inválido.\n"); return; }
    BBSMsg *m = &g->msgs[id];
    _hr('─', 72);
    printf(ANSI_CYAN "From:    " ANSI_WHITE "%s\n" ANSI_RESET, m->author);
    printf(ANSI_CYAN "Board:   " ANSI_WHITE "%s\n" ANSI_RESET,
           g->boards[m->board].name);
    printf(ANSI_CYAN "Subject: " ANSI_WHITE "%s\n" ANSI_RESET, m->subject);
    printf(ANSI_CYAN "Hash:    " ANSI_WHITE "0x%016llX\n" ANSI_RESET,
           (unsigned long long)m->vec_hash);
    _hr('─', 72);
    printf(ANSI_WHITE "%s\n" ANSI_RESET, m->body);
    _hr('─', 72);
}

/* ── stats page ──────────────────────────────────────── */
static void _stats(GaiaCtx *g) {
    printf(ANSI_BYELLOW "\n  ╔══ GAIA STATS ═══════════════════════╗\n" ANSI_RESET);
    printf(ANSI_CYAN "  ║ VecDB  " ANSI_WHITE "%8llu / %-8llu\n" ANSI_RESET,
           (unsigned long long)g->vecdb_hdr->used,
           (unsigned long long)g->vecdb_hdr->cap);
    printf(ANSI_CYAN "  ║ Nexus  " ANSI_WHITE "%8llu / %-8llu\n" ANSI_RESET,
           (unsigned long long)g->nexus_hdr->used,
           (unsigned long long)g->nexus_hdr->cap);
    printf(ANSI_CYAN "  ║ ZipRaf " ANSI_WHITE "%8llu / %-8llu\n" ANSI_RESET,
           (unsigned long long)g->zipraf_hdr->used,
           (unsigned long long)g->zipraf_hdr->cap);
    printf(ANSI_CYAN "  ║ Msgs   " ANSI_WHITE "%8u\n" ANSI_RESET, g->msg_count);
    printf(ANSI_CYAN "  ║ Imgs   " ANSI_WHITE "%8llu\n" ANSI_RESET,
           (unsigned long long)g->trained_imgs);
    printf(ANSI_CYAN "  ║ JSON   " ANSI_WHITE "%8llu\n" ANSI_RESET,
           (unsigned long long)g->trained_json);
    printf(ANSI_CYAN "  ║ R(t)   " ANSI_WHITE "%.8f\n" ANSI_RESET, g->R_t);
    printf(ANSI_CYAN "  ║ Φ_e    " ANSI_WHITE "%.8f\n" ANSI_RESET, g->phi_ethica);
    printf(ANSI_BYELLOW "  ╚═══════════════════════════════════════╝\n" ANSI_RESET);
}

/* ── help ────────────────────────────────────────────── */
static void _help(void) {
    printf(ANSI_BYELLOW "\n  Comandos:\n" ANSI_RESET);
    printf("  " ANSI_BGREEN "b" ANSI_RESET
           "         — listar boards\n");
    printf("  " ANSI_BGREEN "j <N>" ANSI_RESET
           "      — entrar no board N\n");
    printf("  " ANSI_BGREEN "l" ANSI_RESET
           "         — listar msgs do board atual\n");
    printf("  " ANSI_BGREEN "r <N>" ANSI_RESET
           "      — ler mensagem N\n");
    printf("  " ANSI_BGREEN "p" ANSI_RESET
           "         — postar mensagem\n");
    printf("  " ANSI_BGREEN "s <query>" ANSI_RESET
           "  — busca semântica\n");
    printf("  " ANSI_BGREEN "ti <path>" ANSI_RESET
           "  — treinar imagem PPM\n");
    printf("  " ANSI_BGREEN "tj <path>" ANSI_RESET
           "  — treinar JSON (streaming)\n");
    printf("  " ANSI_BGREEN "tt <text>" ANSI_RESET
           "  — treinar texto direto\n");
    printf("  " ANSI_BGREEN "st" ANSI_RESET
           "        — estatísticas\n");
    printf("  " ANSI_BGREEN "cl" ANSI_RESET
           "        — limpar tela\n");
    printf("  " ANSI_BGREEN "q" ANSI_RESET
           "         — sair\n\n");
}

/* ── main BBS loop ───────────────────────────────────── */
void gaia_bbs_run(GaiaCtx *g) {
    _splash(g);
    _help();

    char line[1024];
    char prompt[64];

    while (1) {
        snprintf(prompt, sizeof(prompt),
            ANSI_BGREEN "[GAIA:%s]" ANSI_CYAN "→ " ANSI_RESET,
            g->boards[g->cur_board].name);

        _readline(prompt, line, sizeof(line));

        if (!line[0]) continue;

        /* ── commands ── */
        if (line[0]=='q' && !line[1]) {
            printf(ANSI_BYELLOW "  D'Ele, Amor. FIAT LUX.\n" ANSI_RESET);
            break;
        }
        else if (line[0]=='b' && !line[1]) {
            gaia_bbs_list_boards(g);
        }
        else if (line[0]=='l' && !line[1]) {
            gaia_bbs_list_msgs(g, g->cur_board);
        }
        else if (line[0]=='j' && line[1]==' ') {
            int n = atoi(line+2);
            if (n>=0 && n<GAIA_BBS_BOARDS) {
                g->cur_board=(uint32_t)n;
                printf("  Board: " ANSI_BGREEN "%s\n" ANSI_RESET,
                       g->boards[n].name);
                gaia_bbs_list_msgs(g, (uint32_t)n);
            }
        }
        else if (line[0]=='r' && line[1]==' ') {
            int id = atoi(line+2);
            _read_msg(g, (uint32_t)id);
        }
        else if (line[0]=='p' && !line[1]) {
            char author[32], subj[64], body[GAIA_BBS_MSG_LEN];
            _readline("  Autor: ", author, sizeof(author));
            _readline("  Assunto: ", subj, sizeof(subj));
            _readline("  Mensagem: ", body, sizeof(body));
            gaia_bbs_post(g, g->cur_board, author, subj, body);
            printf(ANSI_BGREEN "  → Postado. R(t)=%.6f\n" ANSI_RESET, g->R_t);
        }
        else if (line[0]=='s' && line[1]==' ') {
            gaia_bbs_search(g, line+2);
        }
        else if (line[0]=='t' && line[1]=='i' && line[2]==' ') {
            printf("  Treinando imagem: %s\n", line+3);
            int n = gaia_train_image(g, line+3);
            if (n > 0)
                printf(ANSI_BGREEN "  → %d tiles ingeridos.\n" ANSI_RESET, n);
            else
                printf(ANSI_RED "  → Erro %d\n" ANSI_RESET, n);
        }
        else if (line[0]=='t' && line[1]=='j' && line[2]==' ') {
            printf("  Treinando JSON: %s\n", line+3);
            int r = gaia_train_json_file(g, line+3);
            if (r==0)
                printf(ANSI_BGREEN "  → JSON ingerido. VecDB=%llu\n" ANSI_RESET,
                       (unsigned long long)g->vecdb_hdr->used);
            else
                printf(ANSI_RED "  → Erro %d\n" ANSI_RESET, r);
        }
        else if (line[0]=='t' && line[1]=='t' && line[2]==' ') {
            gaia_train_text(g, line+3, strlen(line+3),
                            g->boards[g->cur_board].layer, 0);
            printf(ANSI_BGREEN "  → Texto treinado. VecDB=%llu\n" ANSI_RESET,
                   (unsigned long long)g->vecdb_hdr->used);
        }
        else if (line[0]=='s' && line[1]=='t' && !line[2]) {
            _stats(g);
        }
        else if (line[0]=='c' && line[1]=='l') {
            _splash(g);
        }
        else if (line[0]=='?' || (line[0]=='h' && line[1]=='e')) {
            _help();
        }
        else {
            printf(ANSI_RED "  Comando desconhecido. '?' para ajuda.\n" ANSI_RESET);
        }
    }
}
