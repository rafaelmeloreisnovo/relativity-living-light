/*
 * gaia_train.c — training engine
 * Images: PPM/raw bytes → tile hashing → VecDB/ZipRaf
 * JSON: 64KB streaming chunks → field extraction → VecDB
 * No heap alloc — uses GaiaPool for temp buffers
 */
#include "gaia_bbs.h"
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <sys/stat.h>

/* ── vector builder helper ───────────────────────────── */
static void _build_vec(GaiaVec *v, uint64_t h, uint32_t layer, uint32_t flags) {
    v->hash  = h;
    v->layer = layer & 7;
    v->flags = flags;
    gaia_hash_to_vec(h, v->v);
}

/* ── text ingestion ──────────────────────────────────── */
int gaia_train_text(GaiaCtx *g, const char *text, size_t len,
                     uint32_t layer, uint8_t etype)
{
    if (!text || len == 0) return 0;

    uint64_t h = gaia_hash_crc32_asm((const uint8_t*)text, len);
    /* mix with djb2 for extra dispersion */
    h ^= gaia_hash_djb2((const uint8_t*)text, len);

    GaiaVec v;
    _build_vec(&v, h, layer, (uint32_t)etype);

    gaia_vecdb_insert(g, &v, g->trained_total);
    gaia_zipraf_insert(g, &v, etype);

    /* every 1000 insertions → also write to nexus */
    if ((g->trained_total % 1000) == 0) {
        gaia_nexus_insert(g, &v, text[0]=='{'?"json":"text");
    }

    g->trained_total++;
    return 1;
}

/* ── image: raw bytes ────────────────────────────────── */
/*
 * Tiles image into GAIA_IMG_TILE×GAIA_IMG_TILE blocks.
 * Each tile → hash → GaiaVec → inserted at layer = tile_row % 8
 * Works with any channel count (RGB, RGBA, L).
 */
int gaia_train_image_bytes(GaiaCtx *g, const uint8_t *px,
                             uint32_t w, uint32_t h, uint32_t ch)
{
    if (!px || w==0 || h==0 || ch==0) return 0;

    const uint32_t TILE = GAIA_IMG_TILE;
    uint32_t tile_bytes = TILE * TILE * ch;
    uint8_t  tile_buf[TILE * TILE * 4 + 4]; /* max 4ch */
    if (tile_bytes > sizeof(tile_buf)) tile_bytes = sizeof(tile_buf);

    int count = 0;
    uint32_t ty, tx;

    for (ty = 0; ty + TILE <= h; ty += TILE) {
        for (tx = 0; tx + TILE <= w; tx += TILE) {
            /* pack tile into contiguous buffer */
            uint32_t off = 0;
            for (uint32_t r = ty; r < ty+TILE && off+ch <= tile_bytes; r++) {
                for (uint32_t c = tx; c < tx+TILE && off+ch <= tile_bytes; c++) {
                    uint32_t idx = (r*w + c) * ch;
                    for (uint32_t ci = 0; ci < ch && off < tile_bytes; ci++)
                        tile_buf[off++] = px[idx + ci];
                }
            }

            uint32_t layer = (ty / TILE) % GAIA_ZIPRAF_LAYERS;
            uint64_t th = gaia_hash_tile(tile_buf, off, layer);

            GaiaVec v;
            _build_vec(&v, th, layer, 1 /* etype=img */);

            gaia_vecdb_insert(g, &v, g->trained_imgs);
            gaia_zipraf_insert(g, &v, 1);
            count++;
        }
    }

    g->trained_imgs++;
    g->trained_total += count;
    return count;
}

/* ── image: PPM file (P6 binary) ─────────────────────── */
int gaia_train_image(GaiaCtx *g, const char *path) {
    int fd = open(path, O_RDONLY);
    if (fd < 0) { perror(path); return -1; }

    /* read full file — limited to 64MB for safety */
    struct stat st;
    if (fstat(fd, &st) < 0) { close(fd); return -2; }
    if (st.st_size > 64*1024*1024) { close(fd); return -3; }

    /* use pool as temp buffer */
    gaia_pool_reset(&g->pool);
    uint8_t *buf = (uint8_t*)gaia_pool_alloc(&g->pool, (uint32_t)st.st_size + 1);
    if (!buf) { close(fd); return -4; }

    ssize_t nr = read(fd, buf, (size_t)st.st_size);
    close(fd);
    if (nr <= 0) return -5;
    buf[nr] = 0;

    /* Parse PPM P6 header: "P6\nW H\n255\n<pixels>" */
    uint32_t w=0, h=0, ch=3;
    uint8_t *px = buf;
    if (nr > 3 && buf[0]=='P' && buf[1]=='6') {
        /* skip to width */
        uint8_t *p = buf + 2;
        while (*p == ' ' || *p == '\n' || *p == '\r' || *p == '#') {
            if (*p == '#') while (*p && *p!='\n') p++;
            p++;
        }
        w = 0; while (*p>='0'&&*p<='9') w=w*10+(*p++)-'0';
        while (*p==' '||*p=='\n') p++;
        h = 0; while (*p>='0'&&*p<='9') h=h*10+(*p++)-'0';
        while (*p && *p!='\n') p++; p++;
        while (*p && *p!='\n') p++; p++; /* skip maxval line */
        px = p;
    } else {
        /* treat as raw square image of bytes */
        uint32_t side = 1;
        while (side*side < (uint32_t)nr) side++;
        w = h = side - 1;
        if (w == 0) return -6;
        ch = 1;
        px = buf;
    }

    if (w == 0 || h == 0) return -7;
    return gaia_train_image_bytes(g, px, w, h, ch);
}

/* ── JSON streaming parser ───────────────────────────── */
/*
 * Streams file in 64KB chunks. Finds string values between "key":"value"
 * and hashes each string field. Safe for 1.5GB JSON.
 *
 * Strategy:
 *   - Track position across chunks (overlap 256B for boundary strings)
 *   - Extract strings between '"': scan for '"' pairs
 *   - Hash each string, insert to vecdb with layer based on nesting depth
 */

#define JSON_OVERLAP 256

static int _is_word(uint8_t c) {
    return (c>='a'&&c<='z')||(c>='A'&&c<='Z')||
           (c>='0'&&c<='9')||c=='_'||c=='-'||c=='.'||c==' ';
}

static int _json_extract_strings(GaiaCtx *g, const uint8_t *buf, size_t sz,
                                   uint32_t depth_hint)
{
    int count = 0;
    size_t i = 0;
    while (i < sz) {
        if (buf[i] == '"') {
            i++;
            size_t start = i;
            /* scan to closing quote, skip escaped */
            while (i < sz && buf[i] != '"') {
                if (buf[i] == '\\') i++;
                i++;
            }
            size_t slen = i - start;
            if (slen >= 3 && slen <= 512) {
                /* hash this string field */
                uint32_t layer = depth_hint % GAIA_ZIPRAF_LAYERS;
                gaia_train_text(g, (const char*)(buf + start), slen, layer, 2);
                count++;
            }
            if (i < sz) i++; /* skip closing quote */
        } else {
            if (buf[i]=='{' || buf[i]=='[') depth_hint++;
            else if (buf[i]=='}'||buf[i]==']') {
                if (depth_hint) depth_hint--;
            }
            i++;
        }
    }
    return count;
}

int gaia_train_json_stream(GaiaCtx *g, int fd) {
    uint8_t chunk[GAIA_JSON_CHUNK + JSON_OVERLAP];
    size_t  overlap = 0;
    uint64_t total_strings = 0;
    uint32_t depth = 0;
    int      chunk_n = 0;

    while (1) {
        ssize_t nr = read(fd, chunk + overlap, GAIA_JSON_CHUNK);
        if (nr <= 0) break;

        size_t avail = overlap + (size_t)nr;
        int n = _json_extract_strings(g, chunk, avail, depth);
        total_strings += (uint64_t)n;
        chunk_n++;

        /* keep last JSON_OVERLAP bytes as overlap for next chunk */
        if (avail > JSON_OVERLAP) {
            overlap = JSON_OVERLAP;
            __builtin_memmove(chunk, chunk + avail - JSON_OVERLAP, JSON_OVERLAP);
        } else {
            overlap = avail;
        }

        /* progress report every 100 chunks (~6.4MB) */
        if (chunk_n % 100 == 0) {
            fprintf(stderr, "\r  [GAIA-TRAIN] JSON chunks: %d  strings: %llu  "
                    "vecdb: %llu",
                    chunk_n, (unsigned long long)total_strings,
                    (unsigned long long)g->vecdb_hdr->used);
            fflush(stderr);
        }
    }
    fprintf(stderr, "\n");
    g->trained_json++;
    return (int)(total_strings > 0 ? 0 : -1);
}

int gaia_train_json_file(GaiaCtx *g, const char *path) {
    int fd = open(path, O_RDONLY);
    if (fd < 0) { perror(path); return -1; }
    int r = gaia_train_json_stream(g, fd);
    close(fd);
    return r;
}

/* ── RAFAELIA step after training epoch ─────────────── */
void gaia_raf_step(GaiaCtx *g) {
    double n = (double)(g->trained_total + 1);
    double entropy   = 1.0 / n;          /* entropy decreases with data */
    double coherence = 1.0 - entropy;    /* coherence increases */
    g->phi_ethica = gaia_phi_ethica(entropy, coherence);

    double E_verbo = 1.0 + 0.01 * (double)g->vecdb_hdr->used / 1e6;
    g->R_t = gaia_raf_kernel_step(g->R_t, g->phi_ethica, E_verbo);
}
