#ifndef GAIA_LEARN_H
#define GAIA_LEARN_H
#include "gaia_bbs.h"
#define SOM_DIM   8
#define SOM_NODES 512
void  gaia_learn_init(void);
void  gaia_som_update(const float v[3]);
void  gaia_hebb_update(int lattice_pre, const float v[3]);
void  gaia_attention_step(GaiaCtx *g);
void  gaia_learn_stability_update(void);
void  gaia_learn_step(GaiaCtx *g, const float v[3]);
int   gaia_learn_json(char *buf, int cap);
int   gaia_som_json(char *buf, int cap);
#endif
