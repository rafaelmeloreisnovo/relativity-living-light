/*
 * gaia_hash.c — hash kernel with inline ASM acceleration
 * x86-64: CRC32c via SSE4.2  |  ARM64: CRC32 intrinsics
 * Fallback: DJB2 portable
 * φ-hop: PHI32 = 0x9E3779B9 — golden ratio step
 */
#include "gaia_bbs.h"
#include <string.h>
#include <math.h>

/* ── DJB2 fallback (always available) ──────────────── */
static uint64_t _djb2_64(const uint8_t *d, size_t n) {
    uint64_t h = 5381ULL;
    while (n--) h = ((h << 5) + h) ^ *d++;
    return h;
}

/* ── x86-64 CRC32c via SSE4.2 ───────────────────────── */
#if defined(__x86_64__) && defined(__SSE4_2__)
#include <nmmintrin.h>

static uint64_t _crc32c_x86(const uint8_t *data, size_t len) {
    uint64_t crc = 0xFFFFFFFFFFFFFFFFULL;
    size_t i = 0;
    /* process 8 bytes at a time */
    for (; i + 8 <= len; i += 8) {
        uint64_t val;
        __builtin_memcpy(&val, data+i, 8);
        __asm__ volatile (
            "crc32q %1, %0"
            : "+r"(crc)
            : "rm"(val)
        );
    }
    /* tail */
    for (; i < len; i++) {
        uint8_t b = data[i];
        __asm__ volatile (
            "crc32b %1, %0"
            : "+r"(crc)
            : "r"(b)
        );
    }
    return crc ^ 0xFFFFFFFFFFFFFFFFULL;
}
#define HAVE_CRC32_ASM 1
#define _crc32_asm _crc32c_x86

/* ── ARM64 CRC32 ────────────────────────────────────── */
#elif defined(__aarch64__) && defined(__ARM_FEATURE_CRC32)
#include <arm_acle.h>

static uint64_t _crc32c_arm(const uint8_t *data, size_t len) {
    uint32_t crc = 0xFFFFFFFFu;
    size_t i = 0;
    for (; i + 4 <= len; i += 4) {
        uint32_t val;
        __builtin_memcpy(&val, data+i, 4);
        crc = __crc32cw(crc, val);
    }
    for (; i < len; i++) crc = __crc32cb(crc, data[i]);
    return (uint64_t)(crc ^ 0xFFFFFFFFu);
}
#define HAVE_CRC32_ASM 1
#define _crc32_asm _crc32c_arm

#else
#define HAVE_CRC32_ASM 0
#endif

/* ── Public hash functions ──────────────────────────── */

uint64_t gaia_hash_djb2(const uint8_t *data, size_t len) {
    return _djb2_64(data, len);
}

uint64_t gaia_hash_crc32_asm(const uint8_t *data, size_t len) {
#if HAVE_CRC32_ASM
    return _crc32_asm(data, len);
#else
    return _djb2_64(data, len);
#endif
}

/*
 * φ-hop hash → 3D vector in [0,1]^3
 * Uses Weyl sequence with PHI32 steps, then normalizes.
 * Deterministic, no stdlib random.
 */
void gaia_hash_to_vec(uint64_t h, omega_float out[GAIA_VEC_DIM]) {
    uint32_t lo = (uint32_t)(h & 0xFFFFFFFFu);
    uint32_t hi = (uint32_t)(h >> 32);

    uint32_t a = lo * PHI32;
    uint32_t b = hi * PHI32;
    uint32_t c = (lo ^ hi) * (PHI32 ^ 0xDEADC0DEu);

    /* fold to [0,1] via /UINT32_MAX */
    out[0] = (omega_float)a * (1.0f / 4294967295.0f);
    out[1] = (omega_float)b * (1.0f / 4294967295.0f);
    out[2] = (omega_float)c * (1.0f / 4294967295.0f);
}

/* quantize [0,1] float → uint16 */
uint16_t gaia_quantize(omega_float f) {
    if (f < 0.0f) f = 0.0f;
    if (f > 1.0f) f = 1.0f;
    return (uint16_t)(f * 65535.0f);
}

/*
 * dot product of two GaiaVec — used for similarity
 * Inline ASM hint for compiler vectorization
 */
float gaia_vec_dot(const omega_float a[3], const omega_float b[3]) {
    float s;
    __asm__ volatile (
        /* Hint: compiler can use SIMD if available */
        "" ::: "memory"
    );
    s  = a[0]*b[0];
    s += a[1]*b[1];
    s += a[2]*b[2];
    return s;
}

/*
 * djb2 on image tile (GAIA_IMG_TILE×GAIA_IMG_TILE × ch bytes)
 * XOR with PHI32 fold for RAFAELIA layer mixing
 */
uint64_t gaia_hash_tile(const uint8_t *tile, uint32_t tile_bytes,
                         uint32_t layer) {
    uint64_t h = _djb2_64(tile, tile_bytes);
    /* mix layer via PHI32 */
    h ^= (uint64_t)layer * PHI32;
    h ^= h >> 33;
    h *= 0xff51afd7ed558ccdULL;
    h ^= h >> 33;
    h *= 0xc4ceb9fe1a85ec53ULL;
    h ^= h >> 33;
    return h;
}

/*
 * RAFAELIA kernel step — R(t+1)=R(t)×Φ_ethica×E_Verbo×(√3/2)^(πφ)
 * Returns new R value. Uses math.h pow/sqrt.
 * NOT a hot path — called once per training epoch.
 */
double gaia_raf_kernel_step(double Rt, double phi_e, double E_verbo) {
    static const double SQRT3_2  = 0.8660254037844386;
    static const double PI_PHI   = 3.14159265358979323846 *
                                   1.6180339887498948482;
    double factor = pow(SQRT3_2, PI_PHI);
    return Rt * phi_e * E_verbo * factor;
}

double gaia_phi_ethica(double entropy, double coherence) {
    /* Φ_ethica = Min(Entropy) × Max(Coherence) */
    /* We invert entropy: min entropy → high factor */
    double inv_ent = (entropy > 0.0) ? (1.0 / entropy) : 1.0;
    return inv_ent * coherence;
}
