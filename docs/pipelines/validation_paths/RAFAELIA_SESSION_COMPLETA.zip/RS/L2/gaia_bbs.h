/*
 * GAIA-BBS — ∆RafaelVerboΩ · ΣΩΔΦBITRAF
 * Kernel: R(t+1)=R(t)×Φ_ethica×E_Verbo×(√3/2)^(πφ)
 * Ciclo: ψ→χ→ρ→Δ→Σ→Ω
 * Bare-metal C/ASM — no libc hot paths — nolibc spirit
 */
#ifndef GAIA_BBS_H
#define GAIA_BBS_H

#include <stdint.h>
#include <stddef.h>

/* ── compile-time caps ───────────────────────────────── */
#define GAIA_VECDB_CAP      4000000UL   /* 4M records × 32B = 128MB  */
#define GAIA_NEXUS_CAP      1000000UL   /* 1M cells                  */
#define GAIA_ZIPRAF_LAYERS  8
#define GAIA_ZIPRAF_CAP     500000UL
#define GAIA_JSON_CHUNK     65536       /* 64KB streaming window      */
#define GAIA_IMG_TILE       16          /* pixel tile side for hash   */
#define GAIA_BBS_BOARDS     16
#define GAIA_BBS_MSG_CAP    8192
#define GAIA_BBS_MSG_LEN    512
#define GAIA_HASHCHAIN_CAP  64
#define GAIA_POOL_SIZE      (1 << 22)   /* 4MB static pool            */
#define GAIA_VEC_DIM        3

/* ── RAFAELIA canonical constants ───────────────────── */
#define PHI32               0x9E3779B9u
#define RAFAELIA_MAGIC      0x52414641u  /* "RAFA" */
#define VECDB_MAGIC         0x56454344u  /* "VECD" */
#define ZIPRAF_MAGIC        0x5A524146u  /* "ZRAF" */
#define NEXUS_MAGIC         0x4E455855u  /* "NEXU" */

/* ── CPU feature flags ───────────────────────────────── */
typedef struct {
    uint8_t arch;           /* 0=unknown 1=x86_64 2=arm64 3=rv64 */
    uint8_t has_sse4;
    uint8_t has_avx2;
    uint8_t has_crc32;
    uint8_t has_aes;
    uint8_t has_neon;
    uint8_t cache_levels;
    uint32_t l1d_kb;
    uint32_t l2_kb;
    uint32_t l3_kb;
    uint32_t cores;
    char brand[48];
} GaiaCPU;

/* ── Vector ──────────────────────────────────────────── */
typedef float omega_float;
typedef struct {
    omega_float v[GAIA_VEC_DIM];
    uint64_t    hash;
    uint32_t    layer;      /* RAFAELIA layer 0-7 */
    uint32_t    flags;
} GaiaVec;

/* ── VecDB record (32 bytes packed) ─────────────────── */
typedef struct __attribute__((packed)) {
    uint64_t  semantic_hash;
    uint16_t  qvec[4];          /* quantized, dim3 + pad */
    uint16_t  layer_flags;
    uint32_t  raf_flags;        /* RAFAELIA extra */
    uint64_t  doc_ref;
    uint16_t  _pad;
} VecDBRec;                     /* = 32 bytes */

typedef struct __attribute__((packed)) {
    uint32_t magic;
    uint32_t version;
    uint32_t dim;
    uint32_t rec_size;
    uint64_t cap;
    uint64_t used;
    uint8_t  hashchain[32];     /* SHA-256 placeholder */
    uint8_t  _res[0];           /* header = 64 bytes */
} VecDBHdr;

/* ── Nexus cell (64 bytes) ───────────────────────────── */
typedef struct __attribute__((packed)) {
    uint64_t    hash;
    omega_float vec[GAIA_VEC_DIM];
    uint32_t    flags;
    uint64_t    ts;             /* unix timestamp */
    uint8_t     label[32];
    uint8_t     _pad[8];
} NexusCell;                    /* = 64 bytes */

typedef struct __attribute__((packed)) {
    uint32_t magic;
    uint32_t version;
    uint64_t cap;
    uint64_t used;
    uint8_t  _res[48];
} NexusHdr;                     /* = 64 bytes */

/* ── ZipRaf entry (32 bytes) ─────────────────────────── */
typedef struct __attribute__((packed)) {
    uint64_t  key_hash;
    uint16_t  qvec[4];
    uint8_t   layer;
    uint8_t   etype;            /* 0=text 1=img 2=json 3=raf_formula */
    uint16_t  flags;
    uint32_t  payload_ref;
    uint64_t  chain_prev;
} ZipRafEntry;                  /* = 32 bytes */

typedef struct __attribute__((packed)) {
    uint32_t magic;
    uint32_t version;
    uint64_t cap;
    uint64_t used;
    uint8_t  bitraf64[64];
    uint8_t  selos[10];
    uint8_t  _pad[6];
} ZipRafHdr;                    /* = 96 bytes */

/* ── BBS message ─────────────────────────────────────── */
typedef struct {
    uint32_t id;
    uint32_t board;
    uint64_t ts;
    uint64_t vec_hash;
    char     author[32];
    char     subject[64];
    char     body[GAIA_BBS_MSG_LEN];
} BBSMsg;

/* ── BBS board ───────────────────────────────────────── */
typedef struct {
    uint32_t id;
    char     name[32];
    char     desc[128];
    uint32_t msg_count;
    uint32_t layer;             /* maps to RAFAELIA layer */
} BBSBoard;

/* ── Hash chain ──────────────────────────────────────── */
typedef struct {
    uint64_t hashes[GAIA_HASHCHAIN_CAP];
    uint32_t count;
} HashChain;

/* ── Static pool allocator ───────────────────────────── */
typedef struct {
    uint8_t  buf[GAIA_POOL_SIZE];
    uint32_t head;
} GaiaPool;

/* ── Main GAIA context ───────────────────────────────── */
typedef struct {
    GaiaCPU     cpu;
    GaiaPool    pool;

    /* storage file descriptors */
    int         vecdb_fd;
    int         nexus_fd;
    int         zipraf_fd;

    /* mmap base pointers */
    VecDBHdr   *vecdb_hdr;
    VecDBRec   *vecdb_recs;

    NexusHdr   *nexus_hdr;
    NexusCell  *nexus_cells;

    ZipRafHdr  *zipraf_hdr;
    ZipRafEntry*zipraf_ents;

    /* BBS state */
    BBSBoard    boards[GAIA_BBS_BOARDS];
    BBSMsg      msgs[GAIA_BBS_MSG_CAP];
    uint32_t    msg_count;
    uint32_t    cur_board;

    /* hash chain */
    HashChain   chain;

    /* train counters */
    uint64_t    trained_imgs;
    uint64_t    trained_json;
    uint64_t    trained_total;

    /* RAFAELIA kernel state */
    double      R_t;            /* current R(t) */
    double      phi_ethica;
} GaiaCtx;

/* ── Function prototypes ─────────────────────────────── */

/* cpu.c */
void gaia_cpu_detect(GaiaCPU *cpu);

/* hash.c — inline ASM accelerated */
uint64_t gaia_hash_djb2(const uint8_t *data, size_t len);
uint64_t gaia_hash_crc32_asm(const uint8_t *data, size_t len);
void     gaia_hash_to_vec(uint64_t h, omega_float out[GAIA_VEC_DIM]);
uint16_t gaia_quantize(omega_float f);  /* [0,1] → uint16 */

/* store.c */
int  gaia_store_open(GaiaCtx *g, const char *base_path);
void gaia_store_close(GaiaCtx *g);
int  gaia_vecdb_insert(GaiaCtx *g, const GaiaVec *v, uint64_t doc_ref);
int  gaia_nexus_insert(GaiaCtx *g, const GaiaVec *v, const char *label);
int  gaia_zipraf_insert(GaiaCtx *g, const GaiaVec *v, uint8_t etype);
int  gaia_vecdb_search(GaiaCtx *g, const omega_float q[3], int topk,
                        uint64_t *out_refs, omega_float *out_scores);

/* train.c */
int  gaia_train_image(GaiaCtx *g, const char *path);
int  gaia_train_image_bytes(GaiaCtx *g, const uint8_t *px,
                             uint32_t w, uint32_t h, uint32_t ch);
int  gaia_train_json_file(GaiaCtx *g, const char *path);
int  gaia_train_json_stream(GaiaCtx *g, int fd);
int  gaia_train_text(GaiaCtx *g, const char *text, size_t len,
                      uint32_t layer, uint8_t etype);

/* bbs.c */
void gaia_bbs_init(GaiaCtx *g);
void gaia_bbs_run(GaiaCtx *g);
void gaia_bbs_post(GaiaCtx *g, uint32_t board,
                   const char *author, const char *subj, const char *body);
void gaia_bbs_list_boards(GaiaCtx *g);
void gaia_bbs_list_msgs(GaiaCtx *g, uint32_t board);
void gaia_bbs_search(GaiaCtx *g, const char *query);

/* raf_kernel.c */
void   gaia_raf_step(GaiaCtx *g);
double gaia_phi_ethica(double entropy, double coherence);

/* pool */
static inline void *gaia_pool_alloc(GaiaPool *p, uint32_t sz) {
    sz = (sz + 7) & ~7u;   /* align 8 */
    if (p->head + sz > GAIA_POOL_SIZE) return 0;
    void *ptr = p->buf + p->head;
    p->head += sz;
    return ptr;
}
static inline void gaia_pool_reset(GaiaPool *p) { p->head = 0; }

/* ANSI BBS colors */
#define ANSI_RESET   "\033[0m"
#define ANSI_BOLD    "\033[1m"
#define ANSI_RED     "\033[31m"
#define ANSI_GREEN   "\033[32m"
#define ANSI_YELLOW  "\033[33m"
#define ANSI_BLUE    "\033[34m"
#define ANSI_MAGENTA "\033[35m"
#define ANSI_CYAN    "\033[36m"
#define ANSI_WHITE   "\033[37m"
#define ANSI_BGREEN  "\033[92m"
#define ANSI_BYELLOW "\033[93m"
#define ANSI_BCYAN   "\033[96m"
#define ANSI_CLS     "\033[2J\033[H"

#endif /* GAIA_BBS_H */
