/*
 * gaia_store.c — persistent storage engine
 * VecDB + Nexus + ZipRaf via mmap — no stdlib alloc on hot path
 * Files grow in fixed steps; mmap remapped on overflow.
 */
#include "gaia_bbs.h"
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>

/* ── sizes ───────────────────────────────────────────── */
#define VECDB_FILE_SIZE  (sizeof(VecDBHdr) + GAIA_VECDB_CAP * sizeof(VecDBRec))
#define NEXUS_FILE_SIZE  (sizeof(NexusHdr)  + GAIA_NEXUS_CAP  * sizeof(NexusCell))
#define ZIPRAF_FILE_SIZE (sizeof(ZipRafHdr) + GAIA_ZIPRAF_CAP * sizeof(ZipRafEntry))

/* ── mmap helpers ───────────────────────────────────── */
static int _mmap_file(const char *path, size_t file_sz,
                       void **hdr_out, void **data_out, size_t hdr_sz)
{
    int fd = open(path, O_RDWR|O_CREAT, 0644);
    if (fd < 0) { perror(path); return -1; }

    /* extend file to required size if needed */
    struct stat st;
    if (fstat(fd, &st) == 0 && (size_t)st.st_size < file_sz) {
        if (ftruncate(fd, (off_t)file_sz) < 0) {
            perror("ftruncate"); close(fd); return -1;
        }
    }

    void *base = mmap(NULL, file_sz, PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
    if (base == MAP_FAILED) { perror("mmap"); close(fd); return -1; }

    *hdr_out  = base;
    *data_out = (uint8_t*)base + hdr_sz;
    return fd;
}

/* ── VecDB open/init ─────────────────────────────────── */
static int _vecdb_open(GaiaCtx *g, const char *path) {
    void *hdr, *data;
    g->vecdb_fd = _mmap_file(path, VECDB_FILE_SIZE, &hdr, &data, sizeof(VecDBHdr));
    if (g->vecdb_fd < 0) return -1;

    g->vecdb_hdr  = (VecDBHdr*)hdr;
    g->vecdb_recs = (VecDBRec*)data;

    /* init header if new */
    if (g->vecdb_hdr->magic != VECDB_MAGIC) {
        memset(g->vecdb_hdr, 0, sizeof(VecDBHdr));
        g->vecdb_hdr->magic    = VECDB_MAGIC;
        g->vecdb_hdr->version  = 1;
        g->vecdb_hdr->dim      = GAIA_VEC_DIM;
        g->vecdb_hdr->rec_size = sizeof(VecDBRec);
        g->vecdb_hdr->cap      = GAIA_VECDB_CAP;
        g->vecdb_hdr->used     = 0;
        msync(g->vecdb_hdr, sizeof(VecDBHdr), MS_SYNC);
    }
    return 0;
}

/* ── Nexus open/init ─────────────────────────────────── */
static int _nexus_open(GaiaCtx *g, const char *path) {
    void *hdr, *data;
    g->nexus_fd = _mmap_file(path, NEXUS_FILE_SIZE, &hdr, &data, sizeof(NexusHdr));
    if (g->nexus_fd < 0) return -1;

    g->nexus_hdr   = (NexusHdr*)hdr;
    g->nexus_cells = (NexusCell*)data;

    if (g->nexus_hdr->magic != NEXUS_MAGIC) {
        memset(g->nexus_hdr, 0, sizeof(NexusHdr));
        g->nexus_hdr->magic   = NEXUS_MAGIC;
        g->nexus_hdr->version = 1;
        g->nexus_hdr->cap     = GAIA_NEXUS_CAP;
        g->nexus_hdr->used    = 0;
        msync(g->nexus_hdr, sizeof(NexusHdr), MS_SYNC);
    }
    return 0;
}

/* ── ZipRaf open/init ────────────────────────────────── */
static int _zipraf_open(GaiaCtx *g, const char *path) {
    void *hdr, *data;
    g->zipraf_fd = _mmap_file(path, ZIPRAF_FILE_SIZE, &hdr, &data, sizeof(ZipRafHdr));
    if (g->zipraf_fd < 0) return -1;

    g->zipraf_hdr  = (ZipRafHdr*)hdr;
    g->zipraf_ents = (ZipRafEntry*)data;

    if (g->zipraf_hdr->magic != ZIPRAF_MAGIC) {
        memset(g->zipraf_hdr, 0, sizeof(ZipRafHdr));
        g->zipraf_hdr->magic   = ZIPRAF_MAGIC;
        g->zipraf_hdr->version = 1;
        g->zipraf_hdr->cap     = GAIA_ZIPRAF_CAP;
        g->zipraf_hdr->used    = 0;
        /* embed bitraf64 selos */
        const char *b64 = "AΔBΩΔTTΦIIBΩΔΣΣRΩRΔΔBΦΦFΔTTRRFΔBΩΣΣAFΦARΣFΦIΔRΦIFBRΦΩFIΦΩΩFΣFAΦΔ";
        const char *selos = "ΣΩΔΦBITRAF";
        /* copy ASCII-only subset safely */
        size_t bl = strlen(b64); if(bl>63) bl=63;
        memcpy(g->zipraf_hdr->bitraf64, b64, bl);
        size_t sl = strlen(selos); if(sl>9) sl=9;
        memcpy(g->zipraf_hdr->selos, selos, sl);
        msync(g->zipraf_hdr, sizeof(ZipRafHdr), MS_SYNC);
    }
    return 0;
}

/* ── Public API ──────────────────────────────────────── */

int gaia_store_open(GaiaCtx *g, const char *base_path) {
    char path[512];

    snprintf(path, sizeof(path), "%s/gaia.vecdb", base_path);
    if (_vecdb_open(g, path) < 0) return -1;

    snprintf(path, sizeof(path), "%s/gaia.nexus", base_path);
    if (_nexus_open(g, path) < 0) return -2;

    snprintf(path, sizeof(path), "%s/gaia.zipraf", base_path);
    if (_zipraf_open(g, path) < 0) return -3;

    return 0;
}

void gaia_store_close(GaiaCtx *g) {
    if (g->vecdb_fd >= 0) {
        msync(g->vecdb_hdr, VECDB_FILE_SIZE, MS_SYNC);
        munmap(g->vecdb_hdr, VECDB_FILE_SIZE);
        close(g->vecdb_fd);
        g->vecdb_fd = -1;
    }
    if (g->nexus_fd >= 0) {
        msync(g->nexus_hdr, NEXUS_FILE_SIZE, MS_SYNC);
        munmap(g->nexus_hdr, NEXUS_FILE_SIZE);
        close(g->nexus_fd);
        g->nexus_fd = -1;
    }
    if (g->zipraf_fd >= 0) {
        msync(g->zipraf_hdr, ZIPRAF_FILE_SIZE, MS_SYNC);
        munmap(g->zipraf_hdr, ZIPRAF_FILE_SIZE);
        close(g->zipraf_fd);
        g->zipraf_fd = -1;
    }
}

int gaia_vecdb_insert(GaiaCtx *g, const GaiaVec *v, uint64_t doc_ref) {
    if (g->vecdb_hdr->used >= g->vecdb_hdr->cap) return -1;

    VecDBRec *r = &g->vecdb_recs[g->vecdb_hdr->used];
    r->semantic_hash = v->hash;
    r->qvec[0] = gaia_quantize(v->v[0]);
    r->qvec[1] = gaia_quantize(v->v[1]);
    r->qvec[2] = gaia_quantize(v->v[2]);
    r->qvec[3] = 0;
    r->layer_flags = (uint16_t)((v->layer & 7) | (v->flags << 3));
    r->raf_flags   = v->flags;
    r->doc_ref     = doc_ref;
    r->_pad        = 0;

    g->vecdb_hdr->used++;
    return 0;
}

int gaia_nexus_insert(GaiaCtx *g, const GaiaVec *v, const char *label) {
    if (g->nexus_hdr->used >= g->nexus_hdr->cap) return -1;

    NexusCell *c = &g->nexus_cells[g->nexus_hdr->used];
    c->hash   = v->hash;
    c->vec[0] = v->v[0];
    c->vec[1] = v->v[1];
    c->vec[2] = v->v[2];
    c->flags  = v->flags;
    c->ts     = (uint64_t)getpid(); /* placeholder ts */
    if (label) {
        size_t l = strlen(label); if(l>31) l=31;
        memcpy(c->label, label, l);
        c->label[l] = 0;
    }

    g->nexus_hdr->used++;
    return 0;
}

int gaia_zipraf_insert(GaiaCtx *g, const GaiaVec *v, uint8_t etype) {
    if (g->zipraf_hdr->used >= g->zipraf_hdr->cap) return -1;

    ZipRafEntry *e = &g->zipraf_ents[g->zipraf_hdr->used];
    e->key_hash   = v->hash;
    e->qvec[0]    = gaia_quantize(v->v[0]);
    e->qvec[1]    = gaia_quantize(v->v[1]);
    e->qvec[2]    = gaia_quantize(v->v[2]);
    e->qvec[3]    = 0;
    e->layer      = (uint8_t)(v->layer & 7);
    e->etype      = etype;
    e->flags      = (uint16_t)v->flags;
    e->payload_ref= (uint32_t)(g->zipraf_hdr->used);

    /* hash chain: XOR with previous entry hash */
    if (g->zipraf_hdr->used > 0)
        e->chain_prev = g->zipraf_ents[g->zipraf_hdr->used - 1].key_hash;
    else
        e->chain_prev = 0;

    g->zipraf_hdr->used++;
    return 0;
}

/*
 * Linear scan top-k similarity search in VecDB.
 * Returns indices in doc_ref array, scores in out_scores.
 * topk ≤ 16 (BBS use-case).
 */
int gaia_vecdb_search(GaiaCtx *g, const omega_float q[3],
                       int topk, uint64_t *out_refs, omega_float *out_scores)
{
    if (topk <= 0) return 0;
    uint64_t n = g->vecdb_hdr->used;
    if (n == 0) return 0;

    /* initialize worst scores */
    float best[16] = {0};
    uint64_t best_ref[16] = {0};
    int found = 0;

    /* dequantize query */
    float qa = q[0], qb = q[1], qc = q[2];

    for (uint64_t i = 0; i < n; i++) {
        VecDBRec *r = &g->vecdb_recs[i];
        float a = r->qvec[0] * (1.0f/65535.0f);
        float b = r->qvec[1] * (1.0f/65535.0f);
        float c = r->qvec[2] * (1.0f/65535.0f);

        float score = qa*a + qb*b + qc*c;  /* dot product */

        /* insertion sort into top-k */
        if (found < topk || score > best[found-1]) {
            int pos = found < topk ? found : topk - 1;
            while (pos > 0 && score > best[pos-1]) {
                best[pos]     = best[pos-1];
                best_ref[pos] = best_ref[pos-1];
                pos--;
            }
            best[pos]     = score;
            best_ref[pos] = r->doc_ref;
            if (found < topk) found++;
        }
    }

    for (int i = 0; i < found; i++) {
        out_refs[i]   = best_ref[i];
        out_scores[i] = best[i];
    }
    return found;
}
