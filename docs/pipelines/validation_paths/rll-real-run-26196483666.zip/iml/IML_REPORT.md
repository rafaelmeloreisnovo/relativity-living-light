# IML_REPORT
- run_utc: `2026-05-20T23:44:21.010792Z`
- input_path: `artifacts/rll-real-run/iml/input.json`
- input_sha256: `a57a99824928dd2bd2a1ba5bfff31f81aa13af11fe26c95a6c65522e0a58392b`
- steps_requested: `42`
- pipeline_name: `iml_pipeline`
- version: `1.0.0`
- custody.method: `sha256 file custody`
- custody.limitations: `integrity only; no scientific endorsement`