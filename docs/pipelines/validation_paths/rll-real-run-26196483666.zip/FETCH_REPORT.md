# FETCH_REPORT

mode: `full`
- igrf14: fetched
- wmm2025: fetched
- omni: fetched
- nmdb: fetched
- desi: pending_manual_or_large_download
- pantheon: fetched
- planck: pending_manual_or_large_download
- spenvis_reference: pending_manual_or_large_download