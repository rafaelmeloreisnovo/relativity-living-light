# PIPELINE_REPORT

- run_utc: `2026-05-20T23:44:20Z`
- commit_sha: `a386d4f9929a76fd547abd3587d6084a1f847df5`
- book_scope: `all`
- dataset_group: `all`
- mode: `compute`
- status editorial: `Parcial real em preparação`
- objetivo: methodology: validar rota metodológica. ; real_data: auditar dados reais e χ² inicial. ; scripts: mapear execução reprodutível. ; observational_validation: gerar rota de validação observacional completa. ; desi_boss: gerar manifesto de validação DESI/BOSS/Planck. ; amas_mcrp: ligar AMAS/SAA ao MCRP sem afirmar validação total.

## Separação obrigatória
- Hipótese
- Dado
- Modelo
- Métrica
- Referência
- Status: `blocked`
