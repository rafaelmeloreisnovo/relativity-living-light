# DATA_SOURCES

|source|group|version|status|url|
|---|---|---|---|---|
|igrf14|geomagnetic|IGRF14|fetched|https://www.ncei.noaa.gov/products/international-geomagnetic-reference-field|
|wmm2025|geomagnetic|WMM2025|fetched|https://www.ncei.noaa.gov/index.php/products/world-magnetic-model/wmm-coefficients|
|omni|heliophysics|OMNI/SPDF|fetched|https://omniweb.gsfc.nasa.gov/|
|nmdb|heliophysics|current|fetched|https://www.nmdb.eu/|
|desi|cosmology|DR2|pending_manual_or_large_download|https://data.desi.lbl.gov/|
|pantheon|cosmology|DataRelease|fetched|https://raw.githubusercontent.com/PantheonPlusSH0ES/DataRelease/main/README.md|
|planck|cosmology|Planck Legacy|pending_manual_or_large_download|https://pla.esac.esa.int/|
|spenvis_reference|heliophysics|reference|pending_manual_or_large_download|https://www.spenvis.oma.be/|