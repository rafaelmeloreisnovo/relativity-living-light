# COMPUTE_REPORT

run_utc: 2026-05-20T23:44:19.467839Z
- fallback_local: explicit only when used
- pending_data marked explicitly
- geomagnetic: compute_stub with TODO técnico claro