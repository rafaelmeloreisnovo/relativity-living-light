# Extensão Anisotrópica: f(z, θ, φ)
## Generalização direcional da função de transição

**Módulo:** teoria/EXTENSAO_ANISOTROPICA.md  
**Status:** Formulação completa — implementação numérica pendente  
**Motivação:** Anomalia de dipolo de Böhme et al. (2025), 5.4σ

---

## 1. Motivação Observacional

Böhme et al. (2025) reportaram uma assimetria direcional de 5.4σ na distribuição do CMB que sugere quebra de isotropia cósmica em escalas de z ≈ 0.5–1.5. O modelo RLL isotrópico não pode endereçar essa observação. A extensão anisotrópica proposta aqui o faz de forma natural.

---

## 2. Formulação

### 2.1 Função de transição direcional

```
f(z, θ, φ) = 1 / (1 + exp((z − z_t(θ,φ)) / w_t(θ,φ)))
```

onde θ e φ são coordenadas esféricas galácticas e os parâmetros de transição dependem da direção via harmônicos esféricos:

```
z_t(θ, φ) = z_t0 + Σ_{l=1}^{l_max} Σ_{m=-l}^{l}  δz_t^{lm} · Y_l^m(θ, φ)

w_t(θ, φ) = w_t0 + Σ_{l=1}^{l_max} Σ_{m=-l}^{l}  δw_t^{lm} · Y_l^m(θ, φ)
```

**Caso mínimo (dipolo apenas, l=1):**

```
z_t(θ, φ) = z_t0 + A_z · cos(θ) + B_z · sin(θ)cos(φ) + C_z · sin(θ)sin(φ)
w_t(θ, φ) = w_t0 + A_w · cos(θ)
```

### 2.2 Parâmetros do dipolo

| Parâmetro | Descrição | Constraint esperada |
|-----------|-----------|-------------------|
| z_t0 | Redshift de transição médio | 0.8 – 1.5 |
| A_z | Amplitude do dipolo em z_t (eixo z) | a estimar de dados |
| A_w | Amplitude do dipolo em w_t | a estimar de dados |
| l_axis | Direção preferencial (l, b) galático | a estimar de Böhme |

### 2.3 Equação de Friedmann anisotrópica

Para cada direção (θ, φ) no céu, a equação de Friedmann torna-se:

```
H²(z, θ, φ) = H₀² [ Ω_m(1+z)³ + Ω_r(1+z)⁴ + Ω_Λ
               + Ω_s0 · [f(z,θ,φ) + (1-f(z,θ,φ))(1+z)³] ]
```

Isso gera variação direcional em H(z), que propaga para distâncias de luminosidade e parâmetros de crescimento.

---

## 3. Previsão Observacional

### 3.1 Dipolo em H(z)

Para amplitude de dipolo A_z ≈ 0.1 (moderada):

```
ΔH/H₀ ~ (∂H/∂z_t) · A_z ~ 1-3%  em z ≈ 0.8 – 1.5
```

### 3.2 Dipolo em módulo de distância

```
Δμ(z, θ) ~ 5/ln(10) · ΔH/H(z) · [integral path correction]
         ~ 0.03 – 0.08 mag  para z ≈ 1
```

### 3.3 Dipolo em fσ₈

A quebra de isotropia em f(z,θ,φ) propaga para o crescimento:

```
Δ(fσ₈)/fσ₈ ~ 2-5%  direcional em z ≈ 0.5 – 1.0
```

---

## 4. Comparação com Böhme et al. (2025)

A estratégia de teste é:

**1.** Extrair a direção preferencial do dipolo reportado por Böhme (coordenadas l, b galácticas).

**2.** Orientar o eixo da anisotropia do modelo RLL na mesma direção.

**3.** Ajustar (A_z, A_w) para reproduzir a amplitude de 5.4σ nos observáveis de Böhme.

**4.** Verificar se os valores de (A_z, A_w) são fisicamente razoáveis (< 10% de z_t0).

**5.** Reportar Bayes Factor entre modelo isotrópico e anisotrópico.

---

## 5. Implementação Numérica

### Passos para implementar

```python
# Passo 1: Definir Y_l^m via scipy
from scipy.special import sph_harm
import numpy as np

def z_t_dir(theta, phi, z_t0, A_z, B_z, C_z):
    """Redshift de transição direcional (dipolo)"""
    return (z_t0 
            + A_z * np.cos(theta) 
            + B_z * np.sin(theta) * np.cos(phi)
            + C_z * np.sin(theta) * np.sin(phi))

def f_aniso(z, theta, phi, z_t0, w_t0, A_z, A_w):
    """Função de transição anisotrópica"""
    zt = z_t_dir(theta, phi, z_t0, A_z, 0, 0)
    wt = w_t0 + A_w * np.cos(theta)
    return 1.0 / (1.0 + np.exp((z - zt) / wt))

# Passo 2: Grid em (theta, phi) — HEALPix recomendado
# import healpy as hp
# nside = 32  # resolução angular ~1.8 graus

# Passo 3: Para cada pixel, calcular H(z, pixel)
# Passo 4: Construir mapa de H(z=1, θ, φ)
# Passo 5: Comparar com mapa de Böhme
```

### Dependências necessárias

```
numpy >= 1.24
scipy >= 1.10
healpy >= 1.16
emcee >= 3.1 (MCMC direcional)
```

---

## 6. Critério de Falsificabilidade

O modelo anisotrópico é falsificado se:

- Não existir combinação de (A_z, A_w) que reproduza o dipolo de Böhme com razão de Bayes K > 3
- A direção preferencial implicada diferir da reportada por Böhme em mais de 20°
- Os parâmetros de amplitude implicados (A_z/z_t0 > 0.3) forem fisicamente não-motivados

---

## 7. Conexão com a Literatura

A anisotropia no parâmetro de Hubble em z ≈ 1 é discutida em:

- Migkas et al. (2021) — anisotropia em H₀ via clusters X-ray
- Secrest et al. (2022) — dipolo quasar no CMB
- Böhme et al. (2025) — 5.4σ dipolo direcional

O mecanismo RLL de f(z,θ,φ) fornece um framework físico parametrizado para esses sinais, diferentemente das abordagens puramente fenomenológicas da literatura.
