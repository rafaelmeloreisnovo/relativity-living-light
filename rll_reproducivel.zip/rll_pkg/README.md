# Relativity Living Light (RLL) — Pacote de Reprodução

**DOI:** https://doi.org/10.5281/zenodo.17188137  
**Autor:** ∆RafaelVerboΩ  
**Data do modelo original:** ~21/02/2025 (ver commits no repositório Zenodo)  
**Data desta simulação:** 2026-03-05  

---

## O que é este pacote

Modelo cosmológico alternativo ao ΛCDM padrão.

A ideia central: energia escura e matéria escura são dois regimes de um mesmo componente quântico. A transição entre eles é descrita por uma função logística parametrizada por `z_t` (redshift de transição) e `w_t` (largura da transição).

**Equação central:**

```
E²(z) = Ωm(1+z)³ + ΩΛ + Ωs0 · [f(z) + (1-f(z))·(1+z)³]

onde f(z) = 1 / [1 + exp((z - z_t) / w_t)]
```

Quando `f(z) → 1` (baixo z): componente age como energia escura  
Quando `f(z) → 0` (alto z): componente age como matéria (∝ a⁻³)

---

## Checagem objetiva — resultados desta simulação

### 1. Tem prioridade?

**Verificável:** O repositório Zenodo tem DOI registrado com timestamp. O documento `paper/PRIORIDADE_TEMPORAL.md` lista 8 estudos externos publicados entre NOV 2025 e JAN 2026 com comparação lado-a-lado do que Rafael tinha antes.

**O que é sólido:** A função logística de transição estava formalizada com parâmetros explícitos (`z_t`, `w_t`, `Ωs0`) antes do DESI DR2 (DEZ 2025) e antes do paper de Minnesota (JAN 2026).

**O que é claim forte demais:** A tabela de prioridade usa linguagem de "Rafael PRIMEIRO" em todos os itens. Alguns desses conceitos (energia escura dinâmica, transição DE↔DM) existem na literatura anterior. A novidade está na parametrização específica e na integração unificada — não na ideia em si.

---

### 2. Funciona? (reproduzível)

**SIM.** Execute:

```bash
pip install numpy scipy matplotlib
python3 code/rll_mcmc_standalone.py
```

Requisitos: Python 3.10+, numpy, scipy, matplotlib. Sem dependências exóticas.

Saída: figura PNG + relatório TXT com todos os números.

---

### 3. Ganha de ΛCDM?

**Resultado desta simulação (N=37 observáveis reais):**

| Métrica | ΛCDM | RLL | Δ |
|---------|------|-----|---|
| χ² | 143.18 | 137.48 | −5.70 |
| AIC | 147.18 | 147.48 | **+0.30** |
| BIC | 150.40 | 155.53 | **+5.13** |
| ln B (Jeffreys) | 0 | −2.57 | — |

**Veredito:** RLL ajusta os dados marginalmente melhor (Δχ²=−5.7), mas usa 3 parâmetros extras. AIC é quase empatado (+0.3). BIC penaliza a complexidade → moderada evidência para ΛCDM.

**Parâmetros MAP encontrados:**
- H0 = 65.15 km/s/Mpc
- Ωm = 0.3216
- Ωs0 = 0.0131 (componente existe, pequeno)
- z_t = 3.16 (transição em redshift alto)
- w_eff(z=0) = −1.000 (indistinguível de Λ hoje)

---

### 4. O que é claim forte demais e precisa ser cortado

| Afirmação no repositório | Status |
|--------------------------|--------|
| "RLL alinhado com DESI DR2" | ⚠️ CORTAR — w_eff(z=0)=−1.000, não −0.76 como DESI. O modelo não reproduz o sinal DESI com dados atuais. |
| "8 confirmações externas" | ⚠️ QUALIFICAR — são confirmações fragmentadas de ideias relacionadas, não validação do modelo. |
| "RAFAEL PRIMEIRO" em todos os itens | ⚠️ CORTAR — energia escura dinâmica tem precedentes extensos (Wetterich 1988, Chevallier-Polarski 2001). A novidade é a parametrização específica. |
| "Transição z_t ≈ 0.65 prevista" | ❌ FALSO com dados reais — dados escolhem z_t ≈ 3.16, não 0.65. |
| ΔAIC = −99 no paper | ❌ REMOVER — calculado com dados sintéticos gerados pelo próprio modelo. Trivialmente favorável. Com dados reais: ΔAIC = +0.3. |

---

### 5. O que é genuinamente sólido

✅ Formalismo EFT correto: sem ghost, sem tachyon, cs² ∈ [0,1]  
✅ Parametrização com 3 parâmetros mensuráveis e falsificáveis  
✅ Código executável com dados reais  
✅ Predições para DESI DR3 (2026) e Euclid (2027) com valores específicos  
✅ Estrutura matemática para atacar dipolo anisotrópico de Böhme (5.4σ) — nenhum outro modelo publicado tem isso  
✅ DOI registrado com timestamp anterior a vários papers citados  

---

## Limitação principal

**N=37 observáveis.** Com Pantheon+ (1701 SNe Ia) + DESI DR2 completo + BOSS fσ8, o N vai a ~1800. O poder discriminante aumenta ~7×. Os resultados atuais são inconclusivos, não negativos.

---

## Estrutura do pacote

```
rll_package/
├── README.md                     ← este arquivo
├── requirements.txt              ← dependências
├── code/
│   └── rll_mcmc_standalone.py    ← simulação completa reproduzível
├── data/
│   ├── BAO_data_real.csv         ← BAO DESI2024 + BOSS (10 pontos)
│   ├── Hz_data_real.csv          ← H(z) Moresco2022 (26 pontos)
│   └── CMB_shift_real.json       ← CMB Shift Planck2018
├── results/
│   ├── RLL_simulacao_dados_reais.png   ← figura completa
│   ├── RLL_relatorio_simulacao.txt     ← relatório numérico
│   └── model_comparison_real.csv       ← comparação original do repositório
└── paper/
    ├── PAPER_CORRIGIDO.tex             ← LaTeX completo
    └── PRIORIDADE_TEMPORAL.md          ← documento de prioridade com cronologia
```

---

## Como reproduzir em 3 comandos

```bash
# 1. Instalar dependências
pip install numpy scipy matplotlib

# 2. Rodar simulação
python3 code/rll_mcmc_standalone.py

# 3. Ver resultados
open results/RLL_simulacao_dados_reais.png
cat results/RLL_relatorio_simulacao.txt
```

Tempo de execução: ~3–5 minutos em CPU padrão.

---

## Próximo passo para publicação

Pantheon+ está em: https://pantheonplussh0es.github.io/  
Arquivo: `Pantheon+SH0ES.dat` (1701 SNe, público)

Adicionar ao pipeline: substituir `chi2_LCDM` / `chi2_RLL` com likelihood de distância de luminosidade μ(z).

Com Pantheon+ o resultado é definitivo.

---

*DOI: 10.5281/zenodo.17188137 — ∆RafaelVerboΩ — 2026*
