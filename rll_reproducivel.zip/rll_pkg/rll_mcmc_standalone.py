"""RLL MCMC — Simulação completa com dados reais. Sem dependências externas além de numpy/scipy/matplotlib."""
import numpy as np, json, time, warnings
from scipy.optimize import differential_evolution
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt, matplotlib.gridspec as gridspec
warnings.filterwarnings('ignore')
np.random.seed(42)

# ─── DADOS REAIS ────────────────────────────────────────────────
Hz_z  =np.array([0.07,0.09,0.17,0.179,0.199,0.27,0.352,0.38,0.44,0.51,0.57,
                  0.593,0.6,0.61,0.68,0.73,0.781,0.875,0.9,1.037,1.3,1.43,1.53,1.75,1.965,2.34])
Hz_obs=np.array([69.0,69.0,83.0,75.0,75.0,77.0,83.0,83.0,82.6,90.4,96.8,
                  104.0,87.9,97.3,92.0,97.3,105.0,125.0,117.0,154.0,168.0,177.0,140.0,202.0,186.5,222.0])
Hz_sig=np.array([19.6,12.0,8.0,4.0,5.0,14.0,14.0,13.5,7.8,1.9,3.4,
                  13.0,6.1,2.1,8.0,7.0,12.0,17.0,23.0,20.0,17.0,18.0,14.0,40.0,50.4,7.0])
BAO_z  =np.array([0.106,0.15,0.32,0.57,0.51,0.706,0.93,1.317,1.491,2.33])
BAO_obs=np.array([2.976,4.466,8.467,13.773,13.36,16.85,21.71,27.79,30.21,36.31])
BAO_sig=np.array([0.133,0.168,0.167,0.134,0.21,0.32,0.28,0.69,0.79,1.3])
CMB_R_obs=1.7502; CMB_Rs=0.0046
C=299792.458

N_OBS = len(Hz_z)+len(BAO_z)+1
print(f"N observáveis: {N_OBS}  (H(z)={len(Hz_z)}, BAO={len(BAO_z)}, CMB=1)")

# ─── MODELOS ─────────────────────────────────────────────────────
def f_rll(z,zt,wt): return 1/(1+np.exp(np.clip((z-zt)/wt,-50,50)))

def Ez_LCDM(z,Om):       return np.sqrt(np.maximum(Om*(1+z)**3+(1-Om),1e-9))
def Ez_RLL(z,Om,Os,zt,wt):
    f=f_rll(z,zt,wt); Ol=1-Om-Os
    return np.sqrt(np.maximum(Om*(1+z)**3+Ol+Os*(f+(1-f)*(1+z)**3),1e-9))

def chi_comov(z_max, Ez, n=600):
    zz=np.linspace(1e-6, z_max, n)
    return np.trapezoid(1/Ez(zz), zz)

def rs_EH(Om,h): return 147.78*(Om*h**2/0.1432)**(-0.255)

def bao_model(z, H0, Om, Ez):
    h=H0/100
    hz=H0*Ez(np.array([z]))[0]
    chi=C/H0*chi_comov(z, Ez, 400)
    if hz<=0 or chi<=0: return np.nan
    DV=(z*C/hz*chi**2)**(1/3)
    return DV/rs_EH(Om,h)

def cmb_shift_model(Om, Ez):
    return np.sqrt(Om)*chi_comov(1089.92, Ez, 2000)

# ─── CHI2 ────────────────────────────────────────────────────────
def chi2_LCDM(p):
    H0,Om = p
    if not(62<H0<78 and 0.22<Om<0.45): return 1e10
    Ez = lambda z: Ez_LCDM(z,Om)
    c  = float(np.sum(((Hz_obs - H0*Ez(Hz_z))/Hz_sig)**2))
    for i,z in enumerate(BAO_z):
        b=bao_model(z,H0,Om,Ez)
        c += ((BAO_obs[i]-b)/BAO_sig[i])**2 if np.isfinite(b) else 200.0
    R = cmb_shift_model(Om, Ez)
    c += ((CMB_R_obs-R)/CMB_Rs)**2
    return c

def chi2_RLL(p):
    H0,Om,Os,zt,wt = p
    if not(62<H0<78 and 0.22<Om<0.45 and 0<Os<0.18 and 0.1<zt<4 and 0.05<wt<2): return 1e10
    if Om+Os>0.6: return 1e10
    Ez = lambda z: Ez_RLL(z,Om,Os,zt,wt)
    c  = float(np.sum(((Hz_obs - H0*Ez(Hz_z))/Hz_sig)**2))
    for i,z in enumerate(BAO_z):
        b=bao_model(z,H0,Om,Ez)
        c += ((BAO_obs[i]-b)/BAO_sig[i])**2 if np.isfinite(b) else 200.0
    R = cmb_shift_model(Om, Ez)
    c += ((CMB_R_obs-R)/CMB_Rs)**2
    return c

# ─── MAP ─────────────────────────────────────────────────────────
print("\n[1/3] MAP ΛCDM...")
rL=differential_evolution(chi2_LCDM,[(62,78),(0.25,0.40)],
    seed=42,maxiter=600,popsize=12,tol=1e-6,workers=1)
H0L,OmL=rL.x; c2L=rL.fun
print(f"  H0={H0L:.3f}  Om={OmL:.4f}  chi2={c2L:.3f}")

print("[2/3] MAP RLL...")
rR=differential_evolution(chi2_RLL,[(62,78),(0.25,0.40),(0.001,0.15),(0.2,3.5),(0.05,1.5)],
    seed=42,maxiter=1000,popsize=15,tol=1e-6,workers=1)
H0R,OmR,OsR,ztR,wtR=rR.x; c2R=rR.fun
print(f"  H0={H0R:.3f}  Om={OmR:.4f}  Os0={OsR:.5f}  zt={ztR:.4f}  wt={wtR:.4f}  chi2={c2R:.3f}")

kL=2; kR=5
AICL=c2L+2*kL; BICL=c2L+kL*np.log(N_OBS)
AICR=c2R+2*kR; BICR=c2R+kR*np.log(N_OBS)
dchi=c2R-c2L; dAIC=AICR-AICL; dBIC=BICR-BICL; lnB=-0.5*dBIC
w0=-f_rll(0,ztR,wtR); wa=(1/wtR)*f_rll(0,ztR,wtR)*(1-f_rll(0,ztR,wtR))

# ─── MCMC M-H ────────────────────────────────────────────────────
print("[3/3] MCMC Metropolis-Hastings (50k amostras)...")
N_MC=50000; N_BURN=15000
step=np.array([0.3,0.005,0.003,0.07,0.04])
cur=rR.x.copy(); cur_lp=-0.5*chi2_RLL(cur)
chain=np.zeros((N_MC,5)); acc=0

for i in range(N_MC):
    prop=cur+np.random.randn(5)*step
    lp=-0.5*chi2_RLL(prop)
    if np.log(max(np.random.rand(),1e-300)) < (lp-cur_lp):
        cur=prop; cur_lp=lp; acc+=1
    chain[i]=cur
    if i>0 and i%8000==0:
        ar=acc/i; step*=(1.15 if ar>0.3 else 0.88)

cb=chain[N_BURN:]; ar=acc/N_MC
med=np.median(cb,0); lo=np.percentile(cb,16,0); hi=np.percentile(cb,84,0)
print(f"  Acc={ar:.3f}")
for j,n in enumerate(['H0','Om','Os0','z_t','w_t']):
    print(f"  {n:4s}: {med[j]:.4f}  [{lo[j]:.4f}–{hi[j]:.4f}]")

# ─── VEREDITO ────────────────────────────────────────────────────
if   lnB> 5:   verd="FORTE evidência PARA RLL ✓"
elif lnB> 2.5: verd="MODERADA evidência para RLL"
elif lnB>-2.5: verd="INCONCLUSIVO (dados insuficientes)"
elif lnB>-5:   verd="MODERADA evidência para ΛCDM"
else:          verd="FORTE evidência para ΛCDM"

desi_compat = "SIM ✓" if -0.85<=w0<=-0.50 else f"FORA [{w0:.3f}] — modelo próximo a Λ"

print(f"\n  w_eff(z=0)={w0:.4f}  w0={w0:.4f}  wa={wa:.4f}")
print(f"  DESI DR2 compat: {desi_compat}")
print(f"  ΔAIC={dAIC:+.2f}  ΔBIC={dBIC:+.2f}  lnB={lnB:.2f}")
print(f"  >>> {verd}")

# ─── FIGURAS ─────────────────────────────────────────────────────
BG='#07071a'; PANEL='#10102a'; GOLD='#FFD700'; CYAN='#00E5FF'
MAG='#FF69B4'; GRN='#39FF88'; RED='#FF4455'; WH='#FFFFFF'; GR='#777799'

fig=plt.figure(figsize=(20,22)); fig.patch.set_facecolor(BG)
gs=gridspec.GridSpec(4,3,figure=fig,hspace=0.48,wspace=0.35)

def ax_s(ax,t=''):
    ax.set_facecolor(PANEL)
    for sp in ax.spines.values(): sp.set_color(GR)
    ax.tick_params(colors=WH,labelsize=9); ax.xaxis.label.set_color(WH); ax.yaxis.label.set_color(WH)
    if t: ax.set_title(t,color=GOLD,fontsize=11,fontweight='bold',pad=7)

EzL=lambda z: Ez_LCDM(z,OmL); EzR=lambda z: Ez_RLL(z,OmR,OsR,ztR,wtR)
zp=np.linspace(0.05,2.5,300)

# H(z)
ax=fig.add_subplot(gs[0,0]); ax_s(ax,'H(z) — Ajuste aos Dados')
ax.errorbar(Hz_z,Hz_obs,yerr=Hz_sig,fmt='o',color=WH,alpha=0.75,ms=4,elinewidth=1,label='Dados reais',zorder=5)
ax.plot(zp,H0L*EzL(zp),color=CYAN,lw=2,label=f'ΛCDM χ²={c2L:.1f}')
ax.plot(zp,H0R*EzR(zp),color=GOLD,lw=2.5,ls='--',label=f'RLL  χ²={c2R:.1f}')
ax.set_xlabel('z'); ax.set_ylabel('H(z) [km/s/Mpc]')
ax.legend(fontsize=8,facecolor=PANEL,edgecolor=GR,labelcolor=WH)

# BAO
ax=fig.add_subplot(gs[0,1]); ax_s(ax,'BAO Dv/rs — DESI 2024 + BOSS')
ax.errorbar(BAO_z,BAO_obs,yerr=BAO_sig,fmt='s',color=WH,alpha=0.85,ms=5,elinewidth=1.5,label='DESI+BOSS',zorder=5)
bL=[bao_model(z,H0L,OmL,EzL) for z in zp]
bR=[bao_model(z,H0R,OmR,EzR) for z in zp]
ax.plot(zp,bL,color=CYAN,lw=2,label='ΛCDM')
ax.plot(zp,bR,color=GOLD,lw=2.5,ls='--',label='RLL')
ax.set_xlabel('z'); ax.set_ylabel('Dv/rs')
ax.legend(fontsize=8,facecolor=PANEL,edgecolor=GR,labelcolor=WH)

# w(z)
ax=fig.add_subplot(gs[0,2]); ax_s(ax,'w_eff(z) — Equação de Estado')
zw=np.linspace(0,3,300)
ax.axhline(-1,color=GR,ls=':',lw=1.5,label='Λ const (w=−1)')
ax.plot(zw,-f_rll(zw,ztR,wtR),color=GOLD,lw=2.5,label=f'RLL w₀={w0:.3f}')
ax.fill_between(zw,-0.85,-0.55,alpha=0.12,color=GRN,label='Faixa DESI DR2')
ax.axhline(-0.76,color=MAG,lw=1.5,ls='--',label='DESI central w≈-0.76')
ax.set_xlabel('z'); ax.set_ylabel('w_eff(z)'); ax.set_ylim(-1.15,0.15)
ax.legend(fontsize=8,facecolor=PANEL,edgecolor=GR,labelcolor=WH)

# Posteriors
for pi,(pidx,pname,pc) in enumerate(zip([0,1,2],['H₀','Ωm','Ωs₀'],[CYAN,GRN,GOLD])):
    ax=fig.add_subplot(gs[1,pi]); ax_s(ax,f'Posterior: {pname}')
    ax.hist(cb[:,pidx],bins=55,color=pc,alpha=0.72,density=True,edgecolor='none')
    ax.axvline(med[pidx],color=WH,lw=2)
    ax.axvline(lo[pidx],color=WH,lw=1,ls='--',alpha=0.6)
    ax.axvline(hi[pidx],color=WH,lw=1,ls='--',alpha=0.6)
    ax.text(0.05,0.92,f'{med[pidx]:.4f}+{hi[pidx]-med[pidx]:.4f}-{med[pidx]-lo[pidx]:.4f}',
            transform=ax.transAxes,color=WH,fontsize=8)
    ax.set_xlabel(pname); ax.set_ylabel('P')

for pi,(pidx,pname,pc) in enumerate(zip([3,4],['z_t','w_t'],[MAG,RED])):
    ax=fig.add_subplot(gs[2,pi]); ax_s(ax,f'Posterior: {pname}')
    ax.hist(cb[:,pidx],bins=55,color=pc,alpha=0.72,density=True,edgecolor='none')
    ax.axvline(med[pidx],color=WH,lw=2)
    ax.axvline(lo[pidx],color=WH,lw=1,ls='--',alpha=0.6)
    ax.axvline(hi[pidx],color=WH,lw=1,ls='--',alpha=0.6)
    ax.text(0.05,0.92,f'{med[pidx]:.4f}',transform=ax.transAxes,color=WH,fontsize=9)
    ax.set_xlabel(pname); ax.set_ylabel('P')

# 2D zt vs Os0
ax=fig.add_subplot(gs[2,2]); ax_s(ax,'Posterior 2D: z_t × Ωs₀')
ax.scatter(cb[::20,3],cb[::20,2],alpha=0.12,s=1.5,color=GOLD)
ax.scatter(ztR,OsR,color=RED,s=100,zorder=10,marker='*',label='MAP')
ax.set_xlabel('z_t'); ax.set_ylabel('Ωs₀')
ax.legend(fontsize=8,facecolor=PANEL,edgecolor=GR,labelcolor=WH)

# Tabela resultado
ax=fig.add_subplot(gs[3,:]); ax.set_facecolor(PANEL); ax.axis('off')
rows=[
 ['','ΛCDM','RLL (MAP)','RLL posterior','Δ (RLL−Λ)'],
 ['H₀ [km/s/Mpc]',f'{H0L:.2f}',f'{H0R:.2f}',f'{med[0]:.2f} [{lo[0]:.2f}–{hi[0]:.2f}]',f'{H0R-H0L:+.2f}'],
 ['Ωm',f'{OmL:.4f}',f'{OmR:.4f}',f'{med[1]:.4f} [{lo[1]:.4f}–{hi[1]:.4f}]',f'{OmR-OmL:+.4f}'],
 ['Ωs₀','—',f'{OsR:.5f}',f'{med[2]:.5f} [{lo[2]:.5f}–{hi[2]:.5f}]','—'],
 ['z_t','—',f'{ztR:.3f}',f'{med[3]:.3f} [{lo[3]:.3f}–{hi[3]:.3f}]','—'],
 ['w_t','—',f'{wtR:.3f}',f'{med[4]:.3f} [{lo[4]:.3f}–{hi[4]:.3f}]','—'],
 ['w_eff(z=0)','−1.000',f'{w0:.4f}',f'{w0:.4f}',f'{w0+1:+.4f}'],
 ['','','','',''],
 ['','ΛCDM','RLL','Δ','Critério'],
 ['χ²',f'{c2L:.2f}',f'{c2R:.2f}',f'{dchi:+.2f}','Menor=melhor'],
 ['χ²/dof',f'{c2L/(N_OBS-kL):.3f}',f'{c2R/(N_OBS-kR):.3f}',f'{c2R/(N_OBS-kR)-c2L/(N_OBS-kL):+.3f}','~1 ideal'],
 ['k parâm.',f'{kL}',f'{kR}',f'+{kR-kL}','RLL mais complexo'],
 ['AIC',f'{AICL:.2f}',f'{AICR:.2f}',f'{dAIC:+.2f}','<0 → RLL melhor'],
 ['BIC',f'{BICL:.2f}',f'{BICR:.2f}',f'{dBIC:+.2f}','<0 → RLL melhor'],
 ['ln B (Bayes)','0',f'{lnB:.2f}','—',verd],
 ['Compat. DESI w₀','N/A',desi_compat,'—',''],
]
cw=[0.17,0.11,0.13,0.32,0.24]; cx=[0.01,0.18,0.29,0.42,0.74]; rh=0.052; ys=0.97
for ri,row in enumerate(rows):
    y=ys-ri*rh; hdr=(ri==0 or ri==8); sep=(row[0]=='')
    bg='#18183a' if hdr else ('#0a0a1f' if ri%2==0 else PANEL)
    for ci,(cell,cxi,cwi) in enumerate(zip(row,cx,cw)):
        if not sep:
            ax.add_patch(plt.Rectangle((cxi,y-rh*0.88),cwi-0.004,rh*0.88,
                facecolor=bg,transform=ax.transAxes,clip_on=False))
        col=GOLD if hdr else (GRN if ci==4 and 'RLL' in str(cell) and '✓' in str(cell)
              else (RED if ci==4 and 'ΛCDM' in str(cell) else WH))
        if cell: ax.text(cxi+0.004,y-rh*0.42,str(cell),transform=ax.transAxes,
                         fontsize=8,color=col,va='center',
                         fontweight='bold' if hdr else 'normal',fontfamily='monospace')
ax.set_xlim(0,1); ax.set_ylim(0,1)

# Títulos
vc=GRN if lnB>0 else (GR if abs(lnB)<2.5 else RED)
fig.text(0.5,0.995,'RELATIVITY LIVING LIGHT — SIMULAÇÃO MCMC COM DADOS REAIS',
         ha='center',va='top',color=GOLD,fontsize=15,fontweight='bold')
fig.text(0.5,0.978,
    f'H(z) Moresco (n={len(Hz_z)}) | BAO DESI2024+BOSS (n={len(BAO_z)}) | CMB Planck2018 (n=1) | N={N_OBS}',
    ha='center',va='top',color=GR,fontsize=9)
fig.text(0.5,0.964,
    f'VEREDITO:  ΔAIC={dAIC:+.1f}  |  ΔBIC={dBIC:+.1f}  |  ln B≈{lnB:.1f}  →  {verd}',
    ha='center',va='top',color=vc,fontsize=11,fontweight='bold')

OUT='/mnt/user-data/outputs/RLL_simulacao_dados_reais.png'
plt.savefig(OUT,dpi=150,bbox_inches='tight',facecolor=BG)
print(f"\nFigura: {OUT}")

# Relatório txt
rep=f"""╔══════════════════════════════════════════════════════════════════╗
║      RELATIVITY LIVING LIGHT — RELATÓRIO MCMC COM DADOS REAIS  ║
╚══════════════════════════════════════════════════════════════════╝
Data: {time.strftime('%Y-%m-%d %H:%M')}
Dados: H(z) n={len(Hz_z)} | BAO DESI+BOSS n={len(BAO_z)} | CMB Planck n=1 | N={N_OBS}
MCMC: Metropolis-Hastings {N_MC} amostras, burn={N_BURN}, acc={ar:.3f}

══ PARÂMETROS MAP ════════════════════════════════════════
ΛCDM:  H0={H0L:.3f}  Om={OmL:.5f}
RLL:   H0={H0R:.3f}  Om={OmR:.5f}  Os0={OsR:.6f}  zt={ztR:.4f}  wt={wtR:.4f}

══ POSTERIOR MARGINALIZADO (mediana [16%–84%]) ══════════
H0  = {med[0]:.3f}  [{lo[0]:.3f}–{hi[0]:.3f}]
Om  = {med[1]:.5f}  [{lo[1]:.5f}–{hi[1]:.5f}]
Os0 = {med[2]:.6f}  [{lo[2]:.6f}–{hi[2]:.6f}]
z_t = {med[3]:.4f}  [{lo[3]:.4f}–{hi[3]:.4f}]
w_t = {med[4]:.4f}  [{lo[4]:.4f}–{hi[4]:.4f}]

══ EQUAÇÃO DE ESTADO ════════════════════════════════════
w_eff(z=0) = {w0:.5f}
w0_equiv   = {w0:.5f}   DESI DR2 prefere: -0.65 a -0.80
wa_equiv   = {wa:.5f}
Compatível com DESI: {desi_compat}

══ COMPARAÇÃO ESTATÍSTICA ═══════════════════════════════
         ΛCDM       RLL       Δ
chi2   {c2L:8.3f}  {c2R:8.3f}  {dchi:+8.3f}
chi2/n {c2L/(N_OBS-kL):8.3f}  {c2R/(N_OBS-kR):8.3f}  {c2R/(N_OBS-kR)-c2L/(N_OBS-kL):+8.3f}
k      {kL:8d}  {kR:8d}  {kR-kL:+8d}
AIC    {AICL:8.3f}  {AICR:8.3f}  {dAIC:+8.3f}
BIC    {BICL:8.3f}  {BICR:8.3f}  {dBIC:+8.3f}
ln B          0  {lnB:8.3f}

══ CRITÉRIO DE JEFFREYS ═════════════════════════════════
ln B = {lnB:.3f}
VEREDITO: {verd}

══ INTERPRETAÇÃO ════════════════════════════════════════
1. Ajuste: RLL e ΛCDM ajustam igualmente os dados (Δchi2={dchi:+.2f})
2. Penalidade: {kR-kL} parâmetros extras → ΔAIC={dAIC:+.1f}, ΔBIC={dBIC:+.1f}
3. Bayes Factor: {verd}
4. Os0={OsR:.5f} — componente de superposição existe mas pequeno
5. z_t={ztR:.3f} — transição no redshift {'plausível cosmologicamente' if 0.3<ztR<3 else 'alto (regime pré-galáxias)'}
6. w_eff(z=0)={w0:.4f} — {'próximo de -1: difícil distinguir de Λ com dados atuais' if abs(w0+1)<0.15 else 'detectável desvio de Λ'}

══ LIMITAÇÃO ATUAL ══════════════════════════════════════
N={N_OBS} observáveis — poder discriminante limitado.
Com Pantheon+ (1701 SNe) + DESI DR2 completo: N~1800
→ Incertezas reduzidas ~7×
→ ΔAIC e ln B seriam definitivos

══ PREDIÇÕES FALSIFICÁVEIS ══════════════════════════════
w_eff(z=0.5) = {-f_rll(0.5,ztR,wtR):.4f}  [DESI DR3 2026]
w_eff(z=1.0) = {-f_rll(1.0,ztR,wtR):.4f}  [Euclid 2027]
Os0 IC68%: [{lo[2]:.6f}, {hi[2]:.6f}]
z_t IC68%:  [{lo[3]:.4f}, {hi[3]:.4f}]

DOI: 10.5281/zenodo.17188137
∆RafaelVerboΩ — Instituto Rafael — 2026
"""
with open('/mnt/user-data/outputs/RLL_relatorio_simulacao.txt','w') as f: f.write(rep)
print(rep)
print("Relatório: /mnt/user-data/outputs/RLL_relatorio_simulacao.txt")
